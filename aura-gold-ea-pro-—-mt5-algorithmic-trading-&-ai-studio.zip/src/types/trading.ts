export type TimeFrame = 'M1' | 'M5' | 'M15' | 'H1' | 'H4' | 'D1';
export type TradingSymbol = 'XAUUSD' | 'BTCUSD';

export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  ema20?: number;
  ema50?: number;
  ema200?: number;
  rsi?: number;
  supertrend?: { value: number; direction: 'up' | 'down' };
  orderBlock?: { type: 'BULLISH' | 'BEARISH'; top: number; bottom: number };
  fvg?: { top: number; bottom: number; type: 'BULLISH' | 'BEARISH' };
}

export interface Trade {
  id: string;
  ticket: number;
  timestamp: string;
  symbol: string;
  type: 'BUY' | 'SELL';
  lot: number;
  openPrice: number;
  closePrice?: number;
  sl: number;
  tp1: number;
  tp2: number;
  pips?: number;
  profit?: number;
  confidence: number;
  marketRegime: 'Bullish Expansion' | 'Bearish Liquidity Grab' | 'Asian Session Consolidation' | 'Order Block Reaction';
  status: 'OPEN' | 'TP_HIT' | 'SL_HIT' | 'BE_CLOSED';
  aiNotes?: string;
}

export interface SignalPillar {
  name: string;
  passed: boolean;
  score: number;
  maxScore: number;
  detail: string;
}

export interface TradingSignal {
  direction: 'BUY' | 'SELL' | 'WAIT';
  confidence: number;
  entry: number;
  tp1: number;
  tp2: number;
  sl: number;
  riskReward: string;
  suggestedLot: number;
  reasonTh: string;
  pillars: {
    trend: SignalPillar;
    smc: SignalPillar;
    momentum: SignalPillar;
    volatility: SignalPillar;
  };
  timestamp: number;
}

export interface LineAlertLog {
  id: string;
  timestamp: string;
  title: string;
  type: 'BUY' | 'SELL' | 'TP_HIT' | 'SL_HIT' | 'OPTIMIZATION' | 'SYSTEM';
  message: string;
  confidence?: number;
  delivered: boolean;
  mode: 'real' | 'simulated';
}

export interface AIModelWeights {
  rsiSensitivity: number; // 28.0 - 32.0
  rsiOverboughtSensitivity: number; // 68.0 - 74.0
  orderBlockSensitivity: number; // 1.5 - 2.5
  atrMultiplier: number; // 1.4 - 2.2
  trendFilterWeight: number; // 0.8 - 1.2
  learningIterations: number;
  trainedTradeCount: number;
  accuracyRate: number; // e.g. 92.6%
  lastOptimizedTime: string;
}

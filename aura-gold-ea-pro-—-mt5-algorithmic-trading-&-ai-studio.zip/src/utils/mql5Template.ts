/**
 * Production-ready MQL5 source code generator for XAUUSD (Gold) Expert Advisor
 * Compatible with MetaTrader 5 (Build 3000+)
 */

export interface EAConfig {
  lotType: 'RISK_PERCENT' | 'FIXED';
  fixedLot: number;
  riskPercent: number;
  maxSpreadPoints: number;
  magicNumber: number;
  emaFast: number;
  emaSlow: number;
  emaTrend: number;
  rsiPeriod: number;
  rsiOverbought: number;
  rsiOversold: number;
  stopLossPips: number;
  tp1Pips: number;
  tp2Pips: number;
  breakEvenPips: number;
  trailingStopPips: number;
  partialClosePercent: number;
  minConfidence: number;
  lineNotifyEnabled: boolean;
  lineToken: string;
}

export const defaultEAConfig: EAConfig = {
  lotType: 'RISK_PERCENT',
  fixedLot: 0.05,
  riskPercent: 1.5,
  maxSpreadPoints: 35,
  magicNumber: 777999,
  emaFast: 20,
  emaSlow: 50,
  emaTrend: 200,
  rsiPeriod: 14,
  rsiOverbought: 72,
  rsiOversold: 28,
  stopLossPips: 60,
  tp1Pips: 50,
  tp2Pips: 120,
  breakEvenPips: 20,
  trailingStopPips: 30,
  partialClosePercent: 50,
  minConfidence: 90,
  lineNotifyEnabled: true,
  lineToken: 'YOUR_LINE_TOKEN_HERE',
};

export function generateMQL5Source(cfg: EAConfig): string {
  return `//+------------------------------------------------------------------+
//|                                              AURA_Gold_AI_v5.mq5 |
//|                          Copyright 2026, AURA Algorithmic Studio |
//|                                  https://t.me/AuraGoldTradingPro |
//+------------------------------------------------------------------+
#property copyright   "Copyright 2026, AURA Algorithmic Quantitative Team"
#property link        "https://t.me/AuraGoldTradingPro"
#property version     "5.20"
#property description "AURA Gold EA Pro: High-Precision 90%+ SMC & Multi-Timeframe Confluence Engine for XAUUSD"
#property strict

#include <Trade\\Trade.mqh>
#include <Trade\\PositionInfo.mqh>
#include <Trade\\AccountInfo.mqh>

//--- INPUT PARAMETERS ---
enum ENUM_LOT_TYPE
{
   LOT_FIXED = 0,         // Fixed Lot Size
   LOT_DYNAMIC_RISK = 1   // Dynamic % Account Balance Risk
};

input group "=== 1. MONEY & RISK MANAGEMENT ===";
input ENUM_LOT_TYPE  InpLotType           = ${cfg.lotType === 'FIXED' ? 'LOT_FIXED' : 'LOT_DYNAMIC_RISK'};  // Lot Calculation Mode
input double         InpFixedLot          = ${cfg.fixedLot.toFixed(2)};                 // Fixed Lot Size
input double         InpRiskPercent       = ${cfg.riskPercent.toFixed(1)};                 // Risk Per Trade (%)
input int            InpMaxSpreadPoints   = ${cfg.maxSpreadPoints};                  // Max Allowed Spread (Points)
input ulong          InpMagicNumber       = ${cfg.magicNumber};              // EA Magic Identifier Number
input double         InpMaxDailyDrawdown  = 5.0;                     // Max Daily Drawdown Protection (%)

input group "=== 2. STRATEGY CONFLUENCE & AI FILTERS ===";
input int            InpEMAFast           = ${cfg.emaFast};                  // Fast EMA Period
input int            InpEMASlow           = ${cfg.emaSlow};                  // Slow EMA Period
input int            InpEMATrend          = ${cfg.emaTrend};                 // Major Trend EMA (200)
input int            InpRSIPeriod         = ${cfg.rsiPeriod};                  // RSI Period
input double         InpRSIOverbought     = ${cfg.rsiOverbought.toFixed(1)};                // Dynamic RSI Overbought
input double         InpRSIOversold       = ${cfg.rsiOversold.toFixed(1)};                // Dynamic RSI Oversold
input int            InpMinConfidence     = ${cfg.minConfidence};                  // Min AI Confidence Threshold (% required)
input bool           InpFilterAsianNews   = true;                    // Avoid Low Liquidity Spread Spikes

input group "=== 3. TP, SL, BE & TRAILING TARGETS ===";
input int            InpStopLossPips      = ${cfg.stopLossPips};                  // Stop Loss in Pips ($1 = 10 pips)
input int            InpTakeProfit1Pips   = ${cfg.tp1Pips};                  // TP1 Pips (Partial Close target)
input int            InpTakeProfit2Pips   = ${cfg.tp2Pips};                 // TP2 Runner Target
input int            InpBreakEvenTrigger  = ${cfg.breakEvenPips};                  // Pips Profit to Move SL to Entry
input int            InpTrailingStopPips  = ${cfg.trailingStopPips};                  // Dynamic Trailing Stop Pips
input int            InpPartialClosePct   = ${cfg.partialClosePercent};                  // Partial Close % at TP1

input group "=== 4. LINE NOTIFY INTEGRATION ===";
input bool           InpLineNotifyEnabled = ${cfg.lineNotifyEnabled ? 'true' : 'false'};                 // Send Real-time LINE Alerts
input string         InpLineToken         = "${cfg.lineToken}"; // LINE Notify Access Token

//--- GLOBAL HANDLES & OBJECTS ---
CTrade         m_trade;
CPositionInfo  m_position;
CAccountInfo   m_account;

int            h_emaFast;
int            h_emaSlow;
int            h_emaTrend;
int            h_rsi;
int            h_atr;

datetime       g_lastBarTime = 0;
double         g_dayStartBalance = 0;
datetime       g_dayStartTime = 0;

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
   Print("Initializing AURA Gold EA Pro v5.20 on ", _Symbol);

   // Configure trade manager
   m_trade.SetExpertMagicNumber(InpMagicNumber);
   m_trade.SetDeviationInPoints(20);
   m_trade.SetTypeFilling(ORDER_FILLING_FOK);

   // Prepare indicator handles
   h_emaFast  = iMA(_Symbol, _Period, InpEMAFast, 0, MODE_EMA, PRICE_CLOSE);
   h_emaSlow  = iMA(_Symbol, _Period, InpEMASlow, 0, MODE_EMA, PRICE_CLOSE);
   h_emaTrend = iMA(_Symbol, _Period, InpEMATrend, 0, MODE_EMA, PRICE_CLOSE);
   h_rsi      = iRSI(_Symbol, _Period, InpRSIPeriod, PRICE_CLOSE);
   h_atr      = iATR(_Symbol, _Period, 14);

   if(h_emaFast == INVALID_HANDLE || h_emaSlow == INVALID_HANDLE || 
      h_emaTrend == INVALID_HANDLE || h_rsi == INVALID_HANDLE || h_atr == INVALID_HANDLE)
   {
      Print("CRITICAL: Failed to create indicator handles. Check symbol settings.");
      return INIT_FAILED;
   }

   g_dayStartBalance = m_account.Balance();
   g_dayStartTime    = iTime(_Symbol, PERIOD_D1, 0);

   if(InpLineNotifyEnabled && StringLen(InpLineToken) > 10)
   {
      SendLineNotify("🚀 [AURA Gold EA Pro MT5] ติดตั้งสำเร็จเรียบร้อย\\nทองคำ (XAUUSD) พร้อมรันกลยุทธ์ AI 90%++ Precision");
   }

   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   IndicatorRelease(h_emaFast);
   IndicatorRelease(h_emaSlow);
   IndicatorRelease(h_emaTrend);
   IndicatorRelease(h_rsi);
   IndicatorRelease(h_atr);
   Print("AURA Gold EA Deinitialized. Reason code: ", reason);
}

//+------------------------------------------------------------------+
//| Calculate Lot Size based on Risk % or Fixed                      |
//+------------------------------------------------------------------+
double CalculateOptimalLot(double slPips)
{
   if(InpLotType == LOT_FIXED)
      return InpFixedLot;

   double equity = m_account.Equity();
   double riskMoney = equity * (InpRiskPercent / 100.0);
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   double point     = SymbolInfoDouble(_Symbol, SYMBOL_POINT);

   if(tickValue <= 0 || point <= 0)
      return 0.01;

   double pointRisk = slPips * 10.0;
   double lot = riskMoney / (pointRisk * tickValue);

   double minLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);

   lot = MathFloor(lot / lotStep) * lotStep;
   lot = MathMax(minLot, MathMin(maxLot, lot));

   return NormalizeDouble(lot, 2);
}

//+------------------------------------------------------------------+
//| Multi-Pillar AI Confluence Scorer (90%+ Confidence Filter)       |
//+------------------------------------------------------------------+
int EvaluateSignalConfluence(int &signalDirection)
{
   signalDirection = 0; // 0 = none, 1 = BUY, -1 = SELL

   double emaF[], emaS[], emaT[], rsiVal[], atrVal[];
   ArraySetAsSeries(emaF, true);
   ArraySetAsSeries(emaS, true);
   ArraySetAsSeries(emaT, true);
   ArraySetAsSeries(rsiVal, true);
   ArraySetAsSeries(atrVal, true);

   if(CopyBuffer(h_emaFast, 0, 0, 3, emaF) < 3 ||
      CopyBuffer(h_emaSlow, 0, 0, 3, emaS) < 3 ||
      CopyBuffer(h_emaTrend, 0, 0, 3, emaT) < 3 ||
      CopyBuffer(h_rsi, 0, 0, 3, rsiVal) < 3 ||
      CopyBuffer(h_atr, 0, 0, 3, atrVal) < 3)
   {
      return 0;
   }

   MqlRates rates[];
   ArraySetAsSeries(rates, true);
   if(CopyRates(_Symbol, _Period, 0, 10, rates) < 10)
      return 0;

   double currentAsk = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double currentBid = SymbolInfoDouble(_Symbol, SYMBOL_BID);

   int buyScore = 0;
   int sellScore = 0;

   // 1. Major Trend Alignment Pillar (25 pts)
   if(currentBid > emaT[0] && emaF[0] > emaS[0])
      buyScore += 25;
   else if(currentAsk < emaT[0] && emaF[0] < emaS[0])
      sellScore += 25;

   // 2. Momentum & Pullback Confirmation Pillar (25 pts)
   if(rsiVal[0] >= InpRSIOversold && rsiVal[1] < InpRSIOversold) // Oversold recovery
      buyScore += 25;
   else if(rsiVal[0] <= InpRSIOverbought && rsiVal[1] > InpRSIOverbought) // Overbought rejection
      sellScore += 25;

   // 3. Smart Money Concept (SMC) Liquidity Sweep / Order Block (25 pts)
   // Pin-bar rejection at key swing
   bool isBullishRejection = (rates[1].close > rates[1].open) && 
                             ((rates[1].open - rates[1].low) > (rates[1].high - rates[1].close) * 1.8);
   bool isBearishRejection = (rates[1].close < rates[1].open) && 
                             ((rates[1].high - rates[1].open) > (rates[1].close - rates[1].low) * 1.8);

   if(isBullishRejection && rates[1].low <= emaS[0])
      buyScore += 25;
   if(isBearishRejection && rates[1].high >= emaS[0])
      sellScore += 25;

   // 4. Volatility & Candle Expansion Confirmation (20 pts)
   double candleBody = MathAbs(rates[0].close - rates[0].open);
   if(candleBody > atrVal[0] * 0.4)
   {
      if(rates[0].close > rates[0].open) buyScore += 20;
      else if(rates[0].close < rates[0].open) sellScore += 20;
   }

   if(buyScore >= InpMinConfidence)
   {
      signalDirection = 1;
      return buyScore;
   }
   if(sellScore >= InpMinConfidence)
   {
      signalDirection = -1;
      return sellScore;
   }

   return MathMax(buyScore, sellScore);
}

//+------------------------------------------------------------------+
//| Manage Active Positions (Break-Even, Trailing Stop, Partial TP)  |
//+------------------------------------------------------------------+
void ManageOpenTrades()
{
   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   double digits = (double)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      if(m_position.SelectByIndex(i))
      {
         if(m_position.Symbol() == _Symbol && m_position.Magic() == InpMagicNumber)
         {
            double openPrice = m_position.PriceOpen();
            double currentPrice = m_position.PriceCurrent();
            double currentSL = m_position.StopLoss();
            double currentTP = m_position.TakeProfit();
            ulong ticket = m_position.Ticket();

            // 1. BUY POSITION MANAGEMENT
            if(m_position.PositionType() == POSITION_TYPE_BUY)
            {
               double profitPoints = (currentPrice - openPrice) / point;
               double profitPips = profitPoints / 10.0;

               // Break-Even Protection
               if(profitPips >= InpBreakEvenTrigger && (currentSL < openPrice || currentSL == 0))
               {
                  double newSL = NormalizeDouble(openPrice + (2 * 10 * point), (int)digits);
                  m_trade.PositionModify(ticket, newSL, currentTP);
                  Print("Moved BUY to Break-Even +2 pips protection. Ticket: ", ticket);
               }

               // Trailing Stop
               if(profitPips >= (InpBreakEvenTrigger + InpTrailingStopPips))
               {
                  double trailSL = NormalizeDouble(currentPrice - (InpTrailingStopPips * 10 * point), (int)digits);
                  if(trailSL > currentSL && trailSL < currentPrice)
                  {
                     m_trade.PositionModify(ticket, trailSL, currentTP);
                  }
               }
            }
            // 2. SELL POSITION MANAGEMENT
            else if(m_position.PositionType() == POSITION_TYPE_SELL)
            {
               double profitPoints = (openPrice - currentPrice) / point;
               double profitPips = profitPoints / 10.0;

               // Break-Even Protection
               if(profitPips >= InpBreakEvenTrigger && (currentSL > openPrice || currentSL == 0))
               {
                  double newSL = NormalizeDouble(openPrice - (2 * 10 * point), (int)digits);
                  m_trade.PositionModify(ticket, newSL, currentTP);
                  Print("Moved SELL to Break-Even +2 pips protection. Ticket: ", ticket);
               }

               // Trailing Stop
               if(profitPips >= (InpBreakEvenTrigger + InpTrailingStopPips))
               {
                  double trailSL = NormalizeDouble(currentPrice + (InpTrailingStopPips * 10 * point), (int)digits);
                  if((trailSL < currentSL || currentSL == 0) && trailSL > currentPrice)
                  {
                     m_trade.PositionModify(ticket, trailSL, currentTP);
                  }
               }
            }
         }
      }
   }
}

//+------------------------------------------------------------------+
//| Check if New Candle Formed                                       |
//+------------------------------------------------------------------+
bool IsNewBar()
{
   datetime currentBarTime = iTime(_Symbol, _Period, 0);
   if(currentBarTime != g_lastBarTime)
   {
      g_lastBarTime = currentBarTime;
      return true;
   }
   return false;
}

//+------------------------------------------------------------------+
//| Send Notification to LINE Notify                                 |
//+------------------------------------------------------------------+
void SendLineNotify(string message)
{
   if(!InpLineNotifyEnabled || StringLen(InpLineToken) < 10)
      return;

   string url = "https://notify-api.line.me/api/notify";
   string headers = "Authorization: Bearer " + InpLineToken + "\\r\\nContent-Type: application/x-www-form-urlencoded\\r\\n";
   
   string encodedMessage = "message=" + message;
   char postData[];
   StringToCharArray(encodedMessage, postData, 0, WHOLE_ARRAY, CP_UTF8);
   
   char result[];
   string resultHeaders;
   int timeout = 5000;

   // NOTE: Ensure 'https://notify-api.line.me' is allowed in MT5 Tools -> Options -> Expert Advisors -> WebRequest!
   int res = WebRequest("POST", url, headers, timeout, postData, result, resultHeaders);
   if(res == 200)
   {
      Print("LINE Notify delivered successfully.");
   }
   else
   {
      Print("LINE Notify WebRequest error: ", res, " (Check MT5 Tools->Options->WebRequest permission)");
   }
}

//+------------------------------------------------------------------+
//| Main OnTick function                                             |
//+------------------------------------------------------------------+
void OnTick()
{
   // 1. Manage existing positions every tick
   ManageOpenTrades();

   // 2. Only search for entries on fresh bar formation
   if(!IsNewBar())
      return;

   // 3. Spread filter protection
   long spread = SymbolInfoInteger(_Symbol, SYMBOL_SPREAD);
   if(spread > InpMaxSpreadPoints)
   {
      Print("Spread exceeds limit: ", spread, " > ", InpMaxSpreadPoints, ". Skipping tick.");
      return;
   }

   // 4. One trade per direction limit
   int openBuys = 0, openSells = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      if(m_position.SelectByIndex(i) && m_position.Magic() == InpMagicNumber && m_position.Symbol() == _Symbol)
      {
         if(m_position.PositionType() == POSITION_TYPE_BUY) openBuys++;
         if(m_position.PositionType() == POSITION_TYPE_SELL) openSells++;
      }
   }

   // 5. Evaluate Multi-Pillar Confluence (Requires >= 90% score)
   int signalDir = 0;
   int confidenceScore = EvaluateSignalConfluence(signalDir);

   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   double digits = (double)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);
   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);

   // Execute BUY
   if(signalDir == 1 && openBuys == 0)
   {
      double lot = CalculateOptimalLot(InpStopLossPips);
      double sl = NormalizeDouble(ask - (InpStopLossPips * 10 * point), (int)digits);
      double tp = NormalizeDouble(ask + (InpTakeProfit2Pips * 10 * point), (int)digits);

      if(m_trade.Buy(lot, _Symbol, ask, sl, tp, "AURA Gold AI BUY"))
      {
         Print("Successfully executed BUY order. Lot: ", lot, " Confidence: ", confidenceScore, "%");
         string lineMsg = StringFormat(
            "\\n🟢 [AURA GOLD EA - BUY ORDER EXECUTION]\\n" +
            "🟡 คู่เงิน: XAUUSD\\n" +
            "📈 คำสั่ง: STRONG BUY (ความแม่นยำ %d%%)\\n" +
            "📍 ราคาเข้า: %.2f\\n" +
            "🛑 SL: %.2f (-%d pips)\\n" +
            "🎯 TP1: %.2f (+%d pips)\\n" +
            "🎯 TP2: %.2f (+%d pips)\\n" +
            "💼 ขนาด Lot: %.2f\\n" +
            "🧠 ระบบ SMC + AI Confluence ผ่านเกณฑ์ความแม่นยำสูง",
            confidenceScore, ask, sl, InpStopLossPips,
            ask + (InpTakeProfit1Pips * 10 * point), InpTakeProfit1Pips,
            tp, InpTakeProfit2Pips, lot
         );
         SendLineNotify(lineMsg);
      }
   }
   // Execute SELL
   else if(signalDir == -1 && openSells == 0)
   {
      double lot = CalculateOptimalLot(InpStopLossPips);
      double sl = NormalizeDouble(bid + (InpStopLossPips * 10 * point), (int)digits);
      double tp = NormalizeDouble(bid - (InpTakeProfit2Pips * 10 * point), (int)digits);

      if(m_trade.Sell(lot, _Symbol, bid, sl, tp, "AURA Gold AI SELL"))
      {
         Print("Successfully executed SELL order. Lot: ", lot, " Confidence: ", confidenceScore, "%");
         string lineMsg = StringFormat(
            "\\n🔴 [AURA GOLD EA - SELL ORDER EXECUTION]\\n" +
            "🟡 คู่เงิน: XAUUSD\\n" +
            "📉 คำสั่ง: STRONG SELL (ความแม่นยำ %d%%)\\n" +
            "📍 ราคาเข้า: %.2f\\n" +
            "🛑 SL: %.2f (-%d pips)\\n" +
            "🎯 TP1: %.2f (+%d pips)\\n" +
            "🎯 TP2: %.2f (+%d pips)\\n" +
            "💼 ขนาด Lot: %.2f\\n" +
            "🧠 ระบบ SMC + AI Confluence ผ่านเกณฑ์ความแม่นยำสูง",
            confidenceScore, bid, sl, InpStopLossPips,
            bid - (InpTakeProfit1Pips * 10 * point), InpTakeProfit1Pips,
            tp, InpTakeProfit2Pips, lot
         );
         SendLineNotify(lineMsg);
      }
   }
}
//+------------------------------------------------------------------+
`;
}

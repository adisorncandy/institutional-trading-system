import React, { useState } from 'react';
import { LineAlertLog, TradingSignal } from '../types/trading';
import { Bell, Send, CheckCircle2, Shield, Smartphone, Copy, Check, ExternalLink, RefreshCw } from 'lucide-react';

interface LineAlertCenterProps {
  lineToken: string;
  setLineToken: (token: string) => void;
  webhookUrl: string;
  setWebhookUrl: (url: string) => void;
  alertLogs: LineAlertLog[];
  onSendManualAlert: (customMsg?: string) => Promise<boolean>;
  activeSignal: TradingSignal | null;
}

export const LineAlertCenter: React.FC<LineAlertCenterProps> = ({
  lineToken,
  setLineToken,
  webhookUrl,
  setWebhookUrl,
  alertLogs,
  onSendManualAlert,
  activeSignal,
}) => {
  const [testing, setTesting] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<{ success: boolean; msg: string } | null>(null);

  // Settings
  const [notifyOn90Signals, setNotifyOn90Signals] = useState(true);
  const [notifyOnTpHit, setNotifyOnTpHit] = useState(true);
  const [notifyOnBeLock, setNotifyOnBeLock] = useState(true);
  const [notifyDailySummary, setNotifyDailySummary] = useState(true);

  const handleTestConnection = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await onSendManualAlert();
      if (res) {
        setTestResult({
          success: true,
          msg: lineToken
            ? 'ส่งข้อความทดสอบเข้า LINE เรียบร้อยแล้ว!'
            : 'บันทึกการส่งเข้าห้องแชทจำลอง (LINE Terminal Simulator) เรียบร้อย',
        });
      } else {
        setTestResult({
          success: false,
          msg: 'การส่งล้มเหลว กรุณาตรวจสอบ Token หรือการเชื่อมต่ออินเทอร์เน็ต',
        });
      }
    } catch {
      setTestResult({ success: false, msg: 'เกิดข้อผิดพลาดในการเชื่อมต่อ' });
    } finally {
      setTesting(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      {/* Left Column: Configuration & Controls (7 cols) */}
      <div className="lg:col-span-7 flex flex-col gap-4">
        {/* Token Setup Card */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-3 mb-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#06C755]" />
              <h2 className="text-sm font-semibold text-white">ตั้งค่าการแจ้งเตือน LINE Notify & Webhook</h2>
            </div>
            <a
              href="https://notify-bot.line.me/my/"
              target="_blank"
              rel="noreferrer"
              className="text-xs text-neutral-400 hover:text-white flex items-center gap-1"
            >
              <span>ขอ Line Token ฟรี</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          <div className="flex flex-col gap-3">
            <div>
              <label className="text-xs font-medium text-neutral-300 block mb-1">
                LINE Notify Access Token:
              </label>
              <div className="flex gap-2">
                <input
                  type="password"
                  value={lineToken}
                  onChange={(e) => setLineToken(e.target.value)}
                  placeholder="วาง Access Token จาก line.me หรือใช้โหมดจำลองฟรี"
                  className="flex-1 bg-neutral-950 border border-neutral-800 focus:border-emerald-500 rounded px-3 py-2 text-xs font-mono text-white placeholder-neutral-600 outline-none"
                />
                <button
                  onClick={handleTestConnection}
                  disabled={testing}
                  className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-neutral-950 bg-[#06C755] hover:bg-[#05b34c] disabled:opacity-60 rounded transition-colors whitespace-nowrap"
                >
                  {testing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                  <span>ทดสอบส่ง LINE</span>
                </button>
              </div>
              <p className="text-[11px] text-neutral-500 mt-1">
                *หากยังไม่มี Token ระบบจะจำลองการส่งและการแจ้งเตือนในหน้าจอมือถือจำลองทางด้านขวาแบบ 100% Real-Time
              </p>
            </div>

            {testResult && (
              <div
                className={`p-2.5 rounded text-xs flex items-center gap-2 ${
                  testResult.success
                    ? 'bg-emerald-950/40 border border-emerald-500/40 text-emerald-300'
                    : 'bg-rose-950/40 border border-rose-500/40 text-rose-300'
                }`}
              >
                {testResult.success ? <CheckCircle2 className="w-4 h-4" /> : <Shield className="w-4 h-4" />}
                <span>{testResult.msg}</span>
              </div>
            )}

            {/* Custom Webhook URL Option */}
            <div className="pt-2 border-t border-neutral-800/80">
              <label className="text-xs font-medium text-neutral-400 block mb-1">
                Webhook URL (ทางเลือก สำหรับ Discord, Telegram หรือเซิร์ฟเวอร์ส่วนตัว):
              </label>
              <input
                type="text"
                value={webhookUrl}
                onChange={(e) => setWebhookUrl(e.target.value)}
                placeholder="https://your-webhook-endpoint.com/webhook"
                className="w-full bg-neutral-950 border border-neutral-800 focus:border-emerald-500 rounded px-3 py-2 text-xs font-mono text-white placeholder-neutral-600 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Automated Notification Rules */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 shadow-xl">
          <h3 className="text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-3">
            เงื่อนไขการส่งแจ้งเตือนอัตโนมัติ (EA Alert Trigger Rules)
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            <label className="flex items-center justify-between p-2.5 bg-neutral-950 rounded border border-neutral-800 hover:border-neutral-700 cursor-pointer">
              <span className="text-neutral-300">แจ้งเตือนสัญญาณ 90%+ ทันที</span>
              <input
                type="checkbox"
                checked={notifyOn90Signals}
                onChange={(e) => setNotifyOn90Signals(e.target.checked)}
                className="w-4 h-4 accent-[#06C755] rounded"
              />
            </label>

            <label className="flex items-center justify-between p-2.5 bg-neutral-950 rounded border border-neutral-800 hover:border-neutral-700 cursor-pointer">
              <span className="text-neutral-300">แจ้งเตือนเมื่อชน TP1 / TP2</span>
              <input
                type="checkbox"
                checked={notifyOnTpHit}
                onChange={(e) => setNotifyOnTpHit(e.target.checked)}
                className="w-4 h-4 accent-[#06C755] rounded"
              />
            </label>

            <label className="flex items-center justify-between p-2.5 bg-neutral-950 rounded border border-neutral-800 hover:border-neutral-700 cursor-pointer">
              <span className="text-neutral-300">แจ้งเตือนเมื่อเลื่อน Break-Even กันทุน</span>
              <input
                type="checkbox"
                checked={notifyOnBeLock}
                onChange={(e) => setNotifyOnBeLock(e.target.checked)}
                className="w-4 h-4 accent-[#06C755] rounded"
              />
            </label>

            <label className="flex items-center justify-between p-2.5 bg-neutral-950 rounded border border-neutral-800 hover:border-neutral-700 cursor-pointer">
              <span className="text-neutral-300">สรุปกำไร-ขาดทุนประจำวัน</span>
              <input
                type="checkbox"
                checked={notifyDailySummary}
                onChange={(e) => setNotifyDailySummary(e.target.checked)}
                className="w-4 h-4 accent-[#06C755] rounded"
              />
            </label>
          </div>
        </div>

        {/* Live Alert Logs Feed */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 shadow-xl flex-1">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-2 mb-3">
            <h3 className="text-xs font-semibold text-neutral-300 uppercase tracking-wider">
              ประวัติการส่งแจ้งเตือน ({alertLogs.length} รายการ)
            </h3>
            <span className="text-[11px] text-neutral-500 font-mono">สถานะ: เชื่อมต่อพร้อมส่ง</span>
          </div>

          <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
            {alertLogs.length === 0 ? (
              <div className="text-center py-8 text-neutral-500 text-xs">
                ยังไม่มีการส่งข้อความแจ้งเตือน กดปุ่ม &quot;ทดสอบส่ง LINE&quot; ด้านบนเพื่อเริ่มต้น
              </div>
            ) : (
              alertLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-2.5 bg-neutral-950 rounded border border-neutral-800 text-xs flex flex-col gap-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-amber-400 font-mono text-[11px]">
                      {log.title}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-neutral-500 font-mono">{log.timestamp}</span>
                      <button
                        onClick={() => handleCopy(log.id, log.message)}
                        className="text-neutral-500 hover:text-white"
                        title="คัดลอกข้อความ"
                      >
                        {copiedId === log.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                  <pre className="text-[11px] font-mono text-neutral-300 whitespace-pre-wrap bg-neutral-900/60 p-2 rounded border border-neutral-800/80">
                    {log.message}
                  </pre>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Right Column: Realistic Mobile Phone Mockup (5 cols) */}
      <div className="lg:col-span-5 flex flex-col items-center">
        <div className="w-full max-w-[340px] bg-neutral-950 border-[6px] border-neutral-800 rounded-[36px] overflow-hidden shadow-2xl flex flex-col h-[680px]">
          {/* Phone Top Notch & Status Bar */}
          <div className="bg-[#1f232f] px-5 pt-3 pb-2 flex items-center justify-between text-neutral-300 text-[10px] font-mono">
            <span>21:45</span>
            <div className="w-20 h-3 bg-neutral-900 rounded-full" />
            <span>5G 98%</span>
          </div>

          {/* LINE Header */}
          <div className="bg-[#242b3d] px-4 py-2.5 border-b border-neutral-700/60 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-[#06C755] flex items-center justify-center font-bold text-neutral-950 text-xs shadow">
                LINE
              </div>
              <div>
                <div className="text-xs font-semibold text-white">AURA Gold EA Bot</div>
                <div className="text-[10px] text-emerald-400 font-mono">Official Signal Bot</div>
              </div>
            </div>
            <Bell className="w-4 h-4 text-neutral-400" />
          </div>

          {/* LINE Chat Messages Feed */}
          <div className="flex-1 bg-[#161a24] p-3 overflow-y-auto space-y-3">
            <div className="text-center text-[10px] text-neutral-500 font-mono">วันนี้ 21:30 น.</div>

            {/* Chat Bubble 1: Welcome & Auto-pilot notice */}
            <div className="flex items-start gap-2">
              <div className="w-6 h-6 rounded-full bg-[#06C755] text-neutral-950 font-bold text-[10px] flex items-center justify-center shrink-0">
                A
              </div>
              <div className="bg-[#21293a] text-neutral-200 text-xs p-2.5 rounded-2xl rounded-tl-sm max-w-[85%] border border-neutral-700/50 shadow">
                <div className="font-semibold text-amber-400 text-[11px] mb-1">
                  🤖 AURA Gold EA Pro เชื่อมต่อสำเร็จ
                </div>
                <p className="text-[11px] text-neutral-300">
                  ระบบวิเคราะห์ราคาทองคำ XAUUSD แบบ Real-Time พร้อมแจ้งเตือนเมื่อสัญญาณ Confluence &ge; 90%
                </p>
              </div>
            </div>

            {/* Chat Bubble 2: Active Trade Signal */}
            {activeSignal && (
              <div className="flex items-start gap-2">
                <div className="w-6 h-6 rounded-full bg-[#06C755] text-neutral-950 font-bold text-[10px] flex items-center justify-center shrink-0">
                  A
                </div>
                <div className="bg-[#21293a] text-neutral-100 text-xs p-3 rounded-2xl rounded-tl-sm max-w-[88%] border border-emerald-500/40 shadow-lg">
                  <div className="flex items-center justify-between pb-1.5 border-b border-neutral-700/60 mb-2 font-mono">
                    <span className="font-bold text-emerald-400">
                      {activeSignal.direction === 'BUY' ? '🟢 STRONG BUY' : '🔴 STRONG SELL'}
                    </span>
                    <span className="text-[10px] bg-emerald-950 text-emerald-300 px-1.5 py-0.5 rounded border border-emerald-500/30">
                      แม่นยำ {activeSignal.confidence.toFixed(1)}%
                    </span>
                  </div>

                  <div className="space-y-1 font-mono text-[11px]">
                    <div className="text-white">
                      🟡 คู่เงิน: <span className="text-amber-400 font-bold">XAUUSD (Gold)</span>
                    </div>
                    <div>
                      📍 ราคาเข้า: <span className="font-bold text-white">${activeSignal.entry.toFixed(2)}</span>
                    </div>
                    <div className="text-emerald-400">
                      🎯 TP1: ${activeSignal.tp1.toFixed(2)} (+50 pips)
                    </div>
                    <div className="text-emerald-300">
                      🎯 TP2: ${activeSignal.tp2.toFixed(2)} (+120 pips)
                    </div>
                    <div className="text-rose-400">
                      🛑 SL: ${activeSignal.sl.toFixed(2)} (-60 pips)
                    </div>
                    <div className="text-neutral-400">
                      ⚖️ R:R: {activeSignal.riskReward} · Lot: {activeSignal.suggestedLot}
                    </div>
                  </div>

                  <div className="mt-2 pt-1.5 border-t border-neutral-700/60 text-[10px] text-neutral-400">
                    🧠 เหตุผล: {activeSignal.reasonTh}
                  </div>
                </div>
              </div>
            )}

            {/* Chat Bubble 3: Previous Closed Trade Profit Report */}
            <div className="flex items-start gap-2">
              <div className="w-6 h-6 rounded-full bg-[#06C755] text-neutral-950 font-bold text-[10px] flex items-center justify-center shrink-0">
                A
              </div>
              <div className="bg-[#21293a] text-neutral-200 text-xs p-2.5 rounded-2xl rounded-tl-sm max-w-[85%] border border-neutral-700/50 shadow">
                <div className="font-semibold text-emerald-400 text-[11px] mb-1">
                  💰 [ปิดกำไรสำเร็จ TP1 Hit]
                </div>
                <div className="text-[11px] font-mono space-y-0.5 text-neutral-300">
                  <div>XAUUSD BUY #948201</div>
                  <div>กำไร: <span className="text-emerald-400 font-bold">+$855.00 (+57 pips)</span></div>
                  <div>ระบบเลื่อน Stop Loss มา Break-Even คุ้มครองทุนเรียบร้อย</div>
                </div>
              </div>
            </div>
          </div>

          {/* Phone Bottom Input Bar */}
          <div className="bg-[#242b3d] px-3 py-2 border-t border-neutral-700/60 flex items-center gap-2">
            <input
              disabled
              placeholder="ตอบกลับ AURA Gold Bot..."
              className="flex-1 bg-neutral-900 border border-neutral-700/60 rounded-full px-3 py-1.5 text-xs text-neutral-400 outline-none"
            />
            <button
              onClick={() => onSendManualAlert()}
              className="w-7 h-7 rounded-full bg-[#06C755] flex items-center justify-center text-neutral-950 hover:bg-[#05b34c]"
              title="ส่งคำสั่งทันที"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

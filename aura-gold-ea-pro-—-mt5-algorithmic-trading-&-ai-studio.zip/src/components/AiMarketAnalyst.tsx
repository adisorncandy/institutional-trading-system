import React, { useState } from 'react';
import { Candle, TimeFrame, TradingSignal, TradingSymbol } from '../types/trading';
import { Sparkles, Brain, AlertCircle, TrendingUp, Layers, RefreshCw, Compass, Shield } from 'lucide-react';

interface AiMarketAnalystProps {
  symbol: TradingSymbol;
  currentPrice: number;
  timeframe: TimeFrame;
  candles: Candle[];
  activeSignal: TradingSignal | null;
}

interface AnalysisResult {
  marketRegime: string;
  confidenceScore: number;
  rationaleTh: string;
  actionPlan: string;
  keyLevels: {
    resistance: string;
    support: string;
    pivot: string;
  };
  riskWarningTh: string;
}

export const AiMarketAnalyst: React.FC<AiMarketAnalystProps> = ({
  symbol,
  currentPrice,
  timeframe,
  candles,
  activeSignal,
}) => {
  const [loading, setLoading] = useState(false);
  const isBtc = symbol === 'BTCUSD';

  const [analysis, setAnalysis] = useState<AnalysisResult | null>(() => {
    // Initial rich analysis state
    return {
      marketRegime: isBtc 
        ? 'Bullish Halving Momentum & Institutional Inflow' 
        : 'Bullish Institutional Expansion & Order Block Mitigation',
      confidenceScore: 93.4,
      rationaleTh: isBtc
        ? `ราคาบิตคอยน์ BTCUSD ($${Number(currentPrice).toLocaleString()}) ยืนเหนือเส้นแนวโน้มหลัก EMA 50/200 ในกรอบ ${timeframe} เกิด Bullish Flag พร้อม Smart Money Order Block แข็งแกร่ง สัญญาณ RSI เลี้ยวตัวขึ้นจากแนวรับ 42 สอดคล้องกับพฤติกรรมสถาบันเข้าสะสมวอลุ่ม (Confluence 93%+)`
        : `ราคาทองคำ XAUUSD ในกรอบเวลา ${timeframe} เกิดการกวาดสภาพคล่อง (Liquidity Sweep) บริเวณ Demand Zone พร้อมการ Rejection ด้วยแท่งเทียน Pin Bar ชัดเจน เส้น EMA 20 ตัดขึ้นเหนือ EMA 50 และ RSI เกิด Bullish Divergence ตามหลัก Smart Money Concepts (SMC)`,
      actionPlan: isBtc
        ? `เข้าคำสั่ง BUY โซน $${Number(currentPrice).toLocaleString()} เป้าหมาย TP1 +$500 ปิดกำไร 50% แล้วเลื่อน Stop Loss มากันทุน (BE) เป้าหมายรันเทรนด์ TP2 +$1,200 ตัดขาดทุน SL -$450`
        : `เข้าคำสั่ง BUY โซน $${Number(currentPrice).toFixed(2)} เป้าหมาย TP1 +50 pips ปิดทำกำไร 50% แล้วเลื่อน Stop Loss มากันทุน (Break-Even) และถือเป้า TP2 +120 pips ตัดขาดทุน SL -60 pips`,
      keyLevels: {
        resistance: (currentPrice + (isBtc ? 750 : 14.5)).toFixed(isBtc ? 1 : 2),
        support: (currentPrice - (isBtc ? 680 : 11.8)).toFixed(isBtc ? 1 : 2),
        pivot: currentPrice.toFixed(isBtc ? 1 : 2),
      },
      riskWarningTh: isBtc
        ? 'บิตคอยน์มีความผันผวนสูงตามแรงเข้าซื้อ Spot ETF และการตัดสินใจอัตราดอกเบี้ย Macro แนะนำบริหารขนาดไม้ (Position Sizing) เสมอ'
        : 'โปรดระมัดระวังช่วงเวลาเปิดตลาดนิวยอร์ก 19:30-21:30 น. ซึ่งมีแนวโน้มความผันผวนของราคาทองคำสูงจากตัวเลขเศรษฐกิจสหรัฐฯ (USD Index & Fed Interest Rate Expectations)',
    };
  });

  const handleRunAnalysis = async () => {
    setLoading(true);
    try {
      const latest = candles[candles.length - 1];
      const res = await fetch('/api/ai-analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          symbol,
          currentPrice,
          timeframe,
          signalType: activeSignal?.direction || 'BUY',
          indicators: {
            ema20: latest?.ema20,
            ema50: latest?.ema50,
            ema200: latest?.ema200,
            rsi: latest?.rsi,
          },
          recentCandles: candles.slice(-5),
        }),
      });

      const data = await res.json();
      if (data.success && data.analysis) {
        setAnalysis(data.analysis);
      }
    } catch (err) {
      console.error('Failed to analyze:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-5">
      {/* Header card */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-amber-400/10 border border-amber-400/20 flex items-center justify-center text-amber-400">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-white">
              AI Market Structure & Order Flow Intelligence
            </h2>
            <p className="text-xs text-neutral-400">
              วิเคราะห์พฤติกรรมเจ้ามือ (Smart Money Concepts), โซนสภาพคล่อง Liquidity และจังหวะความแม่นยำสูง
            </p>
          </div>
        </div>

        <button
          onClick={handleRunAnalysis}
          disabled={loading}
          className="flex items-center gap-2 px-4 py-2 text-xs font-bold text-neutral-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 rounded transition-all shadow"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>{loading ? 'AI กำลังประมวลผล...' : 'วิเคราะห์โครงสร้างตลาดทันที'}</span>
        </button>
      </div>

      {analysis && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Main Diagnosis (8 cols) */}
          <div className="lg:col-span-8 flex flex-col gap-4">
            {/* Market Regime */}
            <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg shadow-xl">
              <div className="flex items-center justify-between border-b border-neutral-800 pb-2.5 mb-3">
                <div className="flex items-center gap-2 text-xs text-neutral-400">
                  <Compass className="w-4 h-4 text-cyan-400" />
                  <span className="uppercase tracking-wider">Market Regime สภาวะตลาดปัจจุบัน</span>
                </div>
                <div className="flex items-center gap-2 font-mono text-xs text-amber-400 font-bold">
                  <span>ความแม่นยำระบบ: {analysis.confidenceScore}%</span>
                </div>
              </div>

              <div className="text-base font-bold text-white mb-2">
                {analysis.marketRegime}
              </div>

              <p className="text-xs text-neutral-300 leading-relaxed bg-neutral-950/60 p-3 rounded border border-neutral-800/80">
                {analysis.rationaleTh}
              </p>
            </div>

            {/* Strategic Action Plan */}
            <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg shadow-xl">
              <div className="flex items-center gap-2 text-xs text-emerald-400 mb-2 font-semibold">
                <TrendingUp className="w-4 h-4" />
                <span>แผนการเทรดที่แนะนำ (Actionable Execution Strategy)</span>
              </div>
              <p className="text-xs text-neutral-200 leading-relaxed font-mono bg-neutral-950 p-3 rounded border border-neutral-800">
                {analysis.actionPlan}
              </p>
            </div>

            {/* Risk Management Warning */}
            <div className="p-4 bg-rose-950/20 border border-rose-900/40 rounded-lg">
              <div className="flex items-center gap-2 text-xs text-rose-400 mb-1.5 font-semibold">
                <Shield className="w-4 h-4" />
                <span>ข้อควรระวังความเสี่ยง & ข่าวเศรษฐกิจ</span>
              </div>
              <p className="text-xs text-neutral-300">{analysis.riskWarningTh}</p>
            </div>
          </div>

          {/* Key Support/Resistance & Confluence Metrics (4 cols) */}
          <div className="lg:col-span-4 flex flex-col gap-4">
            <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg shadow-xl">
              <h3 className="text-xs font-semibold text-neutral-300 uppercase tracking-wider border-b border-neutral-800 pb-2 mb-3">
                แนวรับ - แนวต้านสำคัญ (Institutional Levels)
              </h3>

              <div className="space-y-3 font-mono text-xs">
                <div className="flex items-center justify-between p-2.5 bg-neutral-950 rounded border border-neutral-800">
                  <span className="text-rose-400">แนวต้านสำคัญ (Resistance):</span>
                  <span className="font-bold text-white">${analysis.keyLevels.resistance}</span>
                </div>
                <div className="flex items-center justify-between p-2.5 bg-neutral-950 rounded border border-neutral-800">
                  <span className="text-amber-400">Pivot จุดกึ่งกลาง:</span>
                  <span className="font-bold text-white">${analysis.keyLevels.pivot}</span>
                </div>
                <div className="flex items-center justify-between p-2.5 bg-neutral-950 rounded border border-neutral-800">
                  <span className="text-emerald-400">แนวรับหลัก (Support Demand):</span>
                  <span className="font-bold text-white">${analysis.keyLevels.support}</span>
                </div>
              </div>
            </div>

            <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg shadow-xl">
              <h3 className="text-xs font-semibold text-neutral-300 uppercase tracking-wider border-b border-neutral-800 pb-2 mb-3">
                หลักเกณฑ์ AI 90%++ Precision
              </h3>

              <ul className="space-y-2 text-xs text-neutral-400">
                <li className="flex items-start gap-2">
                  <span className="text-amber-400 font-bold">1.</span>
                  <span>เทรดตามโครงสร้างสถาบันรายใหญ่ (Institutional Higher Timeframe Bias)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-400 font-bold">2.</span>
                  <span>รอการล้างสภาพคล่อง (Liquidity Sweep) ก่อน ไม่เข้าที่กลางทาง</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-400 font-bold">3.</span>
                  <span>บังคับเลื่อน Break-Even ทันทีเมื่อกำไร +20 pips ป้องกันความเสี่ยงเป็นศูนย์</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-400 font-bold">4.</span>
                  <span>ฐานข้อมูลบันทึกทุกไม้เพื่อปรับค่าน้ำหนัก &quot;ยิ่งใช้ยิ่งฉลาด&quot;</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

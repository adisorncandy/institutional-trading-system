import React from 'react';
import { Activity, Bell, Cpu, Download, Sparkles, Terminal, Radio } from 'lucide-react';
import { GoldDataSource } from './ChartTerminal';
import { TradingSymbol } from '../types/trading';

interface HeaderProps {
  activeTab: 'terminal' | 'signals' | 'line' | 'database' | 'mql5' | 'analyst';
  setActiveTab: (tab: 'terminal' | 'signals' | 'line' | 'database' | 'mql5' | 'analyst') => void;
  currentPrice: number;
  priceChange: number;
  autoPilot: boolean;
  setAutoPilot: (val: boolean) => void;
  unreadAlerts: number;
  dataSource?: GoldDataSource;
  symbol?: TradingSymbol;
  setSymbol?: (s: TradingSymbol) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  currentPrice,
  priceChange,
  autoPilot,
  setAutoPilot,
  unreadAlerts,
  dataSource = 'binance',
  symbol = 'XAUUSD',
  setSymbol,
}) => {
  const isPositive = priceChange >= 0;
  const isBtc = symbol === 'BTCUSD';

  return (
    <header className="sticky top-0 z-50 flex items-center justify-between px-4 lg:px-6 py-3 border-b border-neutral-800 bg-neutral-950/95 backdrop-blur-md">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3">
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('terminal');
          }}
          className="text-base font-semibold tracking-tight text-white flex items-center gap-2 hover:text-amber-400 transition-colors"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>AURA Quantitative EA Pro</span>
        </a>
        <span className="hidden sm:inline text-xs text-neutral-500">·</span>
        <span className="hidden sm:inline text-xs font-mono text-neutral-400">MT5 XAUUSD & BTCUSD AI v5.2</span>
      </div>

      {/* Zone 2: Navigation Links */}
      <nav className="hidden md:flex items-center gap-1 lg:gap-2 text-xs font-medium text-neutral-400">
        <button
          onClick={() => setActiveTab('terminal')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'terminal'
              ? 'bg-neutral-800 text-amber-400 font-semibold shadow-sm'
              : 'hover:text-neutral-200 hover:bg-neutral-900'
          }`}
        >
          <Terminal className="w-3.5 h-3.5" />
          <span>กราฟ & เทอร์มินอล</span>
        </button>

        <button
          onClick={() => setActiveTab('signals')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'signals'
              ? 'bg-neutral-800 text-amber-400 font-semibold shadow-sm'
              : 'hover:text-neutral-200 hover:bg-neutral-900'
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>สัญญาณ 90%+ AI</span>
        </button>

        <button
          onClick={() => setActiveTab('line')}
          className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'line'
              ? 'bg-neutral-800 text-amber-400 font-semibold shadow-sm'
              : 'hover:text-neutral-200 hover:bg-neutral-900'
          }`}
        >
          <Bell className="w-3.5 h-3.5" />
          <span>LINE Alert บอท</span>
          {unreadAlerts > 0 && (
            <span className="ml-1 px-1.5 py-0.2 bg-emerald-500 text-neutral-950 font-mono text-[10px] font-bold rounded-full">
              {unreadAlerts}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('database')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'database'
              ? 'bg-neutral-800 text-amber-400 font-semibold shadow-sm'
              : 'hover:text-neutral-200 hover:bg-neutral-900'
          }`}
        >
          <Cpu className="w-3.5 h-3.5" />
          <span>ฐานข้อมูล ยิ่งใช้ยิ่งฉลาด</span>
        </button>

        <button
          onClick={() => setActiveTab('analyst')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'analyst'
              ? 'bg-neutral-800 text-amber-400 font-semibold shadow-sm'
              : 'hover:text-neutral-200 hover:bg-neutral-900'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>AI วิเคราะห์ตลาด</span>
        </button>

        <button
          onClick={() => setActiveTab('mql5')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'mql5'
              ? 'bg-neutral-800 text-amber-400 font-semibold shadow-sm'
              : 'hover:text-neutral-200 hover:bg-neutral-900'
          }`}
        >
          <Download className="w-3.5 h-3.5" />
          <span>โค้ด EA .mq5 & ติดตั้ง</span>
        </button>
      </nav>

      {/* Zone 3: Live Price Quote & Action Controls */}
      <div className="flex items-center gap-3">
        {/* Live Ticker with Open-Source Feed indicator */}
        <div className="flex items-center gap-2 px-3 py-1 rounded bg-neutral-900 border border-neutral-800 text-xs">
          <div className="flex items-center gap-1.5">
            <span
              className={`w-2 h-2 rounded-full ${
                dataSource !== 'simulation'
                  ? 'bg-emerald-400 animate-pulse'
                  : 'bg-amber-400'
              }`}
            />
            <span className={`font-mono font-bold ${isBtc ? 'text-orange-400' : 'text-amber-400'}`}>
              {symbol}:
            </span>
          </div>
          <span className="font-mono font-bold text-white tabular-nums tracking-wide">
            ${currentPrice.toFixed(isBtc ? 1 : 2)}
          </span>
          <span
            className={`font-mono text-[11px] tabular-nums ${
              isPositive ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {isPositive ? '+' : ''}
            {priceChange.toFixed(2)}%
          </span>
          <span className="hidden lg:inline text-[9px] font-mono px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-300 border border-neutral-700">
            {dataSource === 'binance'
              ? 'Binance'
              : dataSource === 'yahoo'
              ? 'Yahoo'
              : 'Simulator'}
          </span>
        </div>

        {/* Auto-Pilot Toggle Button */}
        <button
          onClick={() => setAutoPilot(!autoPilot)}
          title="สลับโหมด Auto-Pilot ซื้อขายและส่งไลน์อัตโนมัติ"
          className={`hidden sm:flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded border transition-all whitespace-nowrap ${
            autoPilot
              ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-400 shadow-sm shadow-emerald-950'
              : 'bg-neutral-900 border-neutral-700 text-neutral-400 hover:text-white'
          }`}
        >
          <span
            className={`w-1.5 h-1.5 rounded-full ${
              autoPilot ? 'bg-emerald-400 animate-ping' : 'bg-neutral-600'
            }`}
          />
          <span>{autoPilot ? 'Auto-Pilot: เปิด' : 'Auto-Pilot: พัก'}</span>
        </button>

        {/* Quick MT5 Download Button */}
        <button
          onClick={() => setActiveTab('mql5')}
          className="px-3 py-1.5 text-xs font-semibold text-neutral-950 bg-gradient-to-r from-amber-400 to-amber-500 rounded hover:from-amber-300 hover:to-amber-400 transition-all shadow-sm whitespace-nowrap"
        >
          ดาวน์โหลด EA MT5
        </button>
      </div>
    </header>
  );
};

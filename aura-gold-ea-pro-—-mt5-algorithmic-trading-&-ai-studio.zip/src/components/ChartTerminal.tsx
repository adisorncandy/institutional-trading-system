import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Candle, TimeFrame, TradingSignal, TradingSymbol } from '../types/trading';
import { Eye, Layers, Play, Pause, FastForward, Zap, Maximize2, ShieldAlert, Globe, RefreshCw, Radio, CheckCircle2, Coins, Focus, ZoomIn, ZoomOut, MoveVertical, MoveHorizontal, RotateCcw, Minus, Plus, Sliders } from 'lucide-react';

export type GoldDataSource = 'binance' | 'yahoo' | 'simulation';

interface ChartTerminalProps {
  symbol: TradingSymbol;
  setSymbol: (s: TradingSymbol) => void;
  candles: Candle[];
  timeframe: TimeFrame;
  setTimeframe: (tf: TimeFrame) => void;
  activeSignal: TradingSignal | null;
  isRunning: boolean;
  setIsRunning: (running: boolean) => void;
  tickSpeed: number;
  setTickSpeed: (speed: number) => void;
  onSimulateSpike: () => void;
  onQuickTrade: (type: 'BUY' | 'SELL') => void;
  dataSource: GoldDataSource;
  setDataSource: (source: GoldDataSource) => void;
  isFetchingLive: boolean;
  lastLiveSyncTime: string;
  liveLatency: number | null;
  onRefreshLive: () => void;
  wsConnected?: boolean;
  wsTickCount?: number;
  tickDirection?: 'UP' | 'DOWN' | 'EQUAL';
  liveBid?: number | null;
  liveAsk?: number | null;
}

export const ChartTerminal: React.FC<ChartTerminalProps> = ({
  symbol,
  setSymbol,
  candles,
  timeframe,
  setTimeframe,
  activeSignal,
  isRunning,
  setIsRunning,
  tickSpeed,
  setTickSpeed,
  onSimulateSpike,
  onQuickTrade,
  dataSource,
  setDataSource,
  isFetchingLive,
  lastLiveSyncTime,
  liveLatency,
  onRefreshLive,
  wsConnected = false,
  wsTickCount = 0,
  tickDirection = 'EQUAL',
  liveBid = null,
  liveAsk = null,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [hoverData, setHoverData] = useState<{
    candle: Candle;
    x: number;
    y: number;
  } | null>(null);

  // Overlay toggles
  const [showEMAs, setShowEMAs] = useState(true);
  const [showSMC, setShowSMC] = useState(true);
  const [showLevels, setShowLevels] = useState(true);
  const [showRSI, setShowRSI] = useState(true);
  const [scaleMode, setScaleMode] = useState<'candles' | 'full'>('candles');

  // Stretch & Scale State (แนวนอน & แนวตั้ง)
  const [visibleCandleCount, setVisibleCandleCount] = useState<number>(45); // Horizontal Stretch (15 - 90 bars)
  const [verticalStretch, setVerticalStretch] = useState<number>(1.0); // Vertical Stretch (0.4x - 3.5x)
  const [verticalPan, setVerticalPan] = useState<number>(0); // Vertical Pan Offset

  // Axis dragging state
  const [isDraggingAxis, setIsDraggingAxis] = useState<boolean>(false);
  const dragStartYRef = useRef<number>(0);
  const dragStartStretchRef = useRef<number>(1.0);
  const [isHoveringAxis, setIsHoveringAxis] = useState<boolean>(false);

  // Real-Time Clock & Candle Countdown Synchronization
  const [realTimeClock, setRealTimeClock] = useState<string>(() =>
    new Date().toLocaleTimeString('th-TH', { hour12: false })
  );
  const [candleCountdown, setCandleCountdown] = useState<string>('00:00');

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setRealTimeClock(now.toLocaleTimeString('th-TH', { hour12: false }));

      const minutes = now.getMinutes();
      const seconds = now.getSeconds();
      const currentSeconds = minutes * 60 + seconds;

      let tfSeconds = 300; // default M5
      if (timeframe === 'M1') tfSeconds = 60;
      else if (timeframe === 'M5') tfSeconds = 300;
      else if (timeframe === 'M15') tfSeconds = 900;
      else if (timeframe === 'H1') tfSeconds = 3600;
      else if (timeframe === 'H4') tfSeconds = 14400;
      else if (timeframe === 'D1') tfSeconds = 86400;

      const remaining = tfSeconds - (currentSeconds % tfSeconds);
      const remMin = Math.floor(remaining / 60);
      const remSec = remaining % 60;
      setCandleCountdown(`${remMin.toString().padStart(2, '0')}:${remSec.toString().padStart(2, '0')}`);
    };

    updateClock();
    const timer = setInterval(updateClock, 1000);
    return () => clearInterval(timer);
  }, [timeframe]);

  const drawChart = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || candles.length === 0) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high DPI
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    // Clear background
    ctx.fillStyle = '#0a0a0c';
    ctx.fillRect(0, 0, width, height);

    // Chart Dimensions
    const rsiHeight = showRSI ? 90 : 0;
    const paddingBottom = rsiHeight + 25;
    const paddingTop = 25;
    const paddingRight = 75; // for price axis
    const mainChartHeight = height - paddingBottom - paddingTop;

    // Visible candles count
    const visibleCount = Math.min(candles.length, visibleCandleCount);
    const visibleCandles = candles.slice(-visibleCount);

    // 1. Calculate candle bounds from actual price action
    let candleMin = Infinity;
    let candleMax = -Infinity;
    visibleCandles.forEach((c) => {
      if (c.low < candleMin) candleMin = c.low;
      if (c.high > candleMax) candleMax = c.high;
    });

    if (candleMin === Infinity || candleMax === -Infinity) {
      candleMin = symbol === 'BTCUSD' ? 84000 : 2680;
      candleMax = symbol === 'BTCUSD' ? 85000 : 2690;
    }

    // Minimum vertical price spread so candles never collapse into a flat horizontal line on small timeframes
    const minSpread = symbol === 'BTCUSD' ? 45.0 : 1.8;
    let candleSpread = candleMax - candleMin;
    if (candleSpread < minSpread) {
      const mid = (candleMax + candleMin) / 2;
      candleMin = mid - minSpread / 2;
      candleMax = mid + minSpread / 2;
      candleSpread = minSpread;
    }

    let minPrice = candleMin;
    let maxPrice = candleMax;

    // Include EMAs if within realistic proximity (at most 35% outside candle range)
    if (showEMAs) {
      visibleCandles.forEach((c) => {
        [c.ema20, c.ema50].forEach((ema) => {
          if (ema) {
            if (ema < minPrice && (minPrice - ema) < candleSpread * 0.35) {
              minPrice = ema;
            }
            if (ema > maxPrice && (ema - maxPrice) < candleSpread * 0.35) {
              maxPrice = ema;
            }
          }
        });
      });
    }

    // TP/SL Levels scaling logic
    if (scaleMode === 'full' && showLevels && activeSignal && activeSignal.direction !== 'WAIT') {
      // In Full View: scale encompasses all target levels
      minPrice = Math.min(minPrice, activeSignal.sl, activeSignal.tp1, activeSignal.tp2);
      maxPrice = Math.max(maxPrice, activeSignal.sl, activeSignal.tp1, activeSignal.tp2);
    } else {
      // In Auto-Fit Mode (Default): Candle action has priority!
      // Only softly include Entry if within 40% of candle bounds
      if (showLevels && activeSignal && activeSignal.direction !== 'WAIT') {
        const entry = activeSignal.entry;
        if (Math.abs(entry - (candleMax + candleMin) / 2) < candleSpread * 0.4) {
          minPrice = Math.min(minPrice, entry);
          maxPrice = Math.max(maxPrice, entry);
        }
      }
    }

    const priceBuffer = (maxPrice - minPrice) * 0.12 || 1;
    minPrice -= priceBuffer;
    maxPrice += priceBuffer;

    // Apply Vertical Stretch (ถ่างแนวตั้ง) & Pan
    const centerPrice = ((candleMin + candleMax) / 2) + verticalPan;
    const baseRange = maxPrice - minPrice;
    const adjustedRange = Math.max(minSpread, baseRange / verticalStretch);
    minPrice = centerPrice - adjustedRange / 2;
    maxPrice = centerPrice + adjustedRange / 2;
    const priceRange = maxPrice - minPrice;

    // Helper to calculate Y coordinate from price
    const getY = (price: number) => {
      return paddingTop + (1 - (price - minPrice) / priceRange) * mainChartHeight;
    };

    // Calculate Candle Slot Width
    const chartWidth = width - paddingRight;
    const candleSlotWidth = chartWidth / visibleCount;
    const candleBodyWidth = Math.max(2, candleSlotWidth * 0.65);

    // Axis divider line & hover / dragging highlight
    ctx.strokeStyle = '#27272a';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(chartWidth, 0);
    ctx.lineTo(chartWidth, height);
    ctx.stroke();

    if (isDraggingAxis || isHoveringAxis) {
      ctx.fillStyle = 'rgba(245, 158, 11, 0.08)';
      ctx.fillRect(chartWidth, 0, paddingRight, mainChartHeight + paddingTop);

      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(chartWidth + 4, 3, paddingRight - 8, 16);
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`↕ ${Math.round(verticalStretch * 100)}%`, chartWidth + paddingRight / 2, 14);
      ctx.textAlign = 'left';
    }

    // 1. Draw Grid Lines
    ctx.strokeStyle = '#1e2029';
    ctx.lineWidth = 1;
    const priceSteps = 6;
    for (let i = 0; i <= priceSteps; i++) {
      const p = minPrice + (i / priceSteps) * priceRange;
      const y = getY(p);

      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(chartWidth, y);
      ctx.stroke();

      // Price Label
      ctx.fillStyle = '#71717a';
      ctx.font = '10px JetBrains Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(p.toFixed(symbol === 'BTCUSD' ? 1 : 2), chartWidth + 6, y + 3);
    }

    // 2. Draw SMC Order Blocks & Liquidity Sweeps
    if (showSMC) {
      visibleCandles.forEach((c, idx) => {
        const x = idx * candleSlotWidth + candleSlotWidth / 2;
        if (c.orderBlock) {
          const topY = getY(c.orderBlock.top);
          const bottomY = getY(c.orderBlock.bottom);
          const blockH = Math.max(4, bottomY - topY);

          ctx.fillStyle =
            c.orderBlock.type === 'BULLISH'
              ? 'rgba(16, 185, 129, 0.12)'
              : 'rgba(239, 68, 68, 0.12)';
          ctx.fillRect(x - candleSlotWidth * 2, topY, candleSlotWidth * 8, blockH);

          ctx.strokeStyle =
            c.orderBlock.type === 'BULLISH'
              ? 'rgba(16, 185, 129, 0.4)'
              : 'rgba(239, 68, 68, 0.4)';
          ctx.setLineDash([3, 3]);
          ctx.strokeRect(x - candleSlotWidth * 2, topY, candleSlotWidth * 8, blockH);
          ctx.setLineDash([]);

          ctx.fillStyle = c.orderBlock.type === 'BULLISH' ? '#10b981' : '#ef4444';
          ctx.font = '9px monospace';
          ctx.fillText(
            c.orderBlock.type === 'BULLISH' ? 'Demand OB' : 'Supply OB',
            x - candleSlotWidth * 2 + 4,
            topY - 3
          );
        }
      });
    }

    // 3. Draw Candlesticks
    visibleCandles.forEach((c, idx) => {
      const xCenter = idx * candleSlotWidth + candleSlotWidth / 2;
      const isGreen = c.close >= c.open;
      const openY = getY(c.open);
      const closeY = getY(c.close);
      const highY = getY(c.high);
      const lowY = getY(c.low);

      const bodyTop = Math.min(openY, closeY);
      const bodyHeight = Math.max(1.5, Math.abs(openY - closeY));

      // Wick
      ctx.strokeStyle = isGreen ? '#10b981' : '#f43f5e';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(xCenter, highY);
      ctx.lineTo(xCenter, lowY);
      ctx.stroke();

      // Body
      ctx.fillStyle = isGreen ? '#10b981' : '#f43f5e';
      ctx.fillRect(xCenter - candleBodyWidth / 2, bodyTop, candleBodyWidth, bodyHeight);
    });

    // 4. Draw EMAs
    if (showEMAs) {
      const drawEmaLine = (key: 'ema20' | 'ema50' | 'ema200', color: string, width: number) => {
        ctx.strokeStyle = color;
        ctx.lineWidth = width;
        ctx.beginPath();
        let started = false;

        visibleCandles.forEach((c, idx) => {
          const val = c[key];
          if (val) {
            const x = idx * candleSlotWidth + candleSlotWidth / 2;
            const y = getY(val);
            if (!started) {
              ctx.moveTo(x, y);
              started = true;
            } else {
              ctx.lineTo(x, y);
            }
          }
        });
        ctx.stroke();
      };

      drawEmaLine('ema20', '#f59e0b', 1.6); // Amber EMA 20
      drawEmaLine('ema50', '#06b6d4', 1.4); // Cyan EMA 50
      drawEmaLine('ema200', '#8b5cf6', 1.2); // Purple EMA 200
    }

    // 5. Draw Active Signal Levels (Entry, TP1, TP2, SL)
    if (showLevels && activeSignal && activeSignal.direction !== 'WAIT') {
      const drawPriceLevel = (
        price: number,
        label: string,
        color: string,
        pips?: string
      ) => {
        // Handle off-screen target levels with a clean pinned edge badge
        if (price > maxPrice) {
          ctx.fillStyle = color;
          ctx.fillRect(chartWidth - 110, paddingTop + 2, 105, 18);
          ctx.fillStyle = '#09090b';
          ctx.font = 'bold 9px monospace';
          ctx.fillText(`▲ ${label} ${price.toFixed(symbol === 'BTCUSD' ? 1 : 2)}`, chartWidth - 105, paddingTop + 14);
          return;
        }

        if (price < minPrice) {
          const bottomY = paddingTop + mainChartHeight - 20;
          ctx.fillStyle = color;
          ctx.fillRect(chartWidth - 110, bottomY, 105, 18);
          ctx.fillStyle = '#09090b';
          ctx.font = 'bold 9px monospace';
          ctx.fillText(`▼ ${label} ${price.toFixed(symbol === 'BTCUSD' ? 1 : 2)}`, chartWidth - 105, bottomY + 12);
          return;
        }

        const y = getY(price);
        ctx.strokeStyle = color;
        ctx.lineWidth = 1.2;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(chartWidth, y);
        ctx.stroke();
        ctx.setLineDash([]);

        // Right axis tag
        ctx.fillStyle = color;
        ctx.fillRect(chartWidth, y - 9, paddingRight - 4, 18);
        ctx.fillStyle = '#09090b';
        ctx.font = 'bold 9px monospace';
        ctx.fillText(`${label} ${price.toFixed(symbol === 'BTCUSD' ? 1 : 2)}`, chartWidth + 4, y + 3);

        // Chart tag with pips
        if (pips) {
          ctx.fillStyle = color;
          ctx.font = '10px JetBrains Mono, monospace';
          ctx.fillText(`${label} (${pips})`, 10, y - 4);
        }
      };

      drawPriceLevel(activeSignal.entry, 'ENTRY', '#e4e4e7');
      drawPriceLevel(activeSignal.tp1, 'TP1', '#10b981', symbol === 'BTCUSD' ? '+500 pts' : '+50 pips');
      drawPriceLevel(activeSignal.tp2, 'TP2', '#34d399', symbol === 'BTCUSD' ? '+1200 pts' : '+120 pips');
      drawPriceLevel(activeSignal.sl, 'SL', '#ef4444', symbol === 'BTCUSD' ? '-450 pts' : '-60 pips');
    }

    // 6. Draw Current Live Price Tag with Real-time Tick Glow Flash
    const latest = visibleCandles[visibleCandles.length - 1];
    if (latest) {
      const latestY = getY(latest.close);
      const isTickUp = tickDirection === 'UP';
      const isTickDown = tickDirection === 'DOWN';
      const priceColor = isTickUp ? '#10b981' : isTickDown ? '#ef4444' : '#f59e0b';

      ctx.strokeStyle = priceColor;
      ctx.lineWidth = isTickUp || isTickDown ? 1.8 : 1;
      ctx.setLineDash([2, 2]);
      ctx.beginPath();
      ctx.moveTo(0, latestY);
      ctx.lineTo(chartWidth, latestY);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = priceColor;
      ctx.fillRect(chartWidth, latestY - 10, paddingRight - 4, 20);
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 10px JetBrains Mono, monospace';
      const tickSymbol = isTickUp ? '▲ ' : isTickDown ? '▼ ' : '';
      ctx.fillText(
        `${tickSymbol}${latest.close.toFixed(symbol === 'BTCUSD' ? 1 : 2)}`,
        chartWidth + (isTickUp || isTickDown ? 3 : 6),
        latestY + 4
      );
    }

    // 7. Draw RSI Subchart
    if (showRSI) {
      const rsiTop = height - rsiHeight;

      // Divider
      ctx.strokeStyle = '#27272a';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, rsiTop);
      ctx.lineTo(width, rsiTop);
      ctx.stroke();

      // RSI Label & Level Lines
      ctx.fillStyle = '#71717a';
      ctx.font = '10px JetBrains Mono, monospace';
      ctx.fillText('RSI (14) Dynamic', 10, rsiTop + 16);

      const rsiToY = (val: number) => {
        return rsiTop + 20 + (1 - val / 100) * (rsiHeight - 35);
      };

      // 70 & 30 Lines
      [70, 30].forEach((level) => {
        const y = rsiToY(level);
        ctx.strokeStyle = '#27272a';
        ctx.setLineDash([2, 4]);
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(chartWidth, y);
        ctx.stroke();
        ctx.setLineDash([]);

        ctx.fillStyle = '#52525b';
        ctx.fillText(level.toString(), chartWidth + 6, y + 3);
      });

      // RSI Curve
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      let started = false;

      visibleCandles.forEach((c, idx) => {
        if (c.rsi !== undefined) {
          const x = idx * candleSlotWidth + candleSlotWidth / 2;
          const y = rsiToY(c.rsi);
          if (!started) {
            ctx.moveTo(x, y);
            started = true;
          } else {
            ctx.lineTo(x, y);
          }
        }
      });
      ctx.stroke();

      // Latest RSI value
      if (latest && latest.rsi !== undefined) {
        ctx.fillStyle = latest.rsi > 70 ? '#ef4444' : latest.rsi < 30 ? '#10b981' : '#f59e0b';
        ctx.font = 'bold 11px JetBrains Mono, monospace';
        ctx.fillText(latest.rsi.toFixed(1), 110, rsiTop + 16);
      }
    }

    // 7.5. Draw Real-Time Bottom Time Axis
    const timeAxisY = paddingTop + mainChartHeight;
    ctx.strokeStyle = '#27272a';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, timeAxisY);
    ctx.lineTo(chartWidth, timeAxisY);
    ctx.stroke();

    // Time axis background strip
    ctx.fillStyle = '#09090b';
    ctx.fillRect(0, timeAxisY + 1, chartWidth, 24);

    // Calculate step interval so labels don't collide
    const labelStep = Math.max(1, Math.floor(visibleCount / 6));
    ctx.font = '10px JetBrains Mono, monospace';
    ctx.textAlign = 'center';

    visibleCandles.forEach((c, idx) => {
      if (idx % labelStep === 0 || idx === visibleCandles.length - 1) {
        const x = idx * candleSlotWidth + candleSlotWidth / 2;
        const dateObj = new Date(c.time);

        let timeStr = '';
        if (timeframe === 'D1') {
          timeStr = dateObj.toLocaleDateString('th-TH', { day: 'numeric', month: 'short' });
        } else {
          timeStr = dateObj.toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', hour12: false });
        }

        // Small tick mark
        ctx.beginPath();
        ctx.moveTo(x, timeAxisY);
        ctx.lineTo(x, timeAxisY + 4);
        ctx.strokeStyle = '#3f3f46';
        ctx.stroke();

        // Label
        ctx.fillStyle = idx === visibleCandles.length - 1 ? '#f59e0b' : '#71717a';
        ctx.fillText(timeStr, x, timeAxisY + 15);
      }
    });

    // 8. Crosshair if mouse is hovering
    if (hoverData) {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
      ctx.lineWidth = 0.8;
      ctx.setLineDash([3, 3]);

      // Vertical line
      ctx.beginPath();
      ctx.moveTo(hoverData.x, 0);
      ctx.lineTo(hoverData.x, height);
      ctx.stroke();

      // Horizontal line
      ctx.beginPath();
      ctx.moveTo(0, hoverData.y);
      ctx.lineTo(chartWidth, hoverData.y);
      ctx.stroke();
      ctx.setLineDash([]);

      // Price Tag on Right Axis for Crosshair
      const hoverPrice = minPrice + (1 - (hoverData.y - paddingTop) / mainChartHeight) * priceRange;
      if (hoverData.y >= paddingTop && hoverData.y <= paddingTop + mainChartHeight) {
        ctx.fillStyle = '#27272a';
        ctx.fillRect(chartWidth, hoverData.y - 9, paddingRight - 4, 18);
        ctx.strokeStyle = '#71717a';
        ctx.strokeRect(chartWidth, hoverData.y - 9, paddingRight - 4, 18);
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 9px JetBrains Mono, monospace';
        ctx.textAlign = 'left';
        ctx.fillText(hoverPrice.toFixed(symbol === 'BTCUSD' ? 1 : 2), chartWidth + 6, hoverData.y + 3);
      }

      // Time Tag on Bottom Axis for Crosshair
      const dateObj = new Date(hoverData.candle.time);
      const timeTag =
        timeframe === 'D1'
          ? dateObj.toLocaleDateString('th-TH', { day: 'numeric', month: 'short' })
          : dateObj.toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });

      const tagWidth = 68;
      const tagX = Math.max(tagWidth / 2, Math.min(chartWidth - tagWidth / 2, hoverData.x));
      ctx.fillStyle = '#27272a';
      ctx.fillRect(tagX - tagWidth / 2, timeAxisY + 2, tagWidth, 18);
      ctx.strokeStyle = '#f59e0b';
      ctx.strokeRect(tagX - tagWidth / 2, timeAxisY + 2, tagWidth, 18);
      ctx.fillStyle = '#fbbf24';
      ctx.font = 'bold 9px JetBrains Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(timeTag, tagX, timeAxisY + 14);
    }
  }, [candles, showEMAs, showSMC, showLevels, showRSI, activeSignal, hoverData, symbol, timeframe, scaleMode, visibleCandleCount, verticalStretch, verticalPan, isDraggingAxis, isHoveringAxis, tickDirection]);

  useEffect(() => {
    drawChart();
  }, [drawChart]);

  // Handle Canvas Resize
  useEffect(() => {
    const handleResize = () => drawChart();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [drawChart]);

  // Global mouseup listener for axis dragging
  useEffect(() => {
    const handleGlobalMouseUp = () => {
      setIsDraggingAxis(false);
    };
    window.addEventListener('mouseup', handleGlobalMouseUp);
    return () => window.removeEventListener('mouseup', handleGlobalMouseUp);
  }, []);

  // Mouse down on canvas (check for axis drag)
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const chartWidth = rect.width - 75;

    if (x >= chartWidth) {
      setIsDraggingAxis(true);
      dragStartYRef.current = e.clientY;
      dragStartStretchRef.current = verticalStretch;
    }
  };

  // Mouse move on canvas for crosshair or axis stretching
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas || candles.length === 0) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const chartWidth = rect.width - 75;

    const onAxis = x >= chartWidth;
    if (onAxis !== isHoveringAxis) {
      setIsHoveringAxis(onAxis);
    }

    if (isDraggingAxis) {
      // Dragging price scale vertically:
      // Moving up increases stretch, moving down compresses
      const deltaY = dragStartYRef.current - e.clientY;
      const newFactor = Math.max(0.4, Math.min(3.5, dragStartStretchRef.current * Math.pow(1.008, deltaY)));
      setVerticalStretch(Math.round(newFactor * 100) / 100);
      setHoverData(null);
      return;
    }

    if (x < chartWidth) {
      const visibleCount = Math.min(candles.length, visibleCandleCount);
      const visibleCandles = candles.slice(-visibleCount);
      const candleSlotWidth = chartWidth / visibleCount;

      const idx = Math.floor(x / candleSlotWidth);
      if (idx >= 0 && idx < visibleCandles.length) {
        setHoverData({
          candle: visibleCandles[idx],
          x,
          y,
        });
      }
    } else {
      setHoverData(null);
    }
  };

  const handleMouseUp = () => {
    if (isDraggingAxis) {
      setIsDraggingAxis(false);
    }
  };

  const handleDoubleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const chartWidth = rect.width - 75;

    if (x >= chartWidth) {
      // Double click on price axis resets vertical stretch!
      setVerticalStretch(1.0);
      setVerticalPan(0);
    }
  };

  // Mouse wheel zoom for both directions
  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const chartWidth = rect.width - 75;

    if (x >= chartWidth) {
      // Wheel over right price axis -> Adjust Vertical Stretch
      const delta = e.deltaY < 0 ? 0.12 : -0.12;
      setVerticalStretch((prev) => Math.max(0.4, Math.min(3.5, Math.round((prev + delta) * 100) / 100)));
    } else {
      // Wheel over chart body -> Adjust Horizontal Stretch (Bar count)
      const deltaBars = e.deltaY < 0 ? -4 : 4;
      setVisibleCandleCount((prev) => Math.max(15, Math.min(90, prev + deltaBars)));
    }
  };

  const handleMouseLeave = () => {
    setHoverData(null);
    setIsHoveringAxis(false);
  };

  const latestCandle = candles[candles.length - 1];
  const priceDecimals = symbol === 'BTCUSD' ? 1 : 2;

  return (
    <div className="flex flex-col bg-neutral-900 border border-neutral-800 rounded-lg overflow-hidden shadow-xl">
      {/* Open-Source Live Data Feed Selector & Network Health */}
      <div className="flex flex-wrap items-center justify-between px-3 py-2 bg-neutral-950 border-b border-neutral-800 text-xs gap-2">
        <div className="flex flex-wrap items-center gap-2">
          {/* Asset Symbol Switcher */}
          <div className="flex items-center gap-1 bg-neutral-900 p-0.5 rounded border border-neutral-700/80 shadow-inner">
            <button
              onClick={() => setSymbol('XAUUSD')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-bold transition-all ${
                symbol === 'XAUUSD'
                  ? 'bg-amber-400 text-neutral-950 shadow-md ring-1 ring-amber-300'
                  : 'text-neutral-400 hover:text-amber-300'
              }`}
            >
              <span>🥇 XAUUSD</span>
              <span className="text-[10px] opacity-75 font-normal">ทองคำ (10Y Data)</span>
            </button>

            <button
              onClick={() => setSymbol('BTCUSD')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-bold transition-all ${
                symbol === 'BTCUSD'
                  ? 'bg-orange-500 text-neutral-950 shadow-md ring-1 ring-orange-300'
                  : 'text-neutral-400 hover:text-orange-300'
              }`}
            >
              <span>₿ BTCUSD</span>
              <span className="text-[10px] opacity-75 font-normal">บิตคอยน์ (5Y Data)</span>
            </button>
          </div>

          <div className="hidden md:flex items-center gap-1 text-neutral-400 text-[11px] ml-1">
            <Radio className="w-3 h-3 text-emerald-400 animate-pulse" />
            <span>Feed:</span>
          </div>

          <div className="flex items-center gap-1 bg-neutral-900 p-0.5 rounded border border-neutral-800">
            <button
              onClick={() => setDataSource('binance')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs transition-all ${
                dataSource === 'binance'
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40 font-bold shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>{symbol === 'BTCUSD' ? 'Binance (BTCUSDT 24/7)' : 'Binance (PAXG Gold 24/7)'}</span>
            </button>

            <button
              onClick={() => setDataSource('yahoo')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs transition-all ${
                dataSource === 'yahoo'
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/40 font-bold shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Globe className="w-3 h-3 text-cyan-400" />
              <span>{symbol === 'BTCUSD' ? 'Yahoo (BTC-USD)' : 'Yahoo (GC=F COMEX)'}</span>
            </button>

            <button
              onClick={() => setDataSource('simulation')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs transition-all ${
                dataSource === 'simulation'
                  ? 'bg-amber-950 text-amber-300 border border-amber-500/40 font-bold shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Zap className="w-3 h-3 text-amber-400" />
              <span>Tick Simulator</span>
            </button>
          </div>
        </div>

        {/* Live sync status & manual refresh */}
        <div className="flex items-center gap-3 font-mono text-[11px] text-neutral-400">
          {dataSource !== 'simulation' && (
            <>
              {wsConnected && dataSource === 'binance' ? (
                <div className="flex items-center gap-1.5 bg-emerald-950/80 border border-emerald-500/60 px-2.5 py-1 rounded text-emerald-300 font-bold shadow-sm ring-1 ring-emerald-500/20">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  <span>⚡ 0-Lag WebSocket Stream</span>
                  <span className="text-[10px] font-normal text-emerald-400/90 bg-emerald-900/60 px-1 py-0.2 rounded">
                    {wsTickCount.toLocaleString()} ticks
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 bg-neutral-900/80 px-2 py-1 rounded border border-neutral-800">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  <span className="text-emerald-400">เชื่อมต่อสด API ฟรี</span>
                  {liveLatency && (
                    <span className="text-neutral-500">({liveLatency}ms)</span>
                  )}
                </div>
              )}

              <span className="hidden sm:inline text-neutral-500">
                อัพเดตล่าสุด: <span className="text-neutral-300">{lastLiveSyncTime || 'กำลังดึง...'}</span>
              </span>
            </>
          )}

          <button
            onClick={onRefreshLive}
            disabled={isFetchingLive}
            title="ดึงแท่งเทียนราคา Real-Time ล่าสุดจาก Open-Source Feed"
            className="flex items-center gap-1 px-2.5 py-1 bg-neutral-900 hover:bg-neutral-800 border border-neutral-700/80 text-neutral-200 rounded transition-colors text-xs disabled:opacity-50"
          >
            <RefreshCw className={`w-3 h-3 ${isFetchingLive ? 'animate-spin text-amber-400' : 'text-neutral-400'}`} />
            <span>{isFetchingLive ? 'กำลังโหลด...' : 'รีเฟรชกราฟ'}</span>
          </button>
        </div>
      </div>

      {/* Top Bar: Timeframe, Indicators, Simulation Controls */}
      <div className="flex flex-wrap items-center justify-between px-3 py-2 bg-neutral-950/80 border-b border-neutral-800 gap-2">
        {/* Timeframes */}
        <div className="flex items-center gap-1 bg-neutral-900 p-0.5 rounded border border-neutral-800">
          {(['M1', 'M5', 'M15', 'H1', 'H4', 'D1'] as TimeFrame[]).map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-2.5 py-1 text-xs font-mono font-medium rounded transition-colors ${
                timeframe === tf
                  ? 'bg-amber-400 text-neutral-950 font-bold shadow-sm'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>

        {/* Overlay Switches */}
        <div className="flex items-center gap-2 text-xs">
          <button
            onClick={() => setShowEMAs(!showEMAs)}
            className={`px-2 py-1 rounded border transition-colors ${
              showEMAs
                ? 'border-amber-500/40 bg-amber-950/30 text-amber-300'
                : 'border-neutral-800 text-neutral-500 hover:text-neutral-300'
            }`}
          >
            EMA (20/50/200)
          </button>

          <button
            onClick={() => setShowSMC(!showSMC)}
            className={`px-2 py-1 rounded border transition-colors ${
              showSMC
                ? 'border-emerald-500/40 bg-emerald-950/30 text-emerald-300'
                : 'border-neutral-800 text-neutral-500 hover:text-neutral-300'
            }`}
          >
            SMC Order Block
          </button>

          <button
            onClick={() => setShowLevels(!showLevels)}
            className={`px-2 py-1 rounded border transition-colors ${
              showLevels
                ? 'border-cyan-500/40 bg-cyan-950/30 text-cyan-300'
                : 'border-neutral-800 text-neutral-500 hover:text-neutral-300'
            }`}
          >
            เป้า TP / SL
          </button>

          <button
            onClick={() => setShowRSI(!showRSI)}
            className={`px-2 py-1 rounded border transition-colors ${
              showRSI
                ? 'border-purple-500/40 bg-purple-950/30 text-purple-300'
                : 'border-neutral-800 text-neutral-500 hover:text-neutral-300'
            }`}
          >
            RSI อินดิเคเตอร์
          </button>

          {/* Scale Mode: Auto-Fit Candles vs Full View */}
          <button
            onClick={() => setScaleMode(scaleMode === 'candles' ? 'full' : 'candles')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded border transition-all ${
              scaleMode === 'candles'
                ? 'border-amber-400 bg-amber-950/50 text-amber-300 font-bold shadow-sm ring-1 ring-amber-400/30'
                : 'border-neutral-700 bg-neutral-900 text-neutral-400 hover:text-white'
            }`}
            title="สลับระหว่าง ซูมแท่งเทียนชัดเต็มจอ (Auto-Fit) หรือ รวมระยะ TP/SL ไกล"
          >
            <Focus className={`w-3.5 h-3.5 ${scaleMode === 'candles' ? 'text-amber-400' : 'text-neutral-400'}`} />
            <span>{scaleMode === 'candles' ? '🎯 ซูมแท่งเทียนชัด (Auto-Fit)' : '📐 รวม TP/SL ไกล (Full)'}</span>
          </button>
        </div>

        {/* Engine Controls: Play / Pause / News Spike */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-neutral-900 px-1 py-0.5 rounded border border-neutral-800">
            <button
              onClick={() => setIsRunning(!isRunning)}
              className={`p-1 rounded transition-colors ${
                isRunning ? 'text-emerald-400 hover:bg-neutral-800' : 'text-neutral-400 hover:bg-neutral-800'
              }`}
              title={isRunning ? 'หยุดการเคลื่อนไหวราคา' : 'เริ่มรับ Tick ราคาแบบ Real-Time'}
            >
              {isRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            </button>

            {[1, 5, 20].map((s) => (
              <button
                key={s}
                onClick={() => setTickSpeed(s)}
                className={`px-1.5 py-0.5 text-[10px] font-mono rounded ${
                  tickSpeed === s ? 'bg-neutral-700 text-white font-bold' : 'text-neutral-500 hover:text-neutral-300'
                }`}
              >
                {s}x
              </button>
            ))}
          </div>

          <button
            onClick={onSimulateSpike}
            title="จำลองข่าวสหรัฐฯ พุ่งกระชากทดสอบระบบป้องกันข่าวของ EA"
            className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-rose-300 bg-rose-950/50 hover:bg-rose-900/60 border border-rose-800/60 rounded transition-colors"
          >
            <Zap className="w-3.5 h-3.5 text-rose-400" />
            <span>จำลองข่าวกระชาก (News Spike)</span>
          </button>
        </div>
      </div>

      {/* Precision Stretch & Scale Controls (ความถ่างแนวนอน / แนวตั้ง) */}
      <div className="flex flex-wrap items-center justify-between px-3 py-1.5 bg-neutral-950/90 border-b border-neutral-800 text-xs gap-2">
        <div className="flex flex-wrap items-center gap-3">
          {/* Horizontal Stretch Control */}
          <div className="flex items-center gap-1.5 bg-neutral-900 px-2 py-1 rounded border border-neutral-800">
            <MoveHorizontal className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[11px] text-neutral-300 font-medium">ถ่างแนวนอน:</span>
            <button
              onClick={() => setVisibleCandleCount((prev) => Math.min(90, prev + 5))}
              className="w-5 h-5 flex items-center justify-center text-neutral-400 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded transition-colors"
              title="บีบเข้า / เพิ่มจำนวนแท่ง (-)"
            >
              <Minus className="w-3 h-3" />
            </button>
            <input
              type="range"
              min="15"
              max="90"
              step="1"
              value={visibleCandleCount}
              onChange={(e) => setVisibleCandleCount(Number(e.target.value))}
              className="w-20 sm:w-24 h-1.5 bg-neutral-700 rounded-lg appearance-none cursor-pointer accent-amber-400"
              title={`ความกว้างแท่งเทียน: ${visibleCandleCount} บาร์`}
            />
            <button
              onClick={() => setVisibleCandleCount((prev) => Math.max(15, prev - 5))}
              className="w-5 h-5 flex items-center justify-center text-neutral-400 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded transition-colors"
              title="ถ่างออก / ขยายแท่งเทียนให้กว้างขึ้น (+)"
            >
              <Plus className="w-3 h-3" />
            </button>
            <span className="font-mono text-[10px] text-amber-300 w-11 text-right">
              {visibleCandleCount}บาร์
            </span>
          </div>

          {/* Vertical Stretch Control */}
          <div className="flex items-center gap-1.5 bg-neutral-900 px-2 py-1 rounded border border-neutral-800">
            <MoveVertical className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-[11px] text-neutral-300 font-medium">ถ่างแนวตั้ง:</span>
            <button
              onClick={() => setVerticalStretch((prev) => Math.max(0.4, Math.round((prev - 0.15) * 100) / 100))}
              className="w-5 h-5 flex items-center justify-center text-neutral-400 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded transition-colors"
              title="บีบความสูงลง (-)"
            >
              <Minus className="w-3 h-3" />
            </button>
            <input
              type="range"
              min="40"
              max="300"
              step="5"
              value={Math.round(verticalStretch * 100)}
              onChange={(e) => setVerticalStretch(Number(e.target.value) / 100)}
              className="w-20 sm:w-24 h-1.5 bg-neutral-700 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              title={`ความสูงแท่งเทียน: ${Math.round(verticalStretch * 100)}%`}
            />
            <button
              onClick={() => setVerticalStretch((prev) => Math.min(3.5, Math.round((prev + 0.15) * 100) / 100))}
              className="w-5 h-5 flex items-center justify-center text-neutral-400 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded transition-colors"
              title="ถ่างความสูงแท่งเทียนให้สูงขึ้น (+)"
            >
              <Plus className="w-3 h-3" />
            </button>
            <span className="font-mono text-[10px] text-cyan-300 w-11 text-right">
              {Math.round(verticalStretch * 100)}%
            </span>
          </div>

          {/* Quick Reset All Scale Button */}
          <button
            onClick={() => {
              setVerticalStretch(1.0);
              setVerticalPan(0);
              setVisibleCandleCount(45);
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-700/80 rounded transition-colors text-[11px]"
            title="รีเซ็ตสเกลทั้งแนวนอนและแนวตั้งกลับสู่ค่ามาตรฐาน (100% / 45 บาร์)"
          >
            <RotateCcw className="w-3 h-3 text-neutral-400" />
            <span>รีเซ็ตสเกล (Auto)</span>
          </button>
        </div>

        {/* Pro Trader Hint */}
        <div className="hidden lg:flex items-center gap-1.5 text-[10px] text-neutral-400 font-mono">
          <span className="text-amber-400">💡 เทคนิค:</span>
          <span>คลิกลากแกนราคาด้านขวา ↕ เพื่อถ่าง/บีบแนวตั้ง (ดับเบิ้ลคลิกเพื่อรีเซ็ต) หรือหมุนลูกกลิ้งเมาส์</span>
        </div>
      </div>

      {/* OHLCV Header Strip */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-neutral-950/60 border-b border-neutral-800/80 text-[11px] font-mono">
        <div className="flex items-center gap-3 text-neutral-400">
          <span className="text-white font-bold">{symbol}</span>
          <span className="bg-neutral-800 text-neutral-300 px-1.5 py-0.2 rounded text-[10px]">{timeframe}</span>
          {hoverData ? (
            <>
              <span>
                O: <span className="text-neutral-200">{hoverData.candle.open.toFixed(priceDecimals)}</span>
              </span>
              <span>
                H: <span className="text-emerald-400">{hoverData.candle.high.toFixed(priceDecimals)}</span>
              </span>
              <span>
                L: <span className="text-rose-400">{hoverData.candle.low.toFixed(priceDecimals)}</span>
              </span>
              <span>
                C: <span className="text-neutral-200">{hoverData.candle.close.toFixed(priceDecimals)}</span>
              </span>
              <span>
                Vol: <span className="text-neutral-300">{hoverData.candle.volume}</span>
              </span>
            </>
          ) : latestCandle ? (
            <>
              <span>
                O: <span className="text-neutral-200">{latestCandle.open.toFixed(priceDecimals)}</span>
              </span>
              <span>
                H: <span className="text-emerald-400">{latestCandle.high.toFixed(priceDecimals)}</span>
              </span>
              <span>
                L: <span className="text-rose-400">{latestCandle.low.toFixed(priceDecimals)}</span>
              </span>
              <span>
                C: <span className="text-neutral-200">{latestCandle.close.toFixed(priceDecimals)}</span>
              </span>
              <span>
                Vol: <span className="text-neutral-300">{latestCandle.volume}</span>
              </span>
            </>
          ) : null}
          {/* Real-time Tick Glow Flash */}
          {tickDirection === 'UP' && (
            <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-950/80 border border-emerald-500/50 px-1.5 py-0.5 rounded animate-pulse">
              ▲ TICK UP
            </span>
          )}
          {tickDirection === 'DOWN' && (
            <span className="flex items-center gap-1 text-[10px] font-bold text-rose-400 bg-rose-950/80 border border-rose-500/50 px-1.5 py-0.5 rounded animate-pulse">
              ▼ TICK DOWN
            </span>
          )}
        </div>

        <div className="flex items-center gap-3 text-neutral-400">
          {/* Live Real-World Clock & Candle Countdown */}
          <div className="flex items-center gap-2 bg-neutral-900 px-2 py-0.5 rounded border border-neutral-800 text-[10px]">
            <span className="flex items-center gap-1 text-emerald-400 font-bold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>LIVE {realTimeClock} (UTC+7)</span>
            </span>
            <span className="text-neutral-600">|</span>
            <span className="text-amber-300 font-mono">
              ⏳ ปิดแท่ง {timeframe} ใน {candleCountdown}
            </span>
          </div>

          <div className="hidden sm:flex items-center gap-3 text-neutral-500">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              <span>EMA 20</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              <span>EMA 50</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-purple-400" />
              <span>EMA 200</span>
            </span>
          </div>
        </div>
      </div>

      {/* Main Canvas Area */}
      <div className="relative w-full h-[470px] bg-[#0a0a0c]">
        <canvas
          ref={canvasRef}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onDoubleClick={handleDoubleClick}
          onWheel={handleWheel}
          onMouseLeave={handleMouseLeave}
          className={`w-full h-full block ${
            isDraggingAxis || isHoveringAxis ? 'cursor-ns-resize' : 'cursor-crosshair'
          }`}
        />

        {/* Quick Instant Buy / Sell Overlay Buttons on Chart with Live Bid/Ask & Spread */}
        <div className="absolute bottom-4 left-4 flex flex-wrap items-center gap-2 bg-neutral-950/90 p-1.5 rounded-lg border border-neutral-800 backdrop-blur-sm shadow-xl">
          <button
            onClick={() => onQuickTrade('BUY')}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded transition-all shadow active:scale-95"
          >
            <span>BUY {symbol === 'BTCUSD' ? 'BTC' : 'ทองคำ'}</span>
            <span className="font-mono text-[10px] bg-emerald-700 px-1.5 py-0.5 rounded">
              Ask {liveAsk ? liveAsk.toFixed(priceDecimals) : latestCandle ? latestCandle.close.toFixed(priceDecimals) : ''}
            </span>
          </button>

          <button
            onClick={() => onQuickTrade('SELL')}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 rounded transition-all shadow active:scale-95"
          >
            <span>SELL {symbol === 'BTCUSD' ? 'BTC' : 'ทองคำ'}</span>
            <span className="font-mono text-[10px] bg-rose-700 px-1.5 py-0.5 rounded">
              Bid {liveBid ? liveBid.toFixed(priceDecimals) : latestCandle ? latestCandle.close.toFixed(priceDecimals) : ''}
            </span>
          </button>

          {/* Spread indicator */}
          <div className="hidden sm:flex items-center gap-1 text-[10px] font-mono text-neutral-400 bg-neutral-900 px-2 py-1 rounded border border-neutral-800">
            <span className="text-neutral-500">Spread:</span>
            <span className="text-amber-400 font-bold">
              {liveAsk && liveBid
                ? Math.abs(liveAsk - liveBid).toFixed(priceDecimals)
                : symbol === 'BTCUSD'
                ? '0.2'
                : '0.04'}
            </span>
            <span className="text-neutral-500">{symbol === 'BTCUSD' ? 'pts' : 'pts'}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

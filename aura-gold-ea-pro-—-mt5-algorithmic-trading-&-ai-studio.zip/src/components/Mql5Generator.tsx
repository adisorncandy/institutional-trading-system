import React, { useState, useMemo } from 'react';
import { defaultEAConfig, EAConfig, generateMQL5Source } from '../utils/mql5Template';
import { Copy, Download, Check, Settings, Terminal, HelpCircle, Code2, ShieldCheck, Zap } from 'lucide-react';

interface Mql5GeneratorProps {
  currentLineToken: string;
}

export const Mql5Generator: React.FC<Mql5GeneratorProps> = ({ currentLineToken }) => {
  const [config, setConfig] = useState<EAConfig>({
    ...defaultEAConfig,
    lineToken: currentLineToken || 'YOUR_LINE_TOKEN_HERE',
  });
  const [copied, setCopied] = useState(false);
  const [activeGuideTab, setActiveGuideTab] = useState<'editor' | 'webrequest' | 'chart'>('editor');

  const generatedCode = useMemo(() => {
    return generateMQL5Source(config);
  }, [config]);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(generatedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([generatedCode], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'AURA_Gold_AI_v5.mq5';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col gap-5">
      {/* Top Banner & Quick Download */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Code2 className="w-5 h-5 text-amber-400" />
            <h2 className="text-sm font-semibold text-white">
              ซอร์สโค้ด EA สำหรับ MetaTrader 5 (XAUUSD Pro Edition)
            </h2>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            โค้ดภาษา MQL5 แท้ 100% คอมไพล์ได้ทันที รองรับฟังก์ชัน WebRequest ส่ง LINE ในตัว พร้อมคำนวณ Lot & Trailing Stop
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyCode}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-200 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 rounded transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'คัดลอกสำเร็จ!' : 'คัดลอกโค้ด MQL5'}</span>
          </button>

          <button
            onClick={handleDownloadFile}
            className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-bold text-neutral-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 rounded transition-all shadow"
          >
            <Download className="w-3.5 h-3.5" />
            <span>ดาวน์โหลด .mq5</span>
          </button>
        </div>
      </div>

      {/* Grid: Config Settings & Code Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Interactive Parameters (4 cols) */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 shadow-xl">
            <div className="flex items-center gap-2 border-b border-neutral-800 pb-2 mb-3">
              <Settings className="w-4 h-4 text-amber-400" />
              <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
                ปรับแต่งค่าพารามิเตอร์ EA (Config)
              </h3>
            </div>

            <div className="space-y-3 text-xs">
              {/* Lot Type */}
              <div>
                <label className="text-neutral-400 block mb-1">โหมดคำนวณ Lot Size:</label>
                <select
                  value={config.lotType}
                  onChange={(e) => setConfig({ ...config, lotType: e.target.value as any })}
                  className="w-full bg-neutral-950 border border-neutral-800 text-white rounded p-1.5 font-mono"
                >
                  <option value="RISK_PERCENT">Dynamic Risk % ตามยอดเงินทุน (แนะนำ)</option>
                  <option value="FIXED">Fixed Lot คงที่</option>
                </select>
              </div>

              {config.lotType === 'FIXED' ? (
                <div>
                  <label className="text-neutral-400 block mb-1">ขนาด Fixed Lot:</label>
                  <input
                    type="number"
                    step="0.01"
                    value={config.fixedLot}
                    onChange={(e) => setConfig({ ...config, fixedLot: Number(e.target.value) })}
                    className="w-full bg-neutral-950 border border-neutral-800 text-white rounded p-1.5 font-mono"
                  />
                </div>
              ) : (
                <div>
                  <label className="text-neutral-400 block mb-1">ความเสี่ยงต่อไม้ (% Risk):</label>
                  <input
                    type="number"
                    step="0.1"
                    value={config.riskPercent}
                    onChange={(e) => setConfig({ ...config, riskPercent: Number(e.target.value) })}
                    className="w-full bg-neutral-950 border border-neutral-800 text-white rounded p-1.5 font-mono"
                  />
                </div>
              )}

              {/* Targets */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-neutral-400 block mb-1">Stop Loss (Pips):</label>
                  <input
                    type="number"
                    value={config.stopLossPips}
                    onChange={(e) => setConfig({ ...config, stopLossPips: Number(e.target.value) })}
                    className="w-full bg-neutral-950 border border-neutral-800 text-white rounded p-1.5 font-mono"
                  />
                </div>
                <div>
                  <label className="text-neutral-400 block mb-1">TP1 เป้าแรก (Pips):</label>
                  <input
                    type="number"
                    value={config.tp1Pips}
                    onChange={(e) => setConfig({ ...config, tp1Pips: Number(e.target.value) })}
                    className="w-full bg-neutral-950 border border-neutral-800 text-white rounded p-1.5 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-neutral-400 block mb-1">TP2 เป้าสอง (Pips):</label>
                  <input
                    type="number"
                    value={config.tp2Pips}
                    onChange={(e) => setConfig({ ...config, tp2Pips: Number(e.target.value) })}
                    className="w-full bg-neutral-950 border border-neutral-800 text-white rounded p-1.5 font-mono"
                  />
                </div>
                <div>
                  <label className="text-neutral-400 block mb-1">กันทุน Break-Even (Pips):</label>
                  <input
                    type="number"
                    value={config.breakEvenPips}
                    onChange={(e) => setConfig({ ...config, breakEvenPips: Number(e.target.value) })}
                    className="w-full bg-neutral-950 border border-neutral-800 text-white rounded p-1.5 font-mono"
                  />
                </div>
              </div>

              {/* Trailing Stop & Partial Close */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-neutral-400 block mb-1">Trailing Stop (Pips):</label>
                  <input
                    type="number"
                    value={config.trailingStopPips}
                    onChange={(e) => setConfig({ ...config, trailingStopPips: Number(e.target.value) })}
                    className="w-full bg-neutral-950 border border-neutral-800 text-white rounded p-1.5 font-mono"
                  />
                </div>
                <div>
                  <label className="text-neutral-400 block mb-1">ปิดกำไรแบ่งไม้ TP1 (%):</label>
                  <input
                    type="number"
                    value={config.partialClosePercent}
                    onChange={(e) => setConfig({ ...config, partialClosePercent: Number(e.target.value) })}
                    className="w-full bg-neutral-950 border border-neutral-800 text-white rounded p-1.5 font-mono"
                  />
                </div>
              </div>

              {/* High Precision Filter */}
              <div>
                <label className="text-neutral-400 block mb-1">เกณฑ์ขั้นต่ำความแม่นยำ AI (%):</label>
                <input
                  type="number"
                  min="85"
                  max="98"
                  value={config.minConfidence}
                  onChange={(e) => setConfig({ ...config, minConfidence: Number(e.target.value) })}
                  className="w-full bg-neutral-950 border border-neutral-800 text-amber-400 font-bold rounded p-1.5 font-mono"
                />
              </div>

              {/* LINE Notify in EA */}
              <div className="pt-2 border-t border-neutral-800">
                <label className="flex items-center justify-between cursor-pointer mb-2">
                  <span className="text-neutral-300 font-medium">เปิดแจ้งเตือน LINE ใน EA:</span>
                  <input
                    type="checkbox"
                    checked={config.lineNotifyEnabled}
                    onChange={(e) => setConfig({ ...config, lineNotifyEnabled: e.target.checked })}
                    className="w-4 h-4 accent-[#06C755]"
                  />
                </label>
                {config.lineNotifyEnabled && (
                  <input
                    type="text"
                    placeholder="วาง Line Token ในโค้ด"
                    value={config.lineToken}
                    onChange={(e) => setConfig({ ...config, lineToken: e.target.value })}
                    className="w-full bg-neutral-950 border border-neutral-800 text-white rounded p-1.5 font-mono text-[11px]"
                  />
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Code Viewer (8 cols) */}
        <div className="lg:col-span-8 flex flex-col">
          <div className="bg-neutral-950 border border-neutral-800 rounded-lg overflow-hidden shadow-2xl flex flex-col h-[520px]">
            {/* Window bar */}
            <div className="bg-neutral-900 px-4 py-2 border-b border-neutral-800 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-rose-500/80 inline-block" />
                <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block" />
                <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
                <span className="text-neutral-400 font-mono text-[11px] ml-2">AURA_Gold_AI_v5.mq5</span>
              </div>
              <button
                onClick={handleCopyCode}
                className="text-neutral-400 hover:text-white flex items-center gap-1 text-[11px]"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'คัดลอกแล้ว' : 'Copy'}</span>
              </button>
            </div>

            {/* Code Content */}
            <div className="flex-1 p-4 overflow-y-auto font-mono text-[11px] leading-relaxed text-neutral-300">
              <pre className="whitespace-pre">{generatedCode}</pre>
            </div>
          </div>
        </div>
      </div>

      {/* MT5 Installation & WebRequest Setup Guide in Thai */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 shadow-xl">
        <div className="flex items-center gap-2 border-b border-neutral-800 pb-3 mb-3">
          <HelpCircle className="w-5 h-5 text-amber-400" />
          <h3 className="text-sm font-semibold text-white">
            คู่มือการติดตั้ง EA ลงโปรแกรม MetaTrader 5 (MT5) ทีละขั้นตอน
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-3 bg-neutral-950 rounded border border-neutral-800">
            <div className="flex items-center gap-2 font-bold text-amber-400 mb-2">
              <span className="w-5 h-5 rounded-full bg-amber-400/20 text-amber-400 flex items-center justify-center text-xs">
                1
              </span>
              <span>นำโค้ดไปคอมไพล์ใน MT5</span>
            </div>
            <ol className="list-decimal list-inside space-y-1 text-neutral-400">
              <li>เปิดโปรแกรม MetaTrader 5 บนคอมพิวเตอร์</li>
              <li>กดปุ่ม <kbd className="px-1 bg-neutral-800 rounded text-white">F4</kbd> เพื่อเปิด MetaEditor</li>
              <li>คลิก New &rarr; Expert Advisor (template) ตั้งชื่อ <code className="text-neutral-200">AURA_Gold_AI_v5</code></li>
              <li>กด <kbd className="px-1 bg-neutral-800 rounded text-white">Ctrl+A</kbd> ลบโค้ดเดิมออก แล้ววางโค้ดที่คัดลอกจากเว็บนี้</li>
              <li>กดปุ่ม <kbd className="px-1 bg-neutral-800 rounded text-white">F7</kbd> (Compile) เพื่อสร้างไฟล์ .ex5 (0 errors)</li>
            </ol>
          </div>

          <div className="p-3 bg-neutral-950 rounded border border-neutral-800">
            <div className="flex items-center gap-2 font-bold text-[#06C755] mb-2">
              <span className="w-5 h-5 rounded-full bg-emerald-400/20 text-emerald-400 flex items-center justify-center text-xs">
                2
              </span>
              <span>เปิดสิทธิ์ส่งข้อความเข้า LINE</span>
            </div>
            <ol className="list-decimal list-inside space-y-1 text-neutral-400">
              <li>ในหน้าต่างหลักของ MT5 ไปที่เมนู <strong className="text-white">Tools &rarr; Options</strong> (หรือกด Ctrl+O)</li>
              <li>คลิกแท็บ <strong className="text-white">Expert Advisors</strong></li>
              <li>ติ๊กเครื่องหมายถูกที่ <strong className="text-white">Allow WebRequest for listed URL:</strong></li>
              <li>กดปุ่ม <code className="text-emerald-400">+ Add new URL</code> แล้วใส่:</li>
              <li className="font-mono text-emerald-400 bg-neutral-900 p-1 rounded break-all">https://notify-api.line.me</li>
            </ol>
          </div>

          <div className="p-3 bg-neutral-950 rounded border border-neutral-800">
            <div className="flex items-center gap-2 font-bold text-cyan-400 mb-2">
              <span className="w-5 h-5 rounded-full bg-cyan-400/20 text-cyan-400 flex items-center justify-center text-xs">
                3
              </span>
              <span>รัน EA บนกราฟทองคำ XAUUSD</span>
            </div>
            <ol className="list-decimal list-inside space-y-1 text-neutral-400">
              <li>เปิดกราฟทองคำคู่เงิน <strong className="text-white">XAUUSD</strong> แนะนำ Timeframe <strong className="text-white">M5 หรือ M15</strong></li>
              <li>ลากไฟล์ EA จากหน้าต่าง Navigator ฝั่งซ้ายมาวางบนกราฟ</li>
              <li>ในแท็บ Common ติ๊กถูกที่ <strong className="text-white">Allow Algo Trading</strong></li>
              <li>กดปุ่ม <strong className="text-white">Algo Trading</strong> ที่แถบเครื่องมือด้านบนให้เป็นสีเขียว</li>
              <li>เมื่อมีสัญญาณ EA จะเข้าออเดอร์และแจ้งเตือนเข้ามือถือผ่าน LINE ทันที!</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { TradingSignal, Trade, TradingSymbol } from '../types/trading';
import { CheckCircle2, AlertTriangle, Send, ArrowUpRight, ArrowDownRight, ShieldCheck, Zap, Sliders } from 'lucide-react';

interface SignalEngineProps {
  symbol: TradingSymbol;
  signal: TradingSignal;
  accountBalance: number;
  setAccountBalance: (val: number) => void;
  riskPercent: number;
  setRiskPercent: (val: number) => void;
  onExecuteTrade: (trade: Omit<Trade, 'id' | 'ticket' | 'timestamp'>) => void;
  onSendToLine: (signal: TradingSignal) => void;
  autoPilot: boolean;
}

export const SignalEngine: React.FC<SignalEngineProps> = ({
  symbol,
  signal,
  accountBalance,
  setAccountBalance,
  riskPercent,
  setRiskPercent,
  onExecuteTrade,
  onSendToLine,
  autoPilot,
}) => {
  const [lotOverride, setLotOverride] = useState<number | null>(null);

  const isBuy = signal.direction === 'BUY';
  const isSell = signal.direction === 'SELL';
  const effectiveLot = lotOverride ?? signal.suggestedLot;
  const isBtc = symbol === 'BTCUSD';

  const handleExecute = () => {
    if (signal.direction === 'WAIT') return;
    onExecuteTrade({
      symbol: symbol,
      type: signal.direction,
      lot: effectiveLot,
      openPrice: signal.entry,
      sl: signal.sl,
      tp1: signal.tp1,
      tp2: signal.tp2,
      confidence: signal.confidence,
      marketRegime: isBuy ? 'Bullish Expansion' : 'Order Block Reaction',
      status: 'OPEN',
      aiNotes: signal.reasonTh,
    });
  };

  return (
    <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 shadow-xl flex flex-col gap-4">
      {/* Header and 90%+ Precision Indicator */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-neutral-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${isBtc ? 'bg-orange-500' : 'bg-amber-400'}`} />
            <h2 className="text-sm font-semibold text-white">
              ระบบวิเคราะห์สัญญาณ AI 90%++ Multi-Confluence [{symbol}]
            </h2>
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            กรอง 4 เสาหลัก (Trend + SMC Order Block + Dynamic RSI + ATR Safety) ก่อนออกคำสั่ง ({isBtc ? 'BTCUSD Real-Time 5Y Backtest' : 'XAUUSD Real-Time 10Y Backtest'})
          </p>
        </div>

        {/* AI Confidence Meter */}
        <div className="flex items-center gap-3 bg-neutral-950 px-3 py-1.5 rounded-lg border border-neutral-800">
          <div className="text-right">
            <div className="text-[10px] text-neutral-400 uppercase tracking-wider">AI Confluence Score</div>
            <div className="text-base font-mono font-bold text-amber-400 tabular-nums">
              {signal.confidence.toFixed(1)}%
            </div>
          </div>
          <div
            className={`w-3 h-3 rounded-full ${
              signal.confidence >= 90
                ? 'bg-emerald-500 shadow-sm shadow-emerald-500 animate-pulse'
                : 'bg-amber-500'
            }`}
          />
        </div>
      </div>

      {/* Signal Card Main */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* Direction Card */}
        <div
          className={`p-4 rounded-lg border flex flex-col justify-between ${
            isBuy
              ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-200'
              : isSell
              ? 'bg-rose-950/30 border-rose-500/40 text-rose-200'
              : 'bg-neutral-800/40 border-neutral-700 text-neutral-300'
          }`}
        >
          <div>
            <div className="text-xs text-neutral-400 flex items-center justify-between">
              <span>สถานะสัญญาณ {symbol}</span>
              <span className="font-mono text-[11px] text-amber-400">
                {signal.confidence >= 90 ? '★ ผ่านเกณฑ์ความแม่นยำสูง' : 'กำลังประมวลผล'}
              </span>
            </div>
            <div className="mt-2 flex items-center gap-2">
              {isBuy ? (
                <ArrowUpRight className="w-6 h-6 text-emerald-400" />
              ) : isSell ? (
                <ArrowDownRight className="w-6 h-6 text-rose-400" />
              ) : (
                <AlertTriangle className="w-6 h-6 text-amber-400" />
              )}
              <span className="text-xl font-bold tracking-wide">
                {isBuy ? 'STRONG BUY 🟢' : isSell ? 'STRONG SELL 🔴' : 'WAIT FOR SETUP 🟡'}
              </span>
            </div>
          </div>

          <p className="text-xs text-neutral-300 mt-3 line-clamp-2">{signal.reasonTh}</p>
        </div>

        {/* Pricing & Targets */}
        <div className="p-3 bg-neutral-950 rounded-lg border border-neutral-800 flex flex-col justify-between text-xs">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <span className="text-neutral-500 block">ราคาเข้า (Entry):</span>
              <span className="font-mono font-bold text-white text-sm tabular-nums">
                ${signal.entry.toFixed(isBtc ? 1 : 2)}
              </span>
            </div>
            <div>
              <span className="text-neutral-500 block">อัตรา R:R:</span>
              <span className="font-mono font-bold text-amber-400 text-sm">{signal.riskReward}</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-neutral-800/80">
            <div>
              <span className="text-rose-400 font-medium block">Stop Loss:</span>
              <span className="font-mono text-white text-xs tabular-nums">${signal.sl.toFixed(isBtc ? 1 : 2)}</span>
              <span className="text-[10px] text-neutral-500 block font-mono">{isBtc ? '-$450' : '-60 pips'}</span>
            </div>
            <div>
              <span className="text-emerald-400 font-medium block">Take Profit 1:</span>
              <span className="font-mono text-white text-xs tabular-nums">${signal.tp1.toFixed(isBtc ? 1 : 2)}</span>
              <span className="text-[10px] text-emerald-400 block font-mono">{isBtc ? '+$500 (50%)' : '+50 pips (50%)'}</span>
            </div>
            <div>
              <span className="text-emerald-300 font-medium block">Take Profit 2:</span>
              <span className="font-mono text-white text-xs tabular-nums">${signal.tp2.toFixed(isBtc ? 1 : 2)}</span>
              <span className="text-[10px] text-emerald-400 block font-mono">{isBtc ? '+$1,200' : '+120 pips'}</span>
            </div>
          </div>
        </div>

        {/* Dynamic Lot & Money Management */}
        <div className="p-3 bg-neutral-950 rounded-lg border border-neutral-800 flex flex-col justify-between text-xs">
          <div className="flex items-center justify-between">
            <span className="text-neutral-400">คำนวณขนาด Lot ตามทุน:</span>
            <span className="text-amber-400 font-mono font-bold">${accountBalance.toLocaleString()}</span>
          </div>

          <div className="grid grid-cols-2 gap-2 my-2">
            <div>
              <label className="text-[11px] text-neutral-500 block">ความเสี่ยงต่อไม้ (%):</label>
              <select
                value={riskPercent}
                onChange={(e) => setRiskPercent(Number(e.target.value))}
                className="w-full bg-neutral-900 border border-neutral-700 text-white rounded px-2 py-1 text-xs font-mono"
              >
                <option value={1.0}>1.0% (อนุรักษ์นิยม)</option>
                <option value={1.5}>1.5% (แนะนำ EA)</option>
                <option value={2.0}>2.0% (มาตรฐาน)</option>
                <option value={3.0}>3.0% (เติบโตก้าวร้าว)</option>
              </select>
            </div>
            <div>
              <label className="text-[11px] text-neutral-500 block">ขนาด Lot แนะนำ:</label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                max="5.0"
                value={effectiveLot}
                onChange={(e) => setLotOverride(Number(e.target.value))}
                className="w-full bg-neutral-900 border border-neutral-700 text-amber-400 font-mono font-bold rounded px-2 py-1 text-xs"
              />
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-neutral-400 pt-1 border-t border-neutral-800">
            <span>ความเสียหายสูงสุดหากโดน SL:</span>
            <span className="font-mono text-rose-400 font-semibold">
              -${(accountBalance * (riskPercent / 100)).toFixed(1)}
            </span>
          </div>
        </div>
      </div>

      {/* 4 Pillars of High Precision (90%+ Architecture) */}
      <div className="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
        <div className="text-xs font-semibold text-neutral-300 mb-2 flex items-center justify-between">
          <span>เกณฑ์ตรวจสอบ 4 เสาหลัก (Multi-Pillar Verification)</span>
          <span className="text-[11px] text-neutral-500">ระบบเข้าออเดอร์เมื่อคะแนนรวม &gt;= 90%</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 text-xs">
          {Object.entries(signal.pillars).map(([key, p]) => (
            <div
              key={key}
              className={`p-2.5 rounded border flex flex-col justify-between ${
                p.passed
                  ? 'bg-neutral-900 border-emerald-500/30 text-neutral-200'
                  : 'bg-neutral-900 border-neutral-800 text-neutral-400'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium text-neutral-300">{p.name}</span>
                  <CheckCircle2
                    className={`w-3.5 h-3.5 ${p.passed ? 'text-emerald-400' : 'text-neutral-600'}`}
                  />
                </div>
                <p className="text-[11px] text-neutral-400 line-clamp-2">{p.detail}</p>
              </div>

              <div className="mt-2 pt-1.5 border-t border-neutral-800 flex items-center justify-between font-mono text-[10px]">
                <span className="text-neutral-500">คะแนน:</span>
                <span className={p.passed ? 'text-emerald-400 font-bold' : 'text-neutral-400'}>
                  {p.score} / {p.maxScore} pts
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Action Buttons: Execute & Send to LINE */}
      <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
        <div className="flex items-center gap-2">
          <button
            onClick={handleExecute}
            disabled={signal.direction === 'WAIT'}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded shadow transition-all ${
              isBuy
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                : isSell
                ? 'bg-rose-600 hover:bg-rose-500 text-white'
                : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>จำลองเปิดคำสั่ง {signal.direction} ในเทอร์มินอล (Lot {effectiveLot})</span>
          </button>

          <button
            onClick={() => onSendToLine(signal)}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-neutral-900 bg-[#06C755] hover:bg-[#05b34c] rounded shadow transition-all"
          >
            <Send className="w-3.5 h-3.5" />
            <span>ส่งสัญญาณแนะนำเข้า LINE ทันที</span>
          </button>
        </div>

        {autoPilot && (
          <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Auto-Pilot ทำงาน: คำสั่งและแจ้งเตือน LINE ทำงานอัตโนมัติเมื่อแม่นยำ &ge; 90%</span>
          </div>
        )}
      </div>
    </div>
  );
};

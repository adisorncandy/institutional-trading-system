"""Shared conservative OHLC fill approximation for research and OOS review."""


def simulate_trade(bars, i, side, atr, point, fallback_spread,
                   slippage_points=5.0, roundtrip_fee_points=0.0, profile=None):
    if profile is None:
        raise ValueError("Explicit timeframe profile required")
    enter=bars[i+1]
    entry_spread_points=enter[5] if enter[5]>0 else fallback_spread
    if entry_spread_points<=0:
        raise ValueError("Historical spread or positive fallback is required")
    # When a future bar lacks spread, carry the observed entry spread rather than assume zero.
    future_fallback=fallback_spread if fallback_spread>0 else entry_spread_points
    entry_spread=entry_spread_points*point
    slip=slippage_points*point
    entry=enter[1]+(entry_spread if side=="BUY" else 0)+(slip if side=="BUY" else -slip)
    stop_dist=max(profile.stop_atr*atr,2*point+entry_spread)
    target_dist=max(profile.target_atr*atr,2*point+entry_spread)
    sl=entry+(-stop_dist if side=="BUY" else stop_dist)
    tp=entry+(target_dist if side=="BUY" else -target_dist)
    exit_i=i+profile.hold+1
    reason="TIME"
    exit_px=None
    for j in range(i+1,i+profile.hold+1):
        bar=bars[j]
        spread=(bar[5] if bar[5]>0 else future_fallback)*point
        high=bar[2]+(spread if side=="SELL" else 0)
        low=bar[3]+(spread if side=="SELL" else 0)
        opened=bar[1]+(spread if side=="SELL" else 0)
        if (side=="BUY" and opened<=sl) or (side=="SELL" and opened>=sl):
            exit_i,exit_px,reason=j,opened,"STOP_GAP"
            break
        if (side=="BUY" and low<=sl) or (side=="SELL" and high>=sl):
            exit_i,exit_px,reason=j,sl,"STOP"
            break
        if (side=="BUY" and high>=tp) or (side=="SELL" and low<=tp):
            exit_i,exit_px,reason=j,tp,"TARGET"
            break
    if exit_px is None:
        bar=bars[exit_i]
        spread=(bar[5] if bar[5]>0 else future_fallback)*point
        exit_px=bar[1]+(spread if side=="SELL" else 0)
    exit_px+=(-slip if side=="BUY" else slip)
    pnl=(exit_px-entry if side=="BUY" else entry-exit_px)-roundtrip_fee_points*point
    return {"entry_time":enter[0],"exit_time":bars[exit_i][0],"side":side,
            "entry":entry,"exit":exit_px,"reason":reason,"R":pnl/stop_dist,
            "entry_bar":i+1,"exit_bar":exit_i}

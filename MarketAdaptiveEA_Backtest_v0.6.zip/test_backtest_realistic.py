import unittest

from adaptive_research import PROFILES
from backtest_realistic import simulate_trade, run_portfolio, summary


class BacktestTests(unittest.TestCase):
    def bars(self, count=40):
        return [(i*900,100.0,101.0,99.0,100.0,10) for i in range(count)]

    def test_same_bar_target_and_stop_counts_as_loss(self):
        bars=self.bars()
        bars[1]=(900,100,110,90,100,10)
        trade=simulate_trade(bars,0,"BUY",1.0,0.01,10,0,0,PROFILES["M15"])
        self.assertEqual(trade["reason"],"STOP")
        self.assertLess(trade["R"],0)

    def test_gap_through_stop_gets_worse_open(self):
        bars=self.bars()
        bars[1]=(900,100,100.5,99.8,100,10)
        bars[2]=(1800,95,96,94,95,10)
        trade=simulate_trade(bars,0,"BUY",1.0,0.01,10,0,0,PROFILES["M15"])
        self.assertEqual(trade["reason"],"STOP_GAP")
        self.assertLess(trade["exit"],trade["entry"]-1.8)

    def test_overlap_is_not_counted_as_two_positions(self):
        bars=self.bars(260)
        signals=[(220*900,"BUY_R0_T0",1),(221*900,"BUY_R0_T0",1)]
        trades,equity,dd=run_portfolio(bars,signals,0,PROFILES["M15"],0.01,10,None,0,0)
        self.assertEqual(len(trades),1)
        self.assertEqual(summary(trades,equity,dd)["trades"],1)

    def test_daily_loss_pauses_new_entries(self):
        bars=self.bars(260)
        bars[221]=(221*900,100,101,90,100,10)
        signals=[(220*900,"BUY_R0_T0",0),(222*900,"BUY_R0_T0",1)]
        trades,_,_=run_portfolio(bars,signals,0,PROFILES["M15"],0.01,10,None,0,0,
                                  risk_pct=0.5,daily_loss_pct=0.1)
        self.assertEqual(len(trades),1)


if __name__=="__main__":
    unittest.main()

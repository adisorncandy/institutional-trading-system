"""Collect USD releases and asset-specific headlines; publish chart overlays.

The price database spans ten years only when the broker supplies ten years.
GDELT article search begins in 2017, so headline coverage cannot span a full
ten years as of September 2026. Calendar availability is provider dependent.
"""
from __future__ import annotations

import argparse
import csv
import json
import sqlite3
import time
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path


SCHEMA = """
CREATE TABLE IF NOT EXISTS calendar (
  value_id TEXT PRIMARY KEY, event_id TEXT, time_server_epoch INTEGER,
  time_server_text TEXT, importance TEXT, name TEXT,
  actual TEXT, forecast TEXT, source TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS calendar_time ON calendar(time_server_epoch);
CREATE TABLE IF NOT EXISTS articles (
  url TEXT PRIMARY KEY, published_utc INTEGER NOT NULL, title TEXT NOT NULL,
  domain TEXT, source TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS articles_time ON articles(published_utc);
CREATE TABLE IF NOT EXISTS fetch_days (day_utc TEXT PRIMARY KEY, fetched_utc INTEGER NOT NULL, article_count INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS article_symbols (url TEXT, symbol TEXT, PRIMARY KEY(url,symbol));
CREATE TABLE IF NOT EXISTS fetch_days_asset (day_utc TEXT, symbol TEXT, fetched_utc INTEGER, article_count INTEGER,
  PRIMARY KEY(day_utc,symbol));
"""


def connect(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path)
    db.executescript(SCHEMA)
    return db


def import_calendar(db, path):
    count = 0
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        required = {"value_id", "event_id", "time_server_epoch", "time_server_text", "importance", "name"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError("Calendar CSV lacks required headers")
        for row in reader:
            db.execute("INSERT OR REPLACE INTO calendar VALUES (?,?,?,?,?,?,?,?,?)", (
                row["value_id"], row["event_id"], int(row["time_server_epoch"]),
                row["time_server_text"], row["importance"], row["name"],
                row.get("actual", ""), row.get("forecast", ""), "MT5_CALENDAR"))
            count += 1
    db.commit()
    return count


def parse_gdelt_article(article):
    published = datetime.strptime(article["seendate"], "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc)
    url, title = article["url"].strip(), article["title"].strip()
    if not url.startswith(("http://", "https://")) or not title:
        raise ValueError("Invalid GDELT article")
    return url, int(published.timestamp()), title, article.get("domain", ""), "GDELT_DOC"


def fetch_gdelt_day(day, query, timeout=20):
    next_day = day + timedelta(days=1)
    params = {"query": query, "mode": "artlist", "maxrecords": "250", "format": "json",
              "sort": "datedesc", "startdatetime": day.strftime("%Y%m%d%H%M%S"),
              "enddatetime": next_day.strftime("%Y%m%d%H%M%S")}
    url = "https://api.gdeltproject.org/api/v2/doc/doc?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": "GoldAdaptiveEA/0.3 (research)"})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        result = json.load(response)
    if not isinstance(result, dict) or not isinstance(result.get("articles"), list):
        raise ValueError("Unexpected GDELT response; day not checkpointed")
    return result["articles"]


def collect_gdelt(db, since, max_days, query, sleep_seconds=1.0, symbol="XAUUSD"):
    # Jan 2017 is the documented beginning of DOC 2.0 headline search.
    if since < datetime(2017, 1, 1, tzinfo=timezone.utc):
        raise ValueError("GDELT DOC 2.0 search does not cover before 2017-01-01")
    end = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    day = since.replace(hour=0, minute=0, second=0, microsecond=0)
    processed = 0
    while day < end and processed < max_days:
        stamp = day.strftime("%Y-%m-%d")
        if db.execute("SELECT 1 FROM fetch_days_asset WHERE day_utc=? AND symbol=?", (stamp,symbol)).fetchone():
            day += timedelta(days=1)
            continue
        articles = fetch_gdelt_day(day, query)
        if len(articles) >= 250:
            raise RuntimeError(f"{stamp} hit the 250-article API cap; narrow the query or split the date range. Day not marked complete.")
        parsed = []
        for article in articles:
            try:
                parsed.append(parse_gdelt_article(article))
            except (KeyError, ValueError):
                continue
        with db:
            db.executemany("INSERT OR IGNORE INTO articles VALUES (?,?,?,?,?)", parsed)
            db.executemany("INSERT OR IGNORE INTO article_symbols VALUES (?,?)", ((article[0],symbol) for article in parsed))
            db.execute("INSERT INTO fetch_days_asset VALUES (?,?,?,?)", (stamp,symbol,int(time.time()), len(parsed)))
        print(f"{stamp}: {len(parsed)} headlines")
        day += timedelta(days=1)
        processed += 1
        if sleep_seconds and day < end:
            time.sleep(sleep_seconds)
    return processed


def import_headlines(db, path, symbol="XAUUSD"):
    """Licensed CSV columns: published_utc (ISO-8601 with offset),title,url,source."""
    total = 0
    with path.open(encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            dt = datetime.fromisoformat(row["published_utc"].replace("Z", "+00:00"))
            if dt.tzinfo is None:
                raise ValueError("Headlines require explicit timezone offset")
            parsed = (row["url"], int(dt.timestamp()), row["title"],
                      urllib.parse.urlsplit(row["url"]).netloc, row["source"])
            db.execute("INSERT OR REPLACE INTO articles VALUES (?,?,?,?,?)", parsed)
            db.execute("INSERT OR IGNORE INTO article_symbols VALUES (?,?)", (row["url"],symbol))
            total += 1
    db.commit()
    return total


def safe_field(value):
    return str(value).replace("|", " ").replace("\r", " ").replace("\n", " ")


def export_overlay(db, path, lookback_days, offset_hours, max_records, symbol="XAUUSD"):
    # Calendar timestamps are already in MT5's trade-server chart timezone.
    # Article timestamps are UTC; current offset is approximate for historical DST.
    since = int(time.time() - lookback_days*86400)
    offset = round(offset_hours*3600)
    events = []
    for epoch, importance, title, source in db.execute(
            "SELECT time_server_epoch,importance,name,source FROM calendar WHERE time_server_epoch>=?",
            (since+offset,)):
        events.append((epoch, source, importance, title, ""))
    for epoch, title, url, source in db.execute(
            "SELECT a.published_utc,a.title,a.url,a.source FROM articles a JOIN article_symbols s ON a.url=s.url WHERE a.published_utc>=? AND s.symbol=?", (since,symbol)):
        events.append((epoch+offset, source, "HEADLINE", title, url))
    events.sort(key=lambda row: row[0], reverse=True)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".tmp")
    with temp.open("w", encoding="utf-8", newline="\n") as stream:
        stream.write("GOLD_EVENTS_V1\n")
        for row in events[:max_records]:
            stream.write("|".join(map(safe_field,row))+"\n")
    temp.replace(path)
    return min(len(events), max_records)


def coverage_status(db, symbol, timeframe):
    out = {}
    tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "bars" in tables:
        out["bars"] = db.execute("SELECT COUNT(*),MIN(time_utc),MAX(time_utc) FROM bars WHERE symbol=? AND timeframe=?", (symbol,timeframe)).fetchone()
    out["calendar_USD"] = db.execute("SELECT COUNT(*),MIN(time_server_epoch),MAX(time_server_epoch) FROM calendar").fetchone()
    out["articles"] = db.execute("SELECT COUNT(*),MIN(a.published_utc),MAX(a.published_utc) FROM articles a JOIN article_symbols s ON a.url=s.url WHERE s.symbol=?",(symbol,)).fetchone()
    return out


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--db", type=Path, default=Path("market_history.sqlite"))
    sub = p.add_subparsers(dest="command", required=True)
    cal = sub.add_parser("calendar-import")
    cal.add_argument("--csv", type=Path, required=True)
    gdelt = sub.add_parser("gdelt")
    gdelt.add_argument("--since", default=(datetime.now(timezone.utc)-timedelta(days=1)).strftime("%Y-%m-%d"))
    gdelt.add_argument("--max-days", type=int, default=7)
    gdelt.add_argument("--query", default=None)
    gdelt.add_argument("--symbol", default="XAUUSD")
    gdelt.add_argument("--sleep-seconds", type=float, default=1.0)
    headlines = sub.add_parser("headlines-import")
    headlines.add_argument("--csv", type=Path, required=True)
    headlines.add_argument("--symbol", default="XAUUSD")
    overlay = sub.add_parser("overlay")
    overlay.add_argument("--symbol", required=True)
    overlay.add_argument("--common-files", type=Path, required=True)
    overlay.add_argument("--server-utc-offset-hours", type=float, required=True)
    overlay.add_argument("--lookback-days", type=int, default=30)
    overlay.add_argument("--max-records", type=int, default=200)
    status = sub.add_parser("status")
    status.add_argument("--symbol", required=True)
    status.add_argument("--timeframe", default="M15")
    args = p.parse_args()
    with connect(args.db) as db:
        if args.command == "calendar-import":
            print(f"Imported calendar events: {import_calendar(db,args.csv)}")
        elif args.command == "gdelt":
            since = datetime.fromisoformat(args.since).replace(tzinfo=timezone.utc)
            query=args.query or ('"bitcoin price"' if "BTC" in args.symbol.upper() else '"gold price"')
            print(f"Processed days: {collect_gdelt(db,since,args.max_days,query,args.sleep_seconds,args.symbol)}")
        elif args.command == "headlines-import":
            print(f"Imported headlines: {import_headlines(db,args.csv,args.symbol)}")
        else:
            if args.command == "status":
                for source,(count,first,last) in coverage_status(db,args.symbol,args.timeframe).items():
                    print(f"{source}: count={count}, earliest={first}, latest={last} (Unix seconds; calendar in server time)")
            else:
                path=args.common_files/f"MarketEvents_{args.symbol}.txt"
                print(f"Exported {export_overlay(db,path,args.lookback_days,args.server_utc_offset_hours,args.max_records,args.symbol)} markers to {path}")


if __name__ == "__main__":
    main()

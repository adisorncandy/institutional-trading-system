"""Summarize GoldSignalEA CSV logs with Python's standard library.

Usage: python report.py path/to/*_signals.csv path/to/*_exits.csv
"""
import argparse
import csv
from pathlib import Path


def rows(path):
    with open(path, encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def summarize(signals, exits):
    states = {}
    directions = {"BUY": 0, "SELL": 0}
    for row in signals:
        state = row["state"]
        states[state] = states.get(state, 0) + 1
        directions[row["direction"]] = directions.get(row["direction"], 0) + 1

    # These are exit executions. A partial close can create multiple rows.
    values = [float(row["net_exit"]) for row in exits]
    wins = [value for value in values if value > 0]
    losses = [value for value in values if value < 0]
    gross_win = sum(wins)
    gross_loss = -sum(losses)
    return {
        "signals": len(signals),
        "directions": directions,
        "states": states,
        "exit_deals": len(values),
        "win_rate_exit_deals_pct": 100 * len(wins) / len(values) if values else None,
        "net_exit_only": sum(values),
        "profit_factor_exit_only": gross_win / gross_loss if gross_loss else None,
        "average_exit": sum(values) / len(values) if values else None,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("signals", type=Path)
    parser.add_argument("exits", type=Path)
    args = parser.parse_args()
    result = summarize(rows(args.signals), rows(args.exits))
    for label, value in result.items():
        print(f"{label}: {value}")
    print("Note: entry commission, deposits and broker fees outside exit deals are not included.")
    print("Use MT5 Strategy Tester detailed report for full P/L, drawdown and trade-level metrics.")


if __name__ == "__main__":
    main()

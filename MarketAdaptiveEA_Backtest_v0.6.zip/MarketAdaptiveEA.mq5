// MarketAdaptiveEA v0.6 - conservative cost-aware model gate.
#property strict
#property version   "0.60"
#include <Trade/Trade.mqh>

input ENUM_TIMEFRAMES SignalTimeframe=PERIOD_M15;
input bool AlertOnly=true;                 // Safe default: signals without orders
input double RiskPercent=0.5;             // Per trade, percent of current equity
input double MaxDailyLossPercent=2.0;     // Pause new entries from daily equity baseline
input double MaxSpreadPoints=80.0;        // Broker points, not pips
input int MaxDeviationPoints=30;
input long MagicNumber=27092601;
input bool RequireModel=true;              // Fail closed if no fresh, matching model
input int MaxModelAgeHours=48;
input bool ShowNewsOverlay=true;
input int NewsLookbackDays=30;
input int MaxNewsMarkers=60;
input bool EnableLine=false;
input string LineChannelAccessToken="";
input string LineRecipientId="";         // User ID (U...), group ID (C...), room ID (R...)

CTrade trade;
int hFast=INVALID_HANDLE,hSlow=INVALID_HANDLE,hRsi=INVALID_HANDLE,hAtr=INVALID_HANDLE;
datetime lastBar=0;
string signalFile,dealFile,dayKey;
datetime lastNewsRefresh=0;
int fastPeriod=0,slowPeriod=0,holdBars=0;
double buyMin=0,buyMax=0,sellMin=0,sellMax=0,stopFactor=0,targetFactor=0,spreadAtrLimit=0;
long effectiveMagic=0;

string SetupProfile()
{
   buyMin=50; buyMax=70; sellMin=30; sellMax=50;
   if(SignalTimeframe==PERIOD_M5)
   { fastPeriod=20; slowPeriod=100; buyMin=52; buyMax=68; sellMin=32; sellMax=48;
     stopFactor=1.6; targetFactor=2.4; holdBars=12; spreadAtrLimit=0.20; return "TFP6_M5"; }
   if(SignalTimeframe==PERIOD_M15)
   { fastPeriod=34; slowPeriod=144; stopFactor=1.8; targetFactor=2.7; holdBars=16; spreadAtrLimit=0.20; return "TFP6_M15"; }
   if(SignalTimeframe==PERIOD_M30)
   { fastPeriod=50; slowPeriod=200; stopFactor=2.0; targetFactor=3.0; holdBars=18; spreadAtrLimit=0.18; return "TFP6_M30"; }
   if(SignalTimeframe==PERIOD_H1)
   { fastPeriod=50; slowPeriod=200; buyMin=52; buyMax=72; sellMin=28; sellMax=48;
     stopFactor=2.2; targetFactor=3.3; holdBars=24; spreadAtrLimit=0.15; return "TFP6_H1"; }
   if(SignalTimeframe==PERIOD_H4)
   { fastPeriod=34; slowPeriod=144; buyMin=52; buyMax=72; sellMin=28; sellMax=48;
     stopFactor=2.5; targetFactor=3.75; holdBars=18; spreadAtrLimit=0.12; return "TFP6_H4"; }
   return "";
}

void DrawNews()
{
   if(!ShowNewsOverlay || MQLInfoInteger(MQL_TESTER)!=0 || NewsLookbackDays<=0 || MaxNewsMarkers<=0) return;
   if(TimeLocal()-lastNewsRefresh<300) return;
   lastNewsRefresh=TimeLocal();
   int f=FileOpen("MarketEvents_"+_Symbol+".txt",FILE_READ|FILE_TXT|FILE_COMMON|FILE_ANSI,0,CP_UTF8);
   if(f==INVALID_HANDLE) return;
   if(FileReadString(f)!="GOLD_EVENTS_V1") { FileClose(f); return; }
   int count=0;
   while(!FileIsEnding(f) && count<MaxNewsMarkers)
   {
      string line=FileReadString(f),parts[];
      if(StringSplit(line,'|',parts)!=5) continue;
      datetime when=(datetime)StringToInteger(parts[0]);
      if(when<TimeTradeServer()-(long)NewsLookbackDays*86400 || when>TimeTradeServer()+86400) continue;
      string name="GSEA_NEWS_"+IntegerToString((long)when)+"_"+IntegerToString(count);
      if(ObjectFind(0,name)<0 && ObjectCreate(0,name,OBJ_VLINE,0,when,0))
      {
         ObjectSetInteger(0,name,OBJPROP_COLOR,parts[1]=="MT5_CALENDAR"?clrOrange:clrDeepSkyBlue);
         ObjectSetInteger(0,name,OBJPROP_STYLE,STYLE_DOT);
         ObjectSetInteger(0,name,OBJPROP_BACK,true);
         ObjectSetString(0,name,OBJPROP_TOOLTIP,parts[1]+" | "+parts[2]+" | "+parts[3]+" | "+parts[4]);
      }
      count++;
   }
   FileClose(f);
}

string NearbyNews(datetime at)
{
   int f=FileOpen("MarketEvents_"+_Symbol+".txt",FILE_READ|FILE_TXT|FILE_COMMON|FILE_ANSI,0,CP_UTF8);
   if(f==INVALID_HANDLE) return "";
   if(FileReadString(f)!="GOLD_EVENTS_V1") { FileClose(f); return ""; }
   string best="";
   long closest=3601;
   while(!FileIsEnding(f))
   {
      string line=FileReadString(f),parts[];
      if(StringSplit(line,'|',parts)!=5) continue;
      long difference=(long)at-StringToInteger(parts[0]);
      if(difference<0 || difference>3600 || difference>=closest) continue; // Already published in prior hour
      closest=difference;
      best=parts[1]+": "+StringSubstr(parts[3],0,80);
   }
   FileClose(f);
   return best;
}

string ModelFileName()
{
   return "MarketAdaptive_"+_Symbol+"_"+EnumToString(SignalTimeframe)+".txt";
}

bool ModelQualifies(bool buy,double rsi,double fast,double slow,double atr)
{
   if(!RequireModel) return true;
   if(MQLInfoInteger(MQL_TESTER)!=0) return false; // Never use a future-trained live model in historical tester
   int f=FileOpen(ModelFileName(),FILE_READ|FILE_TXT|FILE_COMMON|FILE_ANSI,0,CP_UTF8);
   if(f==INVALID_HANDLE) return false;
   string header=FileReadString(f), parts[];
   if(StringSplit(header,'|',parts)!=6 || parts[0]!="MAEA6" || parts[1]!=_Symbol ||
      parts[2]!=EnumToString(SignalTimeframe) ||
      MathAbs(StringToDouble(parts[4])-MaxSpreadPoints)>0.0001 || parts[5]!=SetupProfile())
   { FileClose(f); return false; }
   long age=(long)TimeGMT()-(long)StringToInteger(parts[3]);
   if(age<0 || age>(long)MaxModelAgeHours*3600) { FileClose(f); return false; }
   string key=(buy?"BUY":"SELL")+"_R"+IntegerToString((buy?rsi>=60:rsi<=40)?1:0)+
              "_T"+IntegerToString(MathAbs(fast-slow)>=0.5*atr?1:0);
   bool accepted=false;
   while(!FileIsEnding(f))
      if(FileReadString(f)==key) accepted=true;
   FileClose(f);
   return accepted;
}

void CloseExpiredPosition()
{
   if(AlertOnly) return;
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0 || !PositionSelectByTicket(ticket) || PositionGetString(POSITION_SYMBOL)!=_Symbol ||
         PositionGetInteger(POSITION_MAGIC)!=effectiveMagic) continue;
      int age=iBarShift(_Symbol,SignalTimeframe,(datetime)PositionGetInteger(POSITION_TIME),false);
      if(age>=holdBars && !trade.PositionClose(ticket))
         Print("Time exit failed, ticket=",ticket," retcode=",trade.ResultRetcode());
   }
}

string JsonEscape(string s)
{
   StringReplace(s,"\\","\\\\");
   StringReplace(s,"\"","\\\"");
   StringReplace(s,"\r","");
   StringReplace(s,"\n","\\n");
   return s;
}

void SendLine(string message)
{
   if(!EnableLine || MQLInfoInteger(MQL_TESTER)!=0) return;
   if(LineChannelAccessToken=="" || LineRecipientId=="") { Print("LINE: missing token or recipient ID"); return; }
   string url="https://api.line.me/v2/bot/message/push";
   string headers="Content-Type: application/json\r\nAuthorization: Bearer "+LineChannelAccessToken+"\r\n";
   string body="{\"to\":\""+JsonEscape(LineRecipientId)+"\",\"messages\":[{\"type\":\"text\",\"text\":\""+JsonEscape(message)+"\"}]}";
   char payload[],response[];
   string responseHeaders;
   int bytes=StringToCharArray(body,payload,0,WHOLE_ARRAY,CP_UTF8);
   if(bytes>0) ArrayResize(payload,bytes-1); // Exclude terminating NUL from JSON
   ResetLastError();
   int status=WebRequest("POST",url,headers,3000,payload,response,responseHeaders);
   if(status!=200) PrintFormat("LINE push failed: HTTP %d, MT5 error %d",status,GetLastError());
}

int OpenLog(string name,string header)
{
   int f=FileOpen(name,FILE_READ|FILE_WRITE|FILE_CSV|FILE_COMMON|FILE_ANSI,',',CP_UTF8);
   if(f==INVALID_HANDLE) { PrintFormat("CSV open failed %s: %d",name,GetLastError()); return f; }
   if(FileSize(f)==0) FileWriteString(f,header+"\r\n");
   FileSeek(f,0,SEEK_END);
   return f;
}

void LogSignal(datetime bar,string direction,double entry,double sl,double tp,double atr,double rsi,double spread,string state)
{
   int f=OpenLog(signalFile,"server_time,bar_time,symbol,timeframe,direction,entry,sl,tp,atr,rsi,spread_points,state");
   if(f==INVALID_HANDLE) return;
   FileWrite(f,TimeToString(TimeCurrent(),TIME_DATE|TIME_SECONDS),TimeToString(bar,TIME_DATE|TIME_SECONDS),
             _Symbol,EnumToString(SignalTimeframe),direction,DoubleToString(entry,_Digits),
             DoubleToString(sl,_Digits),DoubleToString(tp,_Digits),DoubleToString(atr,_Digits),
             DoubleToString(rsi,2),DoubleToString(spread,1),state);
   FileClose(f);
}

string DailyBaselineKey()
{
   MqlDateTime t; TimeToStruct(TimeCurrent(),t);
   return "GSEA."+IntegerToString((long)AccountInfoInteger(ACCOUNT_LOGIN))+"."+
          IntegerToString(t.year)+"."+IntegerToString(t.mon)+"."+IntegerToString(t.day);
}

double DailyBaseline()
{
   string key=DailyBaselineKey();
   if(!GlobalVariableCheck(key)) GlobalVariableSet(key,AccountInfoDouble(ACCOUNT_EQUITY));
   return GlobalVariableGet(key);
}

bool HasSymbolPosition()
{
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket>0 && PositionSelectByTicket(ticket) && PositionGetString(POSITION_SYMBOL)==_Symbol)
         return true; // Protect netting and hedging accounts from overlapping symbol exposure
   }
   return false;
}

double LotsForRisk(ENUM_ORDER_TYPE side,double entry,double sl)
{
   double lossOneLot=0;
   if(!OrderCalcProfit(side,_Symbol,1.0,entry,sl,lossOneLot) || lossOneLot>=0) return 0;
   double budget=AccountInfoDouble(ACCOUNT_EQUITY)*RiskPercent/100.0;
   double minLot=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double maxLot=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   double step=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   if(budget<=0 || step<=0 || minLot<=0) return 0;
   double lots=MathFloor((budget/(-lossOneLot)+1e-9)/step)*step;
   lots=MathMin(lots,maxLot);
   lots=NormalizeDouble(lots,8);
   if(lots<minLot) return 0; // Never round up to minimum lot and exceed budget
   double margin=0;
   if(!OrderCalcMargin(side,_Symbol,lots,entry,margin) || margin>AccountInfoDouble(ACCOUNT_MARGIN_FREE)*0.9) return 0;
   return lots;
}

void MarkSignal(datetime bar,bool buy,double price)
{
   string name="GSEA_"+IntegerToString((long)bar)+"_"+(buy?"B":"S");
   if(ObjectFind(0,name)>=0) return;
   if(ObjectCreate(0,name,buy?OBJ_ARROW_BUY:OBJ_ARROW_SELL,0,bar,price))
      ObjectSetInteger(0,name,OBJPROP_COLOR,buy?clrLimeGreen:clrTomato);
}

void ProcessBar(datetime bar)
{
   if(Bars(_Symbol,SignalTimeframe)<slowPeriod+5) return;
   double fast[2],slow[2],rsi[1],atr[1],close1=iClose(_Symbol,SignalTimeframe,1),close2=iClose(_Symbol,SignalTimeframe,2);
   // CopyBuffer start=1, count=2 returns older at [0], latest closed at [1].
   if(CopyBuffer(hFast,0,1,2,fast)!=2 || CopyBuffer(hSlow,0,1,2,slow)!=2 ||
      CopyBuffer(hRsi,0,1,1,rsi)!=1 || CopyBuffer(hAtr,0,1,1,atr)!=1) return;
   if(close1<=0 || close2<=0 || atr[0]<=0) return;
   bool buy=(fast[1]>slow[1] && close2<=fast[0] && close1>fast[1] && rsi[0]>=buyMin && rsi[0]<=buyMax);
   bool sell=(fast[1]<slow[1] && close2>=fast[0] && close1<fast[1] && rsi[0]>=sellMin && rsi[0]<=sellMax);
   if(!buy && !sell) return;

   MqlTick tick;
   if(!SymbolInfoTick(_Symbol,tick) || tick.ask<=0 || tick.bid<=0) return;
   double spread=(tick.ask-tick.bid)/_Point;
   if(spread>MaxSpreadPoints || spread*_Point>spreadAtrLimit*atr[0]) return;
   double entry=buy?tick.ask:tick.bid;
   double minStop=(double)SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL)*_Point+2*_Point;
   double stopDistance=MathMax(stopFactor*atr[0],minStop+spread*_Point);
   double targetDistance=MathMax(targetFactor*atr[0],minStop+spread*_Point);
   double sl=NormalizeDouble(entry+(buy?-stopDistance:stopDistance),_Digits);
   double tp=NormalizeDouble(entry+(buy?targetDistance:-targetDistance),_Digits);
   string direction=buy?"BUY":"SELL";
   double baseline=DailyBaseline();
   bool paused=(baseline>0 && AccountInfoDouble(ACCOUNT_EQUITY)<=baseline*(1-MaxDailyLossPercent/100.0));
   bool occupied=HasSymbolPosition();
   if(!ModelQualifies(buy,rsi[0],fast[1],slow[1],atr[0]))
   {
      LogSignal(bar,direction,entry,sl,tp,atr[0],rsi[0],spread,"MODEL_NOT_QUALIFIED");
      return; // No buy/sell recommendation and no order if evidence gate is unavailable
   }
   string state=paused?"PAUSED_DAILY_LOSS":(occupied?"SYMBOL_POSITION_OPEN":(AlertOnly?"ALERT_ONLY":"ORDER_PENDING"));
   MarkSignal(bar,buy,close1);
   string msg=StringFormat("MarketAdaptiveEA %s %s %s\nEntry ~%s | SL %s | TP %s\nRSI %.1f | ATR %s | Spread %.1f pts\n%s | %s",
                           _Symbol,EnumToString(SignalTimeframe),direction,
                           DoubleToString(entry,_Digits),DoubleToString(sl,_Digits),DoubleToString(tp,_Digits),
                           rsi[0],DoubleToString(atr[0],_Digits),spread,state,TimeToString(bar,TIME_DATE|TIME_MINUTES));
   string context=NearbyNews(TimeTradeServer());
   if(context!="") msg+="\nRecent news (context only): "+context;
   if(!AlertOnly && !paused && !occupied)
   {
      ENUM_ORDER_TYPE side=buy?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
      double lots=LotsForRisk(side,entry,sl);
      if(lots<=0) { state="NO_SAFE_VOLUME_OR_MARGIN"; }
      else if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED)) state="TRADING_DISABLED";
      else
      {
         bool sent=buy?trade.Buy(lots,_Symbol,0,sl,tp,"GSEA"):
                       trade.Sell(lots,_Symbol,0,sl,tp,"GSEA");
         uint rc=trade.ResultRetcode();
         state=(sent && (rc==TRADE_RETCODE_DONE || rc==TRADE_RETCODE_DONE_PARTIAL))?"ORDER_FILLED":"ORDER_REJECTED";
         msg+="\nOrder "+state+" | lots "+DoubleToString(lots,2)+" | retcode "+IntegerToString((int)rc);
      }
   }
   LogSignal(bar,direction,entry,sl,tp,atr[0],rsi[0],spread,state);
   Alert(msg);
   SendLine(msg);
}

void ShowPanel()
{
   double baseline=DailyBaseline(),equity=AccountInfoDouble(ACCOUNT_EQUITY);
   int exits=0,wins=0; double net=0;
   if(HistorySelect(TimeCurrent()-90*86400,TimeCurrent()))
   {
      for(int i=0;i<HistoryDealsTotal();i++)
      {
         ulong ticket=HistoryDealGetTicket(i);
         if(HistoryDealGetString(ticket,DEAL_SYMBOL)!=_Symbol || HistoryDealGetInteger(ticket,DEAL_MAGIC)!=effectiveMagic) continue;
         ENUM_DEAL_ENTRY e=(ENUM_DEAL_ENTRY)HistoryDealGetInteger(ticket,DEAL_ENTRY);
         if(e!=DEAL_ENTRY_OUT && e!=DEAL_ENTRY_INOUT && e!=DEAL_ENTRY_OUT_BY) continue;
         double pnl=HistoryDealGetDouble(ticket,DEAL_PROFIT)+HistoryDealGetDouble(ticket,DEAL_SWAP)+HistoryDealGetDouble(ticket,DEAL_COMMISSION);
         net+=pnl; exits++; if(pnl>0) wins++;
      }
   }
   Comment("MarketAdaptiveEA | ",_Symbol," | ",EnumToString(SignalTimeframe)," | ",(AlertOnly?"SIGNAL ONLY":"AUTO"),
           "\nEquity: ",DoubleToString(equity,2)," | Day start: ",DoubleToString(baseline,2),
           "\nLast 90 days: ",exits," exit deals | wins ",wins," | net ",DoubleToString(net,2)," ",AccountInfoString(ACCOUNT_CURRENCY),
           "\nWin rate is per exit deal; commissions on entry may be excluded.");
}

int OnInit()
{
   if(RiskPercent<=0 || RiskPercent>5 ||
      MaxDailyLossPercent<=0 || MaxDailyLossPercent>20 || MaxSpreadPoints<=0 || MagicNumber<=0 ||
      NewsLookbackDays<1 || MaxNewsMarkers<1 || MaxNewsMarkers>500)
      return INIT_PARAMETERS_INCORRECT;
   string profile=SetupProfile();
   if(profile=="") { Print("Supported: M5 M15 M30 H1 H4"); return INIT_PARAMETERS_INCORRECT; }
   effectiveMagic=MagicNumber+PeriodSeconds(SignalTimeframe)/60;
   hFast=iMA(_Symbol,SignalTimeframe,fastPeriod,0,MODE_EMA,PRICE_CLOSE);
   hSlow=iMA(_Symbol,SignalTimeframe,slowPeriod,0,MODE_EMA,PRICE_CLOSE);
   hRsi=iRSI(_Symbol,SignalTimeframe,14,PRICE_CLOSE);
   hAtr=iATR(_Symbol,SignalTimeframe,14);
   if(hFast==INVALID_HANDLE || hSlow==INVALID_HANDLE || hRsi==INVALID_HANDLE || hAtr==INVALID_HANDLE) return INIT_FAILED;
   trade.SetExpertMagicNumber(effectiveMagic);
   trade.SetDeviationInPoints(MaxDeviationPoints);
   trade.SetTypeFillingBySymbol(_Symbol);
   signalFile="MarketAdaptiveEA_"+_Symbol+"_"+EnumToString(SignalTimeframe)+"_"+IntegerToString(effectiveMagic)+"_signals.csv";
   dealFile="MarketAdaptiveEA_"+_Symbol+"_"+EnumToString(SignalTimeframe)+"_"+IntegerToString(effectiveMagic)+"_exits.csv";
   DailyBaseline();
   lastBar=iTime(_Symbol,SignalTimeframe,0); // Avoid stale alert immediately upon attaching EA
   EventSetTimer(60);
   Print("MarketAdaptiveEA profile=",profile," AlertOnly=",AlertOnly," magic=",effectiveMagic);
   return INIT_SUCCEEDED;
}

void OnTick()
{
   datetime bar=iTime(_Symbol,SignalTimeframe,0);
   if(bar<=0 || bar==lastBar) return;
   lastBar=bar;
   CloseExpiredPosition();
   ProcessBar(iTime(_Symbol,SignalTimeframe,1));
   ShowPanel();
}

void OnTimer() { ShowPanel(); DrawNews(); }

void OnTradeTransaction(const MqlTradeTransaction &trans,const MqlTradeRequest &request,const MqlTradeResult &result)
{
   if(trans.type!=TRADE_TRANSACTION_DEAL_ADD || trans.deal==0) return;
   if(!HistoryDealSelect(trans.deal)) return;
   if(HistoryDealGetString(trans.deal,DEAL_SYMBOL)!=_Symbol || HistoryDealGetInteger(trans.deal,DEAL_MAGIC)!=effectiveMagic) return;
   ENUM_DEAL_ENTRY e=(ENUM_DEAL_ENTRY)HistoryDealGetInteger(trans.deal,DEAL_ENTRY);
   if(e!=DEAL_ENTRY_OUT && e!=DEAL_ENTRY_INOUT && e!=DEAL_ENTRY_OUT_BY) return;
   double pnl=HistoryDealGetDouble(trans.deal,DEAL_PROFIT)+HistoryDealGetDouble(trans.deal,DEAL_SWAP)+HistoryDealGetDouble(trans.deal,DEAL_COMMISSION);
   int f=OpenLog(dealFile,"server_time,deal,position_id,symbol,volume,exit_price,profit,swap,commission,net_exit,currency");
   if(f!=INVALID_HANDLE)
   {
      FileWrite(f,TimeToString((datetime)HistoryDealGetInteger(trans.deal,DEAL_TIME),TIME_DATE|TIME_SECONDS),
                (long)trans.deal,(long)HistoryDealGetInteger(trans.deal,DEAL_POSITION_ID),_Symbol,
                DoubleToString(HistoryDealGetDouble(trans.deal,DEAL_VOLUME),2),
                DoubleToString(HistoryDealGetDouble(trans.deal,DEAL_PRICE),_Digits),
                DoubleToString(HistoryDealGetDouble(trans.deal,DEAL_PROFIT),2),
                DoubleToString(HistoryDealGetDouble(trans.deal,DEAL_SWAP),2),
                DoubleToString(HistoryDealGetDouble(trans.deal,DEAL_COMMISSION),2),
                DoubleToString(pnl,2),AccountInfoString(ACCOUNT_CURRENCY));
      FileClose(f);
   }
   SendLine(StringFormat("MarketAdaptiveEA %s exit deal %I64u | net exit %.2f %s",_Symbol,trans.deal,pnl,AccountInfoString(ACCOUNT_CURRENCY)));
}

void OnDeinit(const int reason)
{
   EventKillTimer(); Comment("");
   if(hFast!=INVALID_HANDLE) IndicatorRelease(hFast);
   if(hSlow!=INVALID_HANDLE) IndicatorRelease(hSlow);
   if(hRsi!=INVALID_HANDLE) IndicatorRelease(hRsi);
   if(hAtr!=INVALID_HANDLE) IndicatorRelease(hAtr);
}

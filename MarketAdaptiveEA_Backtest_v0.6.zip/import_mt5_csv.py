"""Import MT5 bar-export CSV/TSV into the same SQLite schema as run_assets.py.

Example: python import_mt5_csv.py --file XAUUSD_M15.csv --symbol XAUUSD
  --timeframe M15 --server-utc-offset-hours 2 --db market_history.sqlite
"""
import argparse
import csv
import sqlite3
from datetime import datetime, timezone, timedelta
from pathlib import Path


def clean(name):
    return name.strip().upper().strip("<>").replace(" ", "")


def import_bars(path, db, symbol, timeframe, offset_hours):
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        sample=stream.read(4096)
        stream.seek(0)
        delimiter="\t" if sample.count("\t")>sample.count(",") else ","
        reader=csv.DictReader(stream,delimiter=delimiter)
        if reader.fieldnames is None:
            raise ValueError("Empty MT5 export")
        names={clean(n):n for n in reader.fieldnames}
        needed={"DATE","TIME","OPEN","HIGH","LOW","CLOSE"}
        if not needed.issubset(names):
            raise ValueError(f"Expected DATE,TIME,OPEN,HIGH,LOW,CLOSE; found {reader.fieldnames}")
        rows=[]
        offset=timezone(timedelta(hours=offset_hours))
        for row in reader:
            raw_date=row[names["DATE"]].strip().replace(".","-")
            raw_time=row[names["TIME"]].strip()
            parsed=datetime.fromisoformat(raw_date+"T"+raw_time).replace(tzinfo=offset)
            open_,high,low,close=(float(row[names[k]]) for k in ("OPEN","HIGH","LOW","CLOSE"))
            if not (low<=min(open_,close)<=max(open_,close)<=high):
                raise ValueError(f"Invalid OHLC at {raw_date} {raw_time}")
            spread=int(float(row[names["SPREAD"]])) if "SPREAD" in names and row[names["SPREAD"]] else 0
            tick_key=names.get("TICKVOL",names.get("TICKVOLUME"))
            tick_volume=int(float(row[tick_key])) if tick_key and row[tick_key] else 0
            rows.append((symbol,timeframe,int(parsed.timestamp()),open_,high,low,close,spread,tick_volume))
    if not rows:
        raise ValueError("CSV contains no bars")
    db.parent.mkdir(parents=True,exist_ok=True)
    with sqlite3.connect(db) as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS bars (symbol TEXT, timeframe TEXT, time_utc INTEGER, open REAL, high REAL, low REAL, close REAL, spread INTEGER, tick_volume INTEGER, PRIMARY KEY(symbol,timeframe,time_utc))")
        conn.executemany("INSERT OR REPLACE INTO bars VALUES (?,?,?,?,?,?,?,?,?)",rows)
        conn.commit()
    return len(rows),min(r[2] for r in rows),max(r[2] for r in rows)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--file",required=True,type=Path)
    p.add_argument("--symbol",required=True)
    p.add_argument("--timeframe",required=True,choices=["M5","M15","M30","H1","H4"])
    p.add_argument("--server-utc-offset-hours",required=True,type=float,
                   help="Fixed offset for the export period; split historical DST periods if offset changes")
    p.add_argument("--db",type=Path,default=Path("market_history.sqlite"))
    args=p.parse_args()
    count,first,last=import_bars(args.file,args.db,args.symbol,args.timeframe,args.server_utc_offset_hours)
    print(f"Imported {count} bars {args.symbol}/{args.timeframe}: {datetime.fromtimestamp(first,timezone.utc)} .. {datetime.fromtimestamp(last,timezone.utc)}")
    print("Verify historical server UTC offsets, spread units and missing bars before interpreting backtest results.")


if __name__=="__main__":
    main()

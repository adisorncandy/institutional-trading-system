"""Broker-history collection and chronological, selective signal research.

Requires Python on the same Windows PC/VPS as a running, logged-in MT5 terminal:
    pip install MetaTrader5
    python adaptive_research.py --symbol XAUUSD --timeframe M15 --common-files ".../Terminal/Common/Files"

This is a research gate, not a trained forecast or a claim of 90% live accuracy.
"""
from __future__ import annotations

import argparse
import csv
import math
import sqlite3
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from trade_simulation import simulate_trade


@dataclass(frozen=True)
class Profile:
    tag: str
    fast: int
    slow: int
    buy_min: float
    buy_max: float
    sell_min: float
    sell_max: float
    stop_atr: float
    target_atr: float
    hold: int
    spread_atr_limit: float


PROFILES = {
    "M5": Profile("TFP6_M5",20,100,52,68,32,48,1.6,2.4,12,0.20),
    "M15": Profile("TFP6_M15",34,144,50,70,30,50,1.8,2.7,16,0.20),
    "M30": Profile("TFP6_M30",50,200,50,70,30,50,2.0,3.0,18,0.18),
    "H1": Profile("TFP6_H1",50,200,52,72,28,48,2.2,3.3,24,0.15),
    "H4": Profile("TFP6_H4",34,144,52,72,28,48,2.5,3.75,18,0.12),
}


def ema(values, period):
    out = [None] * len(values)
    if len(values) < period:
        return out
    seed = sum(values[:period]) / period
    out[period - 1] = seed
    alpha = 2 / (period + 1)
    for i in range(period, len(values)):
        out[i] = alpha * values[i] + (1 - alpha) * out[i - 1]
    return out


def wilders(values, period):
    out = [None] * len(values)
    if len(values) <= period:
        return out
    prev = sum(values[1:period + 1]) / period
    out[period] = prev
    for i in range(period + 1, len(values)):
        prev = (prev * (period - 1) + values[i]) / period
        out[i] = prev
    return out


def indicators(bars, profile=PROFILES["M15"]):
    closes = [b[4] for b in bars]
    fast, slow = ema(closes, profile.fast), ema(closes, profile.slow)
    gains = [0.0] + [max(closes[i] - closes[i - 1], 0) for i in range(1, len(bars))]
    losses = [0.0] + [max(closes[i - 1] - closes[i], 0) for i in range(1, len(bars))]
    avg_gain, avg_loss = wilders(gains, 14), wilders(losses, 14)
    rsi = [None if g is None else (100.0 if l == 0 else 100 - 100 / (1 + g / l))
           for g, l in zip(avg_gain, avg_loss)]
    tr = [0.0] + [max(bars[i][2] - bars[i][3], abs(bars[i][2] - closes[i - 1]),
                        abs(bars[i][3] - closes[i - 1])) for i in range(1, len(bars))]
    atr = wilders(tr, 14)
    return fast, slow, rsi, atr


def key_for(side, rsi, fast, slow, atr):
    band = 1 if (rsi >= 60 if side == "BUY" else rsi <= 40) else 0
    trend = 1 if abs(fast - slow) >= 0.5 * atr else 0
    return f"{side}_R{band}_T{trend}"


def candidates(bars, point, fallback_spread, max_spread=80.0, profile=PROFILES["M15"],
               slippage_points=5.0, roundtrip_fee_points=0.0):
    fast, slow, rsi, atr = indicators(bars,profile)
    max_hold=profile.hold
    for i in range(profile.slow+1, len(bars) - max_hold - 2):
        if any(x is None for x in (fast[i - 1], fast[i], slow[i], rsi[i], atr[i])):
            continue
        side = None
        if fast[i] > slow[i] and bars[i - 1][4] <= fast[i - 1] and bars[i][4] > fast[i] and profile.buy_min <= rsi[i] <= profile.buy_max:
            side = "BUY"
        elif fast[i] < slow[i] and bars[i - 1][4] >= fast[i - 1] and bars[i][4] < fast[i] and profile.sell_min <= rsi[i] <= profile.sell_max:
            side = "SELL"
        if side is None:
            continue
        spread_points = bars[i + 1][5] if bars[i + 1][5] > 0 else fallback_spread
        if spread_points <= 0 or spread_points > max_spread or spread_points*point > profile.spread_atr_limit*atr[i]:
            continue
        result=simulate_trade(bars,i,side,atr[i],point,fallback_spread,
                              slippage_points,roundtrip_fee_points,profile)
        yield bars[i][0], key_for(side, rsi[i], fast[i], slow[i], atr[i]), int(result["R"]>0)


def wilson_lower(wins, count, z=1.96):
    if count == 0:
        return 0.0
    p = wins / count
    den = 1 + z*z/count
    return (p + z*z/(2*count) - z*math.sqrt(p*(1-p)/count + z*z/(4*count*count))) / den


def fit_gate(samples, target=0.90, min_train=60, min_validation=30, bar_seconds=900, max_hold=16):
    """60/20/20 chronological split. Test stays untouched for reporting only."""
    n = len(samples)
    first, second = int(n * 0.6), int(n * 0.8)
    # Embargo signals whose maximum holding window crosses a split.
    val_start, test_start = samples[first][0], samples[second][0]
    parts = [[s for s in samples[:first] if s[0] + (max_hold+1)*bar_seconds < val_start],
             [s for s in samples[first:second] if s[0] + (max_hold+1)*bar_seconds < test_start],
             samples[second:]]
    stats = [defaultdict(lambda: [0, 0]) for _ in parts]
    for store, subset in zip(stats, parts):
        for _, key, win in subset:
            store[key][0] += win
            store[key][1] += 1
    eligible = set()
    for key in stats[0].keys():
        wt, nt = stats[0][key]
        wv, nv = stats[1][key]
        if nt >= min_train and nv >= min_validation and wilson_lower(wt, nt) >= target and wilson_lower(wv, nv) >= target:
            eligible.add(key)
    test_selected = [win for _, key, win in parts[2] if key in eligible]
    audit = {
        "candidates_total": n,
        "train_count": len(parts[0]),
        "validation_count": len(parts[1]),
        "test_count": len(parts[2]),
        "selected_keys": sorted(eligible),
        "untouched_test_selected_count": len(test_selected),
        "untouched_test_selected_win_rate": (sum(test_selected)/len(test_selected) if test_selected else None),
        "untouched_test_selected_wilson_lower": wilson_lower(sum(test_selected), len(test_selected)),
        "warning": "OHLC approximation; no tick-level path, slippage, commission or swap. Not a live guarantee.",
    }
    return eligible, audit


def fetch_mt5(symbol, timeframe, years, db):
    try:
        import MetaTrader5 as mt5
    except ImportError as exc:
        raise RuntimeError("Install MetaTrader5 on Windows with the running MT5 terminal") from exc
    if not mt5.initialize():
        raise RuntimeError(f"MT5 initialize failed: {mt5.last_error()}")
    try:
        tf = getattr(mt5, "TIMEFRAME_" + timeframe)
        info = mt5.symbol_info(symbol)
        if info is None:
            raise RuntimeError(f"Symbol {symbol!r} is unavailable in this terminal")
        mt5.symbol_select(symbol, True)
        end = datetime.now(timezone.utc)
        start = end - timedelta(days=365.25 * years)
        cursor = start
        count = 0
        while cursor < end:
            nxt = min(cursor + timedelta(days=30), end)
            rates = mt5.copy_rates_range(symbol, tf, cursor, nxt)
            if rates is None:
                raise RuntimeError(f"copy_rates_range failed: {mt5.last_error()}")
            data = [(symbol, timeframe, int(r["time"]), float(r["open"]), float(r["high"]),
                     float(r["low"]), float(r["close"]), int(r["spread"]), int(r["tick_volume"])) for r in rates]
            db.executemany("INSERT OR REPLACE INTO bars VALUES (?,?,?,?,?,?,?,?,?)", data)
            db.commit()
            count += len(data)
            cursor = nxt  # Overlap boundary; primary key deduplicates any repeated bar.
        return info.point, count
    finally:
        mt5.shutdown()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--symbol", required=True, help="Exact broker symbol, e.g. XAUUSDm")
    p.add_argument("--timeframe", default="M15", choices=["M5", "M15", "M30", "H1", "H4"])
    p.add_argument("--years", type=float, default=10.0)
    p.add_argument("--common-files", required=True, type=Path, help="MT5 Terminal/Common/Files directory")
    p.add_argument("--db", type=Path, default=Path("market_history.sqlite"))
    p.add_argument("--fallback-spread-points", type=float, default=0.0,
                   help="Only if historical spread missing. Set from broker observations.")
    p.add_argument("--max-spread-points", type=float, default=80.0)
    p.add_argument("--slippage-points", type=float, default=5.0)
    p.add_argument("--roundtrip-fee-points", type=float, default=0.0)
    p.add_argument("--trading-days-per-week", type=int, choices=[5,6,7], default=5)
    args = p.parse_args()
    if args.years < 1 or min(args.fallback_spread_points,args.slippage_points,args.roundtrip_fee_points)<0:
        p.error("years must be >= 1 and fallback spread non-negative")
    args.db.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(args.db) as db:
        db.execute("CREATE TABLE IF NOT EXISTS bars (symbol TEXT, timeframe TEXT, time_utc INTEGER, open REAL, high REAL, low REAL, close REAL, spread INTEGER, tick_volume INTEGER, PRIMARY KEY(symbol,timeframe,time_utc))")
        point, fetched = fetch_mt5(args.symbol, args.timeframe, args.years, db)
        bars = db.execute("SELECT time_utc,open,high,low,close,spread FROM bars WHERE symbol=? AND timeframe=? ORDER BY time_utc", (args.symbol,args.timeframe)).fetchall()
    if not bars:
        raise RuntimeError("No historical bars received")
    span_years = (bars[-1][0] - bars[0][0]) / (365.25*86400)
    if span_years < args.years - 0.025:
        raise RuntimeError(f"Only {span_years:.2f} years available; requested {args.years:.2f}. Increase MT5 Max bars in chart and ask broker for history. No model published.")
    bar_seconds = {"M5":300,"M15":900,"M30":1800,"H1":3600,"H4":14400}[args.timeframe]
    expected = span_years*365.25*args.trading_days_per_week/7*86400/bar_seconds
    coverage = len(bars)/expected if expected else 0
    if coverage < 0.8:
        raise RuntimeError(f"History coverage estimate only {coverage:.1%}; no model published. Load more broker history.")
    profile=PROFILES[args.timeframe]
    samples = list(candidates(bars, point, args.fallback_spread_points, args.max_spread_points,profile,
                              args.slippage_points,args.roundtrip_fee_points))
    if len(samples) < 100:
        raise RuntimeError(f"Only {len(samples)} labeled signals; no model published")
    eligible, audit = fit_gate(samples, bar_seconds=bar_seconds, max_hold=profile.hold)
    args.common_files.mkdir(parents=True, exist_ok=True)
    name = f"MarketAdaptive_{args.symbol}_PERIOD_{args.timeframe}.txt"
    destination = args.common_files / name
    generated = int(datetime.now(timezone.utc).timestamp())
    # Only publish a new gate if it can select something. Never silently retain an older gate.
    content = [f"MAEA6|{args.symbol}|PERIOD_{args.timeframe}|{generated}|{args.max_spread_points:.6f}|{profile.tag}"]
    content.extend(sorted(eligible))
    temp = destination.with_suffix(".tmp")
    temp.write_text("\n".join(content)+"\n", encoding="utf-8")
    temp.replace(destination)
    audit.update({"symbol":args.symbol,"timeframe":args.timeframe,"profile":profile.tag,
                  "fast_ema":profile.fast,"slow_ema":profile.slow,"max_hold_bars":profile.hold,
                  "stop_atr":profile.stop_atr,"target_atr":profile.target_atr,
                  "assumed_slippage_points":args.slippage_points,"assumed_roundtrip_fee_points":args.roundtrip_fee_points,
                  "historical_bars":len(bars),
                  "history_span_years":round(span_years,3),"earliest_bar_utc":datetime.fromtimestamp(bars[0][0],timezone.utc).isoformat(),
                  "latest_bar_utc":datetime.fromtimestamp(bars[-1][0],timezone.utc).isoformat(),
                  "estimated_bar_coverage":round(coverage,3),"assumed_trading_days_per_week":args.trading_days_per_week,
                  "bars_fetched":fetched,"model_file":str(destination),
                  "db_file":str(args.db),"point":point})
    with (args.db.parent / f"audit_{args.symbol}_{args.timeframe}.csv").open("w",newline="",encoding="utf-8") as stream:
        writer=csv.writer(stream)
        writer.writerow(["metric","value"])
        writer.writerows(audit.items())
    for k,v in audit.items():
        print(f"{k}: {v}")


if __name__ == "__main__":
    main()

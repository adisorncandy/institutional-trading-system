import sqlite3
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

from import_mt5_csv import import_bars


class ImportTests(unittest.TestCase):
    def test_mt5_tab_export_converts_server_time_and_spread(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            source=root/"bars.csv"
            source.write_text("<DATE>\t<TIME>\t<OPEN>\t<HIGH>\t<LOW>\t<CLOSE>\t<TICKVOL>\t<SPREAD>\n"
                              "2026.09.25\t10:15:00\t100\t102\t99\t101\t50\t15\n",encoding="utf-8")
            db=root/"prices.sqlite"
            n,first,last=import_bars(source,db,"XAUUSD","M15",2)
            self.assertEqual(n,1)
            self.assertEqual(first,int(datetime(2026,9,25,8,15,tzinfo=timezone.utc).timestamp()))
            with sqlite3.connect(db) as conn:
                self.assertEqual(conn.execute("SELECT spread FROM bars").fetchone()[0],15)


if __name__=="__main__":
    unittest.main()

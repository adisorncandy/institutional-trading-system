# MarketAdaptiveEA v0.6 — XAUUSD 10 ปี + BTCUSD 5 ปี พร้อม 5 Timeframes

ต้นแบบ EA สำหรับ MT5 ที่ทำงานกับ **กราฟทองคำและบิตคอยน์แยกกัน** พร้อมฐานข้อมูล SQLite, ตัวคัดกรองสัญญาณตามประวัติ, ข่าวบนกราฟ และ LINE Messaging API ค่าเริ่มต้นคือ `AlertOnly=true` (ไม่ส่งออเดอร์จริง) **ไม่มีข้อมูลราคา 10/5 ปีบรรจุอยู่ใน ZIP**; ต้องดึงจาก MT5 ที่เชื่อมโบรกเกอร์ของคุณก่อน และอาจดึงไม่ครบหากโบรกเกอร์ไม่มีข้อมูลย้อนหลัง

## สรุประบบ

| กราฟ | คำสั่งดึงราคา | เกณฑ์ข่าว | ค่า Spread เริ่มต้นในตัวอย่าง |
|---|---:|---|---:|
| XAUUSD (รวมชื่อที่มี suffix) | 10 ปี | ข่าวทองคำ + ปฏิทินเศรษฐกิจ USD | 80 broker points |
| BTCUSD (รวมชื่อที่มี suffix) | 5 ปี | ข่าว Bitcoin + ปฏิทินเศรษฐกิจ USD | 5,000 broker points |

ค่า Spread ของ BTC เป็น **ตัวอย่างเท่านั้น** หากโบรกเกอร์แสดง 2 ทศนิยม 5,000 points คือ 50 USD; สัญลักษณ์จริงอาจมีจำนวนทศนิยม สเปรด และชั่วโมงซื้อขายต่างกัน ต้องดู `Specification` ใน MT5 แล้วตั้งค่าให้ตรงกันระหว่างสคริปต์กับ EA

## โปรไฟล์ตามกรอบเวลา

ค่าต่อไปนี้เป็นสมมติฐานสำหรับการทดสอบ ไม่ใช่ผลพิสูจน์ว่ากำไรหรือแม่นยำกว่าโปรไฟล์อื่น ตัวสร้างเกณฑ์และ EA ใช้ค่าเดียวกัน

| Timeframe | ลักษณะ | EMA เร็ว/ช้า | RSI Buy / Sell | SL / TP (เท่า ATR) | ถือสูงสุด | สเปรดไม่เกิน ATR |
|---|---|---:|---|---:|---:|---:|
| M5 | ระยะสั้นมาก | 20/100 | 52–68 / 32–48 | 1.6 / 2.4 | 12 แท่ง | 20% |
| M15 | ระยะสั้น | 34/144 | 50–70 / 30–50 | 1.8 / 2.7 | 16 แท่ง | 20% |
| M30 | ระยะสั้นถึงกลาง | 50/200 | 50–70 / 30–50 | 2.0 / 3.0 | 18 แท่ง | 18% |
| H1 | ระยะกลาง | 50/200 | 52–72 / 28–48 | 2.2 / 3.3 | 24 แท่ง | 15% |
| H4 | ระยะยาวขึ้น | 34/144 | 52–72 / 28–48 | 2.5 / 3.75 | 18 แท่ง | 12% |

เพดานเวลาถือครอง M5 คือ 1 ชั่วโมง และ H4 คือ 72 ชั่วโมง หาก SL/TP ทำงานก่อนก็ปิดก่อน

## ติดตั้งราคาและโมเดลแยกสินทรัพย์

1. เปิด MT5 บน Windows หรือ Windows VPS และล็อกอินกับโบรกเกอร์ เพิ่ม `Max. bars in chart` ให้เพียงพอ; ติดตั้ง Python package `pip install MetaTrader5`
2. วาง `MarketAdaptiveEA.mq5` ใน `MQL5/Experts` และ `GoldCalendarExport.mq5` ใน `MQL5/Scripts` แล้ว Compile ใน MetaEditor
3. รันคำสั่งนี้จากโฟลเดอร์ชุดไฟล์ โดยแก้ชื่อสัญลักษณ์และโฟลเดอร์ Common/Files ให้ตรงกับเครื่อง:

```powershell
python run_assets.py --gold-symbol XAUUSD --btc-symbol BTCUSD --all-timeframes --db market_history.sqlite --common-files "C:\Users\YOUR_NAME\AppData\Roaming\MetaQuotes\Terminal\Common\Files" --gold-max-spread-points 80 --btc-max-spread-points 5000
```

`--all-timeframes` รัน 10 ชุดตามลำดับ (2 สินทรัพย์ × 5 Timeframes) อาจใช้เวลานานและต้องมีประวัติ M5 จำนวนมาก ข้อมูลอยู่ใน `market_history.sqlite` โดยแยก Symbol/Timeframe และรายงานแยก เช่น `audit_XAUUSD_M5.csv` ถึง `audit_BTCUSD_H4.csv` หากจะเริ่มกรอบเดียวใช้ `--timeframe M15` แทน ถ้า BTC ของโบรกเกอร์ซื้อขายเฉพาะ 5 วันต่อสัปดาห์ ให้เพิ่ม `--btc-trading-days 5`

ระบบจะปฏิเสธการเผยแพร่เกณฑ์ หากช่วงราคาที่ได้ไม่ใกล้ 10 หรือ 5 ปีตามที่ตั้งค่า หรือแท่งที่ได้ขาดเกินเกณฑ์ ตรวจ `earliest_bar_utc`, `latest_bar_utc`, `estimated_bar_coverage`, `selected_keys` และผลชุดทดสอบปลายทางในรายงานของ **แต่ละสินทรัพย์** หาก `selected_keys` ว่าง EA จะไม่มีคำแนะนำ Buy/Sell สำหรับกลุ่มนั้น

ไฟล์เกณฑ์ของรุ่นก่อนใช้กับ v0.6 ไม่ได้ ต้องรันตัวสร้างเกณฑ์ใหม่ก่อนเปิด `RequireModel=true` รุ่นนี้นับผลชนะของข้อมูลฝึก **หลังสมมติ slippage และค่าธรรมเนียมที่ตั้งไว้** ตาม `--gold-slippage-points`, `--btc-slippage-points`, `--gold-fee-points`, `--btc-fee-points` (ค่า fee ต้องแปลงเป็น points ต่อ roundtrip)

## วิเคราะห์และแจ้งเตือนแบบ Real Time

เปิดกราฟ XAUUSD และ BTCUSD แล้วติดตั้ง EA แยก instance ตั้ง `SignalTimeframe` เป็น M5/M15/M30/H1/H4 และ `MaxSpreadPoints` ให้ตรงกับตัวสร้างเกณฑ์ของสินทรัพย์นั้น EA รับ Tick แบบเรียลไทม์ แต่ยืนยันสัญญาณจาก **แท่งที่ปิดแล้ว** แสดง Entry โดยประมาณ, SL, TP และบันทึก CSV แยก Symbol/Timeframe พร้อม Magic Number ที่แยกตาม Timeframe โดยอัตโนมัติ

เปิดหลายกราฟเพื่อรับแจ้งเตือนพร้อมกันได้ แต่หากเปิด Auto Trading ให้เลือก **หนึ่ง Timeframe ต่อสินทรัพย์** ก่อน เพราะระบบป้องกันการเปิดสถานะซ้อนใน Symbol เดียวกัน และยังไม่ได้ทดสอบกลยุทธ์รวมหลาย Timeframes

เริ่มด้วย `RequireModel=true`, `AlertOnly=true`, `EnableLine=false`. เมื่อเตรียม LINE Official Account Messaging API แล้ว ให้ตั้ง `EnableLine=true`, `LineChannelAccessToken`, `LineRecipientId` และเพิ่ม `https://api.line.me` ใน MT5 → Tools → Options → Expert Advisors → Allow WebRequest. LINE Notify ยุติแล้ว; LINE ส่งจากบัญชี Official Account ตามจำนวนข้อความ/แพ็กเกจของบัญชีนั้น

ถ้าต้องการซื้อขายอัตโนมัติ ต้องทดสอบ Demo และตรวจ Lot ขั้นต่ำ, margin, spread, slippage และ Stop Level ของ **ทั้ง XAU และ BTC** ก่อนเปลี่ยน `AlertOnly=false` ระบบจำกัดความเสี่ยงต่อออเดอร์และ Equity ต่อวัน แต่ไม่สามารถรับประกันอัตราชนะ 90% ได้; โมเดลใช้เกณฑ์คัดกรองเข้มและอาจงดส่งสัญญาณ

## ข่าวทองคำและ Bitcoin บนกราฟ

รัน `GoldCalendarExport` ใน MT5 แล้วนำไฟล์ `GoldCalendar_USD.csv` เข้าฐานข้อมูล:

```powershell
python news_pipeline.py --db market_history.sqlite calendar-import --csv "C:\Users\YOUR_NAME\AppData\Roaming\MetaQuotes\Terminal\Common\Files\GoldCalendar_USD.csv"
```

ดึงหัวข้อข่าวย้อนหลังเท่าที่ GDELT DOC API มี (โดยเริ่มค้นจากปี 2017); สคริปต์จะปัก tag ของข่าวกับสัญลักษณ์แยกกัน:

```powershell
python news_pipeline.py --db market_history.sqlite gdelt --symbol XAUUSD --since 2017-01-01 --max-days 30
python news_pipeline.py --db market_history.sqlite gdelt --symbol BTCUSD --since 2017-01-01 --max-days 30
```

รันซ้ำเพื่อทยอยดึงวันถัดไป; API อาจจำกัดผลและปริมาณคำขอ ถ้าชนเพดาน 250 รายการต่อวัน สคริปต์จะหยุดโดยไม่ทำเครื่องหมายวันนั้นว่าครบ ข้อมูลปี 2016 ที่ไม่อยู่ใน GDELT ต้องนำเข้าจากแหล่งข่าวย้อนหลังที่มีสิทธิ์ โดย CSV คอลัมน์ `published_utc,title,url,source` และสั่ง `headlines-import --csv PATH --symbol XAUUSD` หรือ `BTCUSD`

ส่งออกเส้นบนกราฟแยกสองไฟล์ โดย `--server-utc-offset-hours` ต้องเป็นค่าเวลาของเซิร์ฟเวอร์โบรกเกอร์เทียบกับ UTC ในวันปัจจุบัน:

```powershell
python news_pipeline.py --db market_history.sqlite overlay --symbol XAUUSD --common-files "C:\Users\YOUR_NAME\AppData\Roaming\MetaQuotes\Terminal\Common\Files" --server-utc-offset-hours 2
python news_pipeline.py --db market_history.sqlite overlay --symbol BTCUSD --common-files "C:\Users\YOUR_NAME\AppData\Roaming\MetaQuotes\Terminal\Common\Files" --server-utc-offset-hours 2
```

เส้นสีส้มคือเหตุการณ์เศรษฐกิจ USD ที่ใช้ได้กับทั้งสองกราฟ; เส้นสีฟ้าคือหัวข้อข่าวเฉพาะสินทรัพย์ ข้อมูลข่าวเป็น **บริบทตามเวลา** ไม่ใช่ตัวทำนาย Buy/Sell หากโบรกเกอร์เปลี่ยนเขตเวลาในอดีต เส้นข่าวย้อนหลังอาจคลาดเคลื่อนหนึ่งชั่วโมง ตรวจฐานข้อมูลด้วย `python news_pipeline.py --db market_history.sqlite status --symbol BTCUSD --timeframe M15` (สั่งอีกครั้งสำหรับ XAUUSD)

## ข้อจำกัดการทดสอบ

ชุดนี้ยังไม่ผ่านการ Compile ด้วย MetaEditor หรือ Backtest กับบัญชี MT5 จริง ข้อมูลข่าว/ราคาต้องดึงบนเครื่องของคุณ; Python ทดสอบหน่วยและไฟล์ ZIP ตรวจแล้ว สคริปต์ประเมินผลย้อนหลังจาก OHLC แบบประมาณ ไม่รวม Tick path, คอมมิชชัน, slippage และ swap จึงต้อง Forward Test บัญชี Demo แยก XAU กับ BTC ก่อนใช้งานจริง

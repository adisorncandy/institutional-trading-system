"""Collect and research XAUUSD (10y) and BTCUSD (5y) sequentially from one MT5 terminal.

Use exact broker symbol names, including suffixes. Requires running/logged-in MT5.
"""
import argparse
import subprocess
import sys
from pathlib import Path


def commands(args):
    frames=["M5","M15","M30","H1","H4"] if getattr(args,"all_timeframes",False) else [args.timeframe]
    tasks=[]
    for tf in frames:
        base = [sys.executable, str(Path(__file__).with_name("adaptive_research.py")),
                "--db", str(args.db), "--common-files", str(args.common_files),
                "--timeframe", tf]
        tasks.extend([
            ("gold "+tf, base + ["--symbol", args.gold_symbol, "--years", "10",
                              "--max-spread-points", str(args.gold_max_spread_points),
                              "--fallback-spread-points",str(getattr(args,"gold_fallback_spread_points",0)),
                              "--slippage-points",str(getattr(args,"gold_slippage_points",5)),
                              "--roundtrip-fee-points",str(getattr(args,"gold_fee_points",0)),
                              "--trading-days-per-week", str(args.gold_trading_days)]),
            ("bitcoin "+tf, base + ["--symbol", args.btc_symbol, "--years", "5",
                                 "--max-spread-points", str(args.btc_max_spread_points),
                                 "--fallback-spread-points",str(getattr(args,"btc_fallback_spread_points",0)),
                                 "--slippage-points",str(getattr(args,"btc_slippage_points",5)),
                                 "--roundtrip-fee-points",str(getattr(args,"btc_fee_points",0)),
                                 "--trading-days-per-week", str(args.btc_trading_days)]),
        ])
    return tasks


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--gold-symbol", default="XAUUSD")
    p.add_argument("--btc-symbol", default="BTCUSD")
    p.add_argument("--timeframe", default="M15", choices=["M5", "M15", "M30", "H1", "H4"])
    p.add_argument("--all-timeframes", action="store_true", help="Build five separate models for each asset")
    p.add_argument("--common-files", type=Path, required=True)
    p.add_argument("--db", type=Path, default=Path("market_history.sqlite"))
    p.add_argument("--gold-max-spread-points", type=float, default=80.0)
    p.add_argument("--btc-max-spread-points", type=float, default=5000.0)
    p.add_argument("--gold-fallback-spread-points", type=float, default=0.0)
    p.add_argument("--btc-fallback-spread-points", type=float, default=0.0)
    p.add_argument("--gold-slippage-points", type=float, default=5.0)
    p.add_argument("--btc-slippage-points", type=float, default=5.0)
    p.add_argument("--gold-fee-points", type=float, default=0.0)
    p.add_argument("--btc-fee-points", type=float, default=0.0)
    p.add_argument("--gold-trading-days", type=int, choices=[5,6,7], default=5)
    p.add_argument("--btc-trading-days", type=int, choices=[5,6,7], default=7)
    args=p.parse_args()
    if args.gold_symbol==args.btc_symbol or min(args.gold_max_spread_points,args.btc_max_spread_points)<=0:
        p.error("Symbols must differ and spread ceilings must be positive")
    errors=[]
    for label, cmd in commands(args):
        print(f"Starting {label}: {cmd[cmd.index('--symbol')+1]}", flush=True)
        result=subprocess.run(cmd,check=False)
        if result.returncode:
            errors.append(label)
    if errors:
        raise SystemExit(f"Incomplete assets: {', '.join(errors)}. See individual errors; no model is published for failed assets.")
    print("Both asset histories and audit reports are ready. Check actual date ranges and selected_keys.")


if __name__ == "__main__":
    main()

# MarketAdaptiveEA v0.6 — ตรวจผลย้อนหลัง XAUUSD/BTCUSD

**ยังไม่มีผล Backtest จริงในชุดนี้** เพราะยังไม่มีประวัติราคา MT5 ของโบรกเกอร์ในงานนี้ ชุดนี้เพิ่มตัวทดสอบจาก SQLite/CSV เพื่อให้รันผลจริงได้ทันทีเมื่อได้รับข้อมูล แล้วค่อยพิจารณาแก้กติกาจากหลักฐาน ไม่ปรับตัวเลขเพื่ออ้างความแม่นยำโดยไม่มีข้อมูล

## สิ่งที่ตัวทดสอบตรวจ

- ฝึกตัวคัดกรองจาก 60% แรก ตรวจสอบ 20% ถัดมา และทดสอบบน 20% ท้ายตามเวลา พร้อมกันช่วงทับซ้อนของผลลัพธ์
- เปรียบเทียบสัญญาณทั้งหมดกับสัญญาณที่ผ่านเกณฑ์ โดยใช้ช่วงทดสอบเดียวกัน
- เปิดได้หนึ่งสถานะต่อ Symbol ในแต่ละครั้ง; เข้าตอนเปิดแท่งถัดไป; นับ SL ก่อน TP ถ้าราคาในแท่งเดียวแตะทั้งคู่; หากเปิดแท่งกระโดดข้าม SL ใช้ราคาเปิดที่แย่กว่า
- ใส่ Historical spread, slippage และค่าธรรมเนียมที่แปลงเป็น points; จำกัดเวลาถือครองและจำลองความเสี่ยง 0.5% ต่อออเดอร์/เพดานขาดทุนรายวันโดยประมาณ
- สรุปจำนวนดีล, อัตราชนะหลังต้นทุน, net R, profit factor แบบ R, การเปลี่ยน Equity สมมติ และ maximum drawdown; ส่ง CSV รายดีลเพื่อสอบย้อนกลับ

**ข้อจำกัด:** OHLC ไม่รู้ลำดับ Tick ภายในแท่ง, การ Fill จริง, Swap, Stop Level, Margin/Stop Out, ค่าคอมมิชชันในสกุลบัญชี, Timezone ที่เปลี่ยนตามฤดูกาล และเวลาฐาน Equity ตอนเริ่มวัน ผลนี้เป็นการตรวจเบื้องต้น **ไม่ใช่ Strategy Tester ของ MT5** หรือผลตอบแทนรับประกัน

## กรณีมี MT5 บน Windows/VPS

ใช้ `run_assets.py --all-timeframes` จากคู่มือ `README_TIMEFRAMES_TH.md` เพื่อสร้าง `market_history.sqlite` ก่อน ตรวจวันที่แรก/ท้ายของแต่ละ Symbol/Timeframe และค่า `point` จริงใน MT5 → Specification แล้วทดสอบตัวอย่างนี้ (ตัวเลข point/ต้นทุนต้องแก้ให้ตรงโบรกเกอร์):

```powershell
python backtest_realistic.py --db market_history.sqlite --symbol XAUUSD --timeframe M15 --point 0.01 --max-spread-points 80 --slippage-points 5 --roundtrip-fee-points 0 --server-utc-offset-hours 2 --output backtest_XAUUSD_M15.csv
python backtest_realistic.py --db market_history.sqlite --symbol BTCUSD --timeframe M15 --point 0.01 --max-spread-points 5000 --slippage-points 5 --roundtrip-fee-points 0 --server-utc-offset-hours 2 --output backtest_BTCUSD_M15.csv
```

ทำซ้ำสำหรับ M5, M30, H1, H4 โดยใช้ `--point`, เพดานสเปรด, slippage และ commission ของแต่ละสัญลักษณ์ หาก CSV หรือ MT5 ไม่มี Historical spread ต้องระบุ `--fallback-spread-points` ตามข้อมูลที่ตรวจจากโบรกเกอร์ (การสมมติ spread เป็นศูนย์จะทำให้ผลดีเกินจริงและสคริปต์ไม่สร้างสัญญาณ)

## กรณีส่งออก CSV จาก MT5 ให้ตรวจร่วมกัน

รับไฟล์ CSV/TSV แท่งราคาของแต่ละสัญลักษณ์/Timeframe ที่มีอย่างน้อย `DATE,TIME,OPEN,HIGH,LOW,CLOSE,SPREAD` โดยใช้ชื่อคอลัมน์แบบ MT5 `<DATE>` ฯลฯ ได้ พร้อมแจ้ง **ชื่อ Symbol จริง, point, Timezone ของเวลาในไฟล์, commission, ช่วงวันที่ และโบรกเกอร์** นำเข้าตัวอย่าง:

```powershell
python import_mt5_csv.py --file XAUUSD_M15.csv --symbol XAUUSD --timeframe M15 --server-utc-offset-hours 2 --db market_history.sqlite
```

ถ้าช่วงย้อนหลังโบรกเกอร์เปลี่ยน UTC offset ต้องแยกไฟล์ตามช่วง offset ที่ถูกต้องก่อนนำเข้า หรือใช้ MT5 Python API ที่ให้ bar timestamps เป็น UTC เพื่อหลีกเลี่ยงการคลาดของเวลา

## วิธีใช้ผลเพื่อปรับปรุง

พิจารณาเฉพาะช่วงทดสอบปลายทางที่มีจำนวนดีลมากพอ เทียบ **win rate พร้อม profit factor และ drawdown** หลังหักต้นทุน อย่าเลือก Timeframe ด้วย win rate ตัวเดียว เพราะ Take Profit ที่ใกล้มากอาจชนะบ่อยแต่ขาดทุนสุทธิ หากตัวคัดกรองได้ 0 ดีล ให้รายงานว่า *ไม่มีหลักฐานสำหรับระบบนั้น* และทดสอบช่วง Forward Demo ต่อ จากนั้นยืนยันด้วย MT5 Strategy Tester แบบ **Every tick based on real ticks** ของโบรกเกอร์

โปรไฟล์ของ EA v0.5 ยังไม่ถูกปรับเพื่ออ้างว่าแม่นขึ้น การแก้ตามผลทดสอบปลายทางซ้ำ ๆ จะทำให้ช่วงนั้นไม่เป็นชุดทดสอบที่ไม่เคยเห็นอีกต่อไป; ต้องกันข้อมูลช่วงใหม่หรือ Forward Test ภายหลัง

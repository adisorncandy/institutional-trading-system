"""Conservative OHLC out-of-sample review of MarketAdaptiveEA candidates.

Uses the broker SQLite bar database created by run_assets.py. Results are an
approximation; MT5 Strategy Tester with real ticks is required before live use.
"""
from __future__ import annotations

import argparse
import csv
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from adaptive_research import PROFILES, candidates, fit_gate, indicators
from trade_simulation import simulate_trade


def run_portfolio(bars, signals, cutoff, profile, point, fallback_spread, allowed_keys,
                  slippage_points, fee_points, risk_pct=0.5,
                  daily_loss_pct=2.0, server_utc_offset_hours=0.0):
    index_by_time={bar[0]:i for i,bar in enumerate(bars)}
    atr=indicators(bars,profile)[3]
    next_free=-1
    equity=1.0
    peak=1.0
    drawdown=0.0
    trades=[]
    current_day=None
    day_start_equity=equity
    for timestamp,key,_ in signals:
        if timestamp<cutoff or (allowed_keys is not None and key not in allowed_keys):
            continue
        i=index_by_time[timestamp]
        day=datetime.fromtimestamp(bars[i+1][0]+round(server_utc_offset_hours*3600),timezone.utc).date()
        if day!=current_day:
            current_day=day
            day_start_equity=equity
        if equity<=day_start_equity*(1-daily_loss_pct/100):
            continue
        if i+1<=next_free:  # Existing trade held through or into the next entry bar
            continue
        trade=simulate_trade(bars,i,key.split("_",1)[0],atr[i],point,fallback_spread,
                             slippage_points,fee_points,profile)
        trade["signal_time"]=timestamp
        trade["bucket"]=key
        next_free=trade["exit_bar"]
        equity=max(0.0,equity*(1+risk_pct/100*trade["R"]))
        peak=max(peak,equity)
        drawdown=max(drawdown,(peak-equity)/peak)
        trades.append(trade)
        if equity==0.0:
            break
    return trades,equity,drawdown


def summary(trades,equity,drawdown):
    gains=sum(t["R"] for t in trades if t["R"]>0)
    losses=-sum(t["R"] for t in trades if t["R"]<0)
    return {"trades":len(trades),"wins":sum(t["R"]>0 for t in trades),
            "win_rate":sum(t["R"]>0 for t in trades)/len(trades) if trades else None,
            "net_R":sum(t["R"] for t in trades),
            "profit_factor_R":gains/losses if losses else None,
            "equity_change_pct":100*(equity-1),"max_drawdown_pct":100*drawdown,
            "warning":"OHLC approximation; not a tick-accurate MT5 result"}


def backtest(bars,profile,point,max_spread,fallback_spread,slippage_points=5,
             fee_points=0,risk_pct=0.5,daily_loss_pct=2.0,server_utc_offset_hours=0.0):
    signals=list(candidates(bars,point,fallback_spread,max_spread,profile,slippage_points,fee_points))
    if len(signals)<100:
        raise ValueError(f"Only {len(signals)} labeled candidates; need at least 100")
    selected,audit=fit_gate(signals,bar_seconds={"M5":300,"M15":900,"M30":1800,"H1":3600,"H4":14400}[
        profile.tag.split("_")[-1]],max_hold=profile.hold)
    cutoff=signals[int(len(signals)*0.8)][0]
    results={}
    for label,keys in (("unfiltered",None),("validated_gate",selected)):
        trades,equity,dd=run_portfolio(bars,signals,cutoff,profile,point,fallback_spread,keys,
                                       slippage_points,fee_points,risk_pct,daily_loss_pct,server_utc_offset_hours)
        results[label] = {"summary":summary(trades,equity,dd),"trades":trades}
    return cutoff,audit,results


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--db",type=Path,default=Path("market_history.sqlite"))
    p.add_argument("--symbol",required=True)
    p.add_argument("--timeframe",choices=list(PROFILES),required=True)
    p.add_argument("--point",type=float,required=True,help="MT5 symbol point size, e.g. 0.01")
    p.add_argument("--max-spread-points",type=float,required=True)
    p.add_argument("--fallback-spread-points",type=float,default=0)
    p.add_argument("--slippage-points",type=float,default=5)
    p.add_argument("--roundtrip-fee-points",type=float,default=0,
                   help="Commission converted into price points for one roundtrip")
    p.add_argument("--risk-percent",type=float,default=0.5)
    p.add_argument("--daily-loss-percent",type=float,default=2.0)
    p.add_argument("--server-utc-offset-hours",type=float,default=0,
                   help="Broker server offset for approximate daily pause boundaries")
    p.add_argument("--output",type=Path,default=Path("backtest_report.csv"))
    args=p.parse_args()
    if not args.db.exists():
        p.error(f"Price database not found: {args.db}. Run run_assets.py on your MT5 first.")
    if min(args.point,args.max_spread_points,args.risk_percent,args.daily_loss_percent)<=0 or min(args.slippage_points,args.roundtrip_fee_points,args.fallback_spread_points)<0:
        p.error("Invalid costs, risk, or symbol point")
    with sqlite3.connect(args.db) as db:
        try:
            bars=db.execute("SELECT time_utc,open,high,low,close,spread FROM bars WHERE symbol=? AND timeframe=? ORDER BY time_utc",
                            (args.symbol,args.timeframe)).fetchall()
        except sqlite3.OperationalError as exc:
            p.error(f"Price table missing: {exc}")
    if not bars:
        p.error(f"No bars for {args.symbol}/{args.timeframe}")
    cutoff,audit,results=backtest(bars,PROFILES[args.timeframe],args.point,args.max_spread_points,
                                   args.fallback_spread_points,args.slippage_points,
                                   args.roundtrip_fee_points,args.risk_percent,args.daily_loss_percent,args.server_utc_offset_hours)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open("w",newline="",encoding="utf-8") as f:
        writer=csv.writer(f)
        writer.writerow(["symbol","timeframe","test_start_utc","variant","metric","value"])
        for variant,result in results.items():
            for metric,value in result["summary"].items():
                writer.writerow([args.symbol,args.timeframe,datetime.fromtimestamp(cutoff,timezone.utc).isoformat(),variant,metric,value])
    trades_path=args.output.with_name(args.output.stem+"_trades.csv")
    with trades_path.open("w",newline="",encoding="utf-8") as f:
        writer=csv.DictWriter(f,fieldnames=["variant","signal_time","bucket","entry_time","exit_time","side","entry","exit","reason","R","entry_bar","exit_bar"])
        writer.writeheader()
        for variant,result in results.items():
            writer.writerows({"variant":variant,**t} for t in result["trades"])
    print(f"Untouched test begins {datetime.fromtimestamp(cutoff,timezone.utc).isoformat()}")
    print(f"Selected buckets: {audit['selected_keys']}")
    for label,result in results.items():
        print(label,result["summary"])
    print(f"Wrote {args.output} and {trades_path}")


if __name__=="__main__":
    main()

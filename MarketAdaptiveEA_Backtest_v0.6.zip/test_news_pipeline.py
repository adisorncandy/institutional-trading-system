import csv
import json
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

from news_pipeline import connect, import_calendar, import_headlines, export_overlay, parse_gdelt_article, collect_gdelt


class NewsPipelineTests(unittest.TestCase):
    def test_calendar_and_headlines_share_timeline_with_provenance(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            now = int(datetime.now(timezone.utc).timestamp())
            cal = root / "cal.csv"
            with cal.open("w", encoding="utf-8", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["value_id","event_id","time_server_epoch","time_server_text","importance","name","actual","forecast"])
                writer.writerow(["1","10",str(now+7200),"2026.09.27 12:00:00","CALENDAR_IMPORTANCE_HIGH","US CPI","2.3","2.2"])
            headlines = root / "headlines.csv"
            with headlines.open("w", encoding="utf-8", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["published_utc","title","url","source"])
                writer.writerow([datetime.fromtimestamp(now,timezone.utc).isoformat(),"Gold outlook","https://example.org/a","LICENSED"])
            with connect(root / "prices.sqlite") as db:
                self.assertEqual(import_calendar(db,cal),1)
                self.assertEqual(import_headlines(db,headlines),1)
                count=export_overlay(db,root / "GoldEvents_XAUUSD.txt",7,2,10)
            self.assertEqual(count,2)
            content=(root / "GoldEvents_XAUUSD.txt").read_text()
            self.assertIn("MT5_CALENDAR|CALENDAR_IMPORTANCE_HIGH|US CPI", content)
            self.assertIn("LICENSED|HEADLINE|Gold outlook|https://example.org/a", content)
            with connect(root / "prices.sqlite") as db:
                btc=export_overlay(db,root / "MarketEvents_BTCUSD.txt",7,2,10,symbol="BTCUSD")
            self.assertEqual(btc,1)  # Shared USD calendar; no gold-only headline leakage

    def test_gdelt_time_and_cap_does_not_mark_day_complete(self):
        self.assertEqual(parse_gdelt_article({"seendate":"20260927T000000Z","url":"https://example.org/x","title":"Gold"})[1],
                         int(datetime(2026,9,27,tzinfo=timezone.utc).timestamp()))
        with tempfile.TemporaryDirectory() as folder:
            with connect(Path(folder)/"db.sqlite") as db:
                with patch("news_pipeline.fetch_gdelt_day",return_value=[{}]*250):
                    with self.assertRaises(RuntimeError):
                        collect_gdelt(db,datetime(2020,1,1,tzinfo=timezone.utc),1,'"gold price"',0)
                self.assertEqual(db.execute("SELECT COUNT(*) FROM fetch_days_asset").fetchone()[0],0)


if __name__ == "__main__":
    unittest.main()

import argparse
import unittest
from pathlib import Path

from run_assets import commands


class AssetsTests(unittest.TestCase):
    def test_distinct_histories_and_spreads(self):
        args=argparse.Namespace(db=Path("market_history.sqlite"),common_files=Path("common"),timeframe="M15",
                                gold_symbol="XAUUSDm",btc_symbol="BTCUSDm",gold_max_spread_points=80,
                                btc_max_spread_points=5000,gold_trading_days=5,btc_trading_days=7)
        gold,btc=commands(args)
        self.assertEqual(gold[1][gold[1].index("--years")+1],"10")
        self.assertEqual(btc[1][btc[1].index("--years")+1],"5")
        self.assertEqual(gold[1][gold[1].index("--symbol")+1],"XAUUSDm")
        self.assertEqual(btc[1][btc[1].index("--symbol")+1],"BTCUSDm")
        self.assertEqual(btc[1][btc[1].index("--max-spread-points")+1],"5000")

    def test_all_timeframes_produce_ten_independent_jobs(self):
        args=argparse.Namespace(db=Path("market_history.sqlite"),common_files=Path("common"),timeframe="M15",
                                all_timeframes=True,gold_symbol="XAUUSD",btc_symbol="BTCUSD",
                                gold_max_spread_points=80,btc_max_spread_points=5000,
                                gold_trading_days=5,btc_trading_days=7)
        jobs=commands(args)
        self.assertEqual(len(jobs),10)
        self.assertEqual({cmd[cmd.index("--timeframe")+1] for _,cmd in jobs},{"M5","M15","M30","H1","H4"})


if __name__ == "__main__":
    unittest.main()

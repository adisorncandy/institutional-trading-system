import unittest

from adaptive_research import fit_gate, wilson_lower, key_for, PROFILES


class ResearchTests(unittest.TestCase):
    def test_wilson_penalizes_tiny_sample(self):
        self.assertLess(wilson_lower(9, 10), 0.90)
        self.assertGreater(wilson_lower(300, 300), 0.90)

    def test_gate_respects_chronological_test(self):
        # All train/validation samples win, all untouched test samples lose.
        samples = [(i * 900, "BUY_R0_T0", 1 if i < 320 else 0) for i in range(400)]
        eligible, audit = fit_gate(samples, bar_seconds=900)
        self.assertIn("BUY_R0_T0", eligible)
        self.assertEqual(audit["untouched_test_selected_count"], 80)
        self.assertEqual(audit["untouched_test_selected_win_rate"], 0.0)
        self.assertLess(audit["train_count"], 240)  # 17-bar embargo

    def test_features_are_bounded_and_deterministic(self):
        self.assertEqual(key_for("BUY", 65, 102, 100, 2), "BUY_R1_T1")
        self.assertEqual(key_for("SELL", 45, 99.8, 100, 2), "SELL_R0_T0")

    def test_five_profiles_have_distinct_horizons(self):
        self.assertEqual(set(PROFILES), {"M5","M15","M30","H1","H4"})
        self.assertEqual(PROFILES["M5"].hold,12)
        self.assertEqual(PROFILES["H1"].hold,24)
        self.assertGreater(PROFILES["H4"].stop_atr,PROFILES["M5"].stop_atr)


if __name__ == "__main__":
    unittest.main()

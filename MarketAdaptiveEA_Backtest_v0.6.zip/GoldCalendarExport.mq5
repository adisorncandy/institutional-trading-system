// Export US economic release calendar to Common/Files for the news pipeline.
// Run as a Script in an online MT5 terminal; Calendar times are trade-server times.
#property strict
#property script_show_inputs
input int YearsBack=10;
input bool OnlyHighImportance=true;
input string OutputFile="GoldCalendar_USD.csv";

void OnStart()
{
   if(YearsBack<1 || YearsBack>20) { Print("YearsBack must be 1..20"); return; }
   datetime end=TimeTradeServer();
   MqlDateTime t; TimeToStruct(end,t);
   t.year-=YearsBack; t.day=1; t.hour=0; t.min=0; t.sec=0;
   datetime cursor=StructToTime(t);
   int file=FileOpen(OutputFile,FILE_READ|FILE_WRITE|FILE_CSV|FILE_COMMON|FILE_ANSI,',',CP_UTF8);
   if(file==INVALID_HANDLE) { Print("Cannot open calendar export: ",GetLastError()); return; }
   if(FileSize(file)==0) FileWrite(file,"value_id","event_id","time_server_epoch","time_server_text","importance","name","actual","forecast");
   FileSeek(file,0,SEEK_END);
   int total=0,failed=0;
   while(cursor<end && !IsStopped())
   {
      MqlDateTime next; TimeToStruct(cursor,next);
      next.mon++;
      if(next.mon>12) { next.mon=1; next.year++; }
      datetime until=StructToTime(next);
      if(until>end) until=end;
      MqlCalendarValue values[];
      ResetLastError();
      int n=CalendarValueHistory(values,cursor,until,"US","USD");
      if(n<0)
      {
         Print("Calendar month failed ",TimeToString(cursor,TIME_DATE)," error=",GetLastError());
         failed++;
      }
      else
      {
         for(int i=0;i<n;i++)
         {
            MqlCalendarEvent event;
            if(!CalendarEventById(values[i].event_id,event)) { failed++; continue; }
            if(OnlyHighImportance && event.importance!=CALENDAR_IMPORTANCE_HIGH) continue;
            string title=event.name;
            StringReplace(title,"\r"," "); StringReplace(title,"\n"," ");
            string actual=values[i].HasActualValue()?DoubleToString(values[i].GetActualValue(),6):"";
            string forecast=values[i].HasForecastValue()?DoubleToString(values[i].GetForecastValue(),6):"";
            FileWrite(file,(long)values[i].id,(long)values[i].event_id,(long)values[i].time,
                      TimeToString(values[i].time,TIME_DATE|TIME_SECONDS),EnumToString(event.importance),
                      title,actual,forecast);
            total++;
         }
      }
      FileFlush(file);
      cursor=until;
   }
   FileClose(file);
   Print("Calendar exported rows=",total," failed months/events=",failed," file=",OutputFile,
         ". Check earliest event date and failed chunks; calendar history may not cover ten years.");
}
